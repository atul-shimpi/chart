//
// Copyright (c) 2014-2015 TIBCO Software Inc. All rights reserved.
//
'use strict';
var Notify = (function($){

	/**
	 * This object wraps a straight-forward Notify chart. It is meant to be reusable, but is limited in the configuration
	 * options made available. It extends from the Visualization base object which maintains its data model.
	 * @class Notify
	 * @param {Object} settings An object containing the parameters used to configure this Notify
	 * @param {String} settings.elementId The element ID of the DOM element that this visualization should render in.
	 * @param {String} [settings.categoryField] The field name of the category field in the data model.
	 * @param {String} [settings.valueField] The field name of the value field in the data model.
	 */
	function Notify(settings){
		this.schema = {};
		this.data = [];
		this.html = '';
		this.settings = settings || {elementId: ''};
		this.settings.categoryField = settings.categoryField || 'category';
		this.settings.valueField = settings.valueField || 'value';
		this.viewModel = [];
	}

	Notify.prototype = $.extend(
		new Visualization(),
		{
			refresh: function(){
				var i;
				//sync viewModel with data
				this.viewModel = [];
				for(i = 0; i < this.data.length; i++){
					if(this.data[i]){
						this.viewModel.push(this.data[i].fieldMap);
					}
				}
				this.render();
			},
			render: function(){
				/*
				console.log("in Notify");
				console.log(this.viewModel);
				console.log(this.settings.elementId);
				console.log(this.settings.spanID);
				console.log(this.viewModel[0].cnt);
				*/
				
				var self = this,
				element = d3.select('#' + this.settings.elementId);
				// console.log(element);
				element.selectAll('#' + this.settings.spanID).remove();

				// element.html('hello');
				if(this.viewModel[0].cnt > 0){
					element.append('span')
						.attr('class', 'label label-danger pull-right')
						.attr('style', 'margin-right:10px')
						.attr('id', this.settings.spanID)
						.html(''+ this.viewModel[0].cnt);
				}
				else{
					
				}
				


				// class="label label-danger pull-right" style="margin-right:10px"


				
				
				
			}
		}
	);

	return Notify;

})(jQuery);
