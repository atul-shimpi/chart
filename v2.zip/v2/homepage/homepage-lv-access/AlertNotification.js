//
// Copyright (c) 2014-2015 TIBCO Software Inc. All rights reserved.
//
'use strict';
var AlertNotification = (function($){

	/**
	 * This object wraps a straight-forward AlertNotification chart. It is meant to be reusable, but is limited in the configuration
	 * options made available. It extends from the Visualization base object which maintains its data model.
	 * @class AlertNotification
	 * @param {Object} settings An object containing the parameters used to configure this AlertNotification
	 * @param {String} settings.elementId The element ID of the DOM element that this visualization should render in.
	 * @param {String} [settings.categoryField] The field name of the category field in the data model.
	 * @param {String} [settings.valueField] The field name of the value field in the data model.
	 */
	function AlertNotification(settings){
		this.schema = {};
		this.data = [];
		this.html = '';
		this.settings = settings || {elementId: ''};
		this.settings.categoryField = settings.categoryField || 'category';
		this.settings.valueField = settings.valueField || 'value';
		this.viewModel = [];
	}

	AlertNotification.prototype = $.extend(
		new Visualization(),
		{
			refresh: function(){
				var i;
				//sync viewModel with data
				this.viewModel = [];
				for(i = 0; i < this.data.length; i++){
					if(this.data[i]){
						this.viewModel.push(this.data[i].fieldMap);
					}
				}
				this.render();
			},
			render: function(){
				/*
				console.log("in AlertNotification");
				
				console.log(this.settings.elementId);
				console.log(this.settings.spanID);
				console.log(this.viewModel[0].cnt);
				*/
				// console.log(this.viewModel);
				
				var self = this,
					red = 0,
					yellow = 0,
					blue = 0,
					element = d3.select('#' + this.settings.elementId);
				console.log('in AlertNotification');
				element.selectAll('#' + this.settings.spanID).remove();

				for (i = 0; i < this.viewModel.length; i++) { 
					/*
					console.log(this.viewModel[i].Status);
					console.log(this.viewModel[i].cnt);
					*/
				    if(this.viewModel[i].Status == 'Red'){
				    	red = this.viewModel[i].cnt;
				    }
				    else if(this.viewModel[i].Status == 'Yellow'){
				    	yellow = this.viewModel[i].cnt;
				    }
				    else if(this.viewModel[i].Status == 'Blue'){
				    	blue = this.viewModel[i].cnt;
				    }
				}
				/*
				console.log(red);
				console.log(yellow);
				console.log(blue);
				*/
				
				if(blue > 0){
					element.append('span')
							.attr('class', 'label label-primary pull-right')
							.attr('style', 'margin-right:5px')
							.attr('id', this.settings.spanID)
							.html(''+ blue);
				}
				if(red > 0){
					element.append('span')
							.attr('class', 'label label-danger pull-right')
							.attr('style', 'margin-right:5px')
							.attr('id', this.settings.spanID)
							.html(''+ red);
				}

				if(yellow > 0){
					element.append('span')
							.attr('class', 'label label-warning pull-right')
							.attr('style', 'margin-right:5px')
							.attr('id', this.settings.spanID)
							.html(''+ yellow);
				}


				// element.html('hello');
				/*
				if(this.viewModel[0].cnt > 0){
					element.append('span')
						.attr('class', 'label label-danger pull-right')
						.attr('style', 'margin-right:10px')
						.attr('id', this.settings.spanID)
						.html(''+ this.viewModel[0].cnt);
				}
				else{
					
				}
				*/



				// class="label label-danger pull-right" style="margin-right:10px"


				
				
				
			}
		}
	);

	return AlertNotification;

})(jQuery);
