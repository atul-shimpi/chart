//
// Copyright (c) 2014-2015 TIBCO Software Inc. All rights reserved.
//
'use strict';


var GoogleChartServerTrendTable = (function($){
	/**
	 * This object wraps a straight-forward GoogleChartServerTrendTable chart. It is meant to be reusable, but is limited in the configuration
	 * options made available. It extends from the Visualization base object which maintains its data model.
	 * @class GoogleChartServerTrendTable
	 * @param {Object} settings An object containing the parameters used to configure this GoogleChartServerTrendTable
	 * @param {String} settings.elementId The element ID of the DOM element that this visualization should render in.
	 * @param {String} [settings.categoryField] The field name of the category field in the data model.
	 * @param {String} [settings.valueField] The field name of the value field in the data model.
	 */
	function GoogleChartServerTrendTable(settings){
		this.schema = {};
		this.data = [];
		this.html = '<div>GoogleChartServerTrendTable goes here</div>';
		this.settings = settings || {elementId: ''};
		this.settings.categoryField = settings.categoryField || 'category';
		this.settings.valueField = settings.valueField || 'value';
		// if adding more stuff in the app.model.js, add them here as well
		this.viewModel = [];
	}

	GoogleChartServerTrendTable.prototype = $.extend(
		new Visualization(),
		{
			refresh: function(){
				var i;
				//sync viewModel with data
				this.viewModel = [];
				for(i = 0; i < this.data.length; i++){
					if(this.data[i]){
						this.viewModel.push(this.data[i].fieldMap);
					}
				}
				
				this.render();
			},
			render: function(){
				/*
				var data = this.viewModel,
					self = this;
				*/
				// console.log(data);
				
				var self = this;
      			// Set a callback to run when the Google Visualization API is loaded.
      			google.charts.setOnLoadCallback(drawChart);
				
      			// drawChart() is to guarantee that DataTable() will be loaded before vis is to be drawn
      			function drawChart(){
      				// console.log('draw table');
      				var rawData = self.viewModel,
			        	data = new google.visualization.DataTable(),
			        	rows = [];
			        // console.log(rawData);
			        
			        // this is necssary for render
			        var element = d3.select('#' + self.settings.elementId);
					element.selectAll('svg').remove();
					element.selectAll('*').remove();

					// console.log(rawData);

					// this part has not been made generic enough just yet
					if(self.settings.storyName == 'serverTrendTable'  && rawData.length > 0){
						// console.log(rawData);
						data.addColumn('datetime', 'Time Inserted');
						data.addColumn('string', 'Server');
						data.addColumn('string', 'Server Type');
						data.addColumn('string', 'Status');
						data.addColumn('string', 'Status Description');
						data.addColumn('number', 'Ping');
						data.addColumn('number', 'CPU');
						data.addColumn('number', 'Memory');
						// data.addColumn('boolean', 'Create Business Error');
						// data.addColumn('boolean', 'Create Fatal Error');
						// data.addColumn('boolean', 'Complete Business Error');
						// data.addColumn('boolean', 'Complete Fatal Error');
						data.addColumn('number', 'Disk C Free');
						data.addColumn('number', 'Disk E Free');
						
						// data.addColumn('string', 'Stack String');
						// data.addColumn('string', 'BAM Error');



						// console.log('res sent to batch');
						for(var i=0; i < rawData.length; i++){
				        	rows.push([new Date(rawData[i]['dtStamp']), 
				        		       rawData[i]['Server'],
				        		       rawData[i]['ServerType'],
				        		       rawData[i]['Status'],
				        		       rawData[i]['StatusDesc'],
				        		       rawData[i]['Ping'],
				        		       rawData[i]['CPU'],
				        		       rawData[i]['Memory'],
				        		       rawData[i]['diskCfree'],
				        		       rawData[i]['diskEfree'],
				        		       ]);

				        
				        }

					}
					else if(self.settings.storyName == 'workloadLagTrendHistory' && rawData.length > 0){
						// console.log('work load lag table here');

						data.addColumn('datetime', 'Time Inserted');
						data.addColumn('datetime', 'Runtime');
						data.addColumn('datetime', 'Tier 2 Update');
						data.addColumn('number', 'Lag Minutes');
						data.addColumn('string', 'Status');
						


						// console.log('res sent to batch');
						for(var i=0; i < rawData.length; i++){
				        	rows.push([new Date(rawData[i]['dtStamp']), 
				        		       new Date(rawData[i]['Runtime']),
				        		       new Date(rawData[i]['Tier2Update']),
				        		       rawData[i]['LagMinutes'],
				        		       rawData[i]['Status']
				        		       ]);


				        }



					}
					else if(self.settings.storyName == 'appTrendTable' && rawData.length > 0){
						//console.log('Application Trend');
						//console.log(rawData);


						data.addColumn('datetime', 'Time Inserted');
						data.addColumn('string', 'Application');
						data.addColumn('string', 'Site');
						data.addColumn('string', 'Server');
						
						// data.addColumn('string', 'Status Code');
						data.addColumn('string', 'Status');
						data.addColumn('string', 'Status Description');
						// data.addColumn('number', 'Response Length');
						data.addColumn('number', 'Time Taken');
						
						
						data.addColumn('string', 'Port');
						data.addColumn('string', 'URL');
						data.addColumn('string', 'VIP Name');
						

						for(var i=0; i < rawData.length; i++){
				        	rows.push([new Date(rawData[i]['dtStamp']),
				        		       rawData[i]['Application'], 
				        		       rawData[i]['WebSite'],
				        		       rawData[i]['Server'],
				        		       
				        		       // rawData[i]['StatusCode'],
				        		       rawData[i]['color'],
				        		       rawData[i]['StatusDescription'],
				        		       // rawData[i]['ResponseLength'],
				        		       rawData[i]['TimeTaken'],
				        		       
				        		       
				        		       rawData[i]['Port'],
				        		       rawData[i]['url'],
				        		       rawData[i]['VIPName']
				        		       // '<a href="' + rawData[i]['url'] + '" target="_blank">Click Here</a>'
				        		       
				        		       ]);


				        }







			








					}
					else if(self.settings.storyName == 'storedbtrend' && rawData.length > 0){
						//console.log('Application Trend');
						//console.log(rawData);


						data.addColumn('datetime', 'Time Inserted');
						data.addColumn('datetime', 'Execution Time');
						data.addColumn('string', 'Database Server');
						data.addColumn('string', 'Database Name');
						
						// data.addColumn('string', 'Status Code');
						data.addColumn('string', 'Application');
						data.addColumn('number', 'Time Taken');
						// data.addColumn('number', 'Response Length');
						data.addColumn('string', 'Query Type');
						
						
						data.addColumn('number', 'Result Rows');
						data.addColumn('string', 'Status');
						data.addColumn('string', 'Status Description');
						

						for(var i=0; i < rawData.length; i++){
				        	rows.push([new Date(rawData[i]['dtStamp']),
				        		       new Date(rawData[i]['Exectime']), 
				        		       rawData[i]['DBServer'],
				        		       rawData[i]['DBName'],
				        		       
				        		       // rawData[i]['StatusCode'],
				        		       rawData[i]['Application'],
				        		       rawData[i]['TimeTaken'],
				        		       // rawData[i]['ResponseLength'],
				        		       rawData[i]['QueryType'],
				        		       
				        		       
				        		       rawData[i]['ResultRows'],
				        		       rawData[i]['Status'],
				        		       rawData[i]['StatusDescription']
				        		       // '<a href="' + rawData[i]['url'] + '" target="_blank">Click Here</a>'
				        		       
				        		       ]);


				        }







			








					}
					else if(rawData.length > 0){
						data.addColumn('datetime', self.settings.field1Name);
			        	data.addColumn('string', self.settings.field2Name);
			        	for(var i=0; i < rawData.length; i++){
				        	rows.push([new Date(rawData[i][self.settings.field1]), rawData[i][self.settings.field2]]);
				        	//console.log([rawData[i][self.settings.categoryField], rawData[i][self.settings.valueField]]);
				        }
					}
			        
					rows = rows.sort(ForceSort);
					// console.log('sorted');
					// for table, the oldest record will be at top
					function ForceSort(a, b) {
					    if (a[0] < b[0]){
					    	// console.log('less');
					   		return 1;
					   	}
					    if (a[0] > b[0]){
					    	// console.log('greater');
					    	return -1;
					    }
					    
					    return 0;
					}

					// console.log(rows);

			        data.addRows(rows);
			        // console.log('rows: ' + rows.length);
			        // console.log(rows);

			        // Set chart options
			        
			        // Instantiate and draw our chart, passing in some options.
			        var chart = new google.visualization.Table(document.getElementById(self.settings.elementId));
			        chart.draw(data, {allowHtml: true, showRowNumber: false, width: '100%', height: '100%'});	




			        //if(self.settings.storyName == 'resSentToBatch'){
			        	


			        	//var selectHandler = function(e) {
				        	//open(data.getValue(chart.getSelection()[0]['row'], 8)); // 9 means the 9th column, which is the link in this case
				        	//self.render(); // this is necessary for one of the mysterious bug
				        				   // 
				        //}

				        // Add our selection handler.
				        //google.visualization.events.addListener(chart, 'select', selectHandler);


			        	/*
			        	google.visualization.events.addListener(chart, 'select', selectHandler);
			        	function selectHandler() {
			        		var str;
							var selection = chart.getSelection();
						 	var message = '';
							for (var i = 0; i < selection.length; i++) {
						    	
						    	var item = selection[i];
						    	if (item.row != null && item.column != null) {
						     		var str = data.getFormattedValue(item.row, item.column);
						     		console.log('row: ' + item.row), ', column: ' + item.column;
						      		message += '{row:' + item.row + ',column:' + item.column + '} = ' + str + '\n';
							    } else if (item.row != null) {
							      	var str = data.getFormattedValue(item.row, 0); // the number here means the xth column, starting from 0
							      	message += '{row:' + item.row + ', column:none}; value (col 0) = ' + str + '\n';
							    } else if (item.column != null) {
							      	var str = data.getFormattedValue(0, item.column);
							      	message += '{row:none, column:' + item.column + '}; value (row 0) = ' + str + '\n';
							    }

							    console.log(message);
							    
							}
							if (message == '') {
						    	message = 'nothing';
						  	}
						  	alert(message);
						    window.open("http://localhost:10080/dashboard/pages/Batched_Triaged/Batched_Triaged.html?resnum=" + str);
						}
						*/
			       // }

			        
      			};
			}
		}
	);

	return GoogleChartServerTrendTable;

})(jQuery);
