//
// Copyright (c) 2014-2015 TIBCO Software Inc. All rights reserved.
//
'use strict';


var GoogleChartStoreMultiline = (function($){
	/**
	 * This object wraps a straight-forward GoogleChartStoreMultiline chart. It is meant to be reusable, but is limited in the configuration
	 * options made available. It extends from the Visualization base object which maintains its data model.
	 * @class GoogleChartStoreMultiline
	 * @param {Object} settings An object containing the parameters used to configure this GoogleChartStoreMultiline
	 * @param {String} settings.elementId The element ID of the DOM element that this visualization should render in.
	 * @param {String} [settings.categoryField] The field name of the category field in the data model.
	 * @param {String} [settings.valueField] The field name of the value field in the data model.
	 */
	function GoogleChartStoreMultiline(settings){
		this.schema = {};
		this.data = [];
		this.html = '<div>GoogleChartStoreMultiline goes here</div>';
		this.settings = settings || {elementId: ''};
		this.settings.categoryField = settings.categoryField || 'category';
		this.settings.valueField = settings.valueField || 'value';
		// if adding more stuff in the app.model.js, add them here as well
		this.viewModel = [];
	}

	GoogleChartStoreMultiline.prototype = $.extend(
		new Visualization(),
		{
			refresh: function(){
				var i;
				//sync viewModel with data
				this.viewModel = [];
				for(i = 0; i < this.data.length; i++){
					if(this.data[i]){
						this.viewModel.push(this.data[i].fieldMap);
					}
				}
				this.render();
			},
			render: function(){
				/*
				var data = this.viewModel,
					self = this;
				console.log(data);
				*/
				// console.log(this.viewModel);
				// console.log(this.viewModel.length);

				var self = this;

      			// Set a callback to run when the Google Visualization API is loaded.
      			google.charts.setOnLoadCallback(drawChart);
                
				
      			function drawChart(){
      				var rawData = self.viewModel,
			        	data = new google.visualization.DataTable(),
			        	rows;
		        	// console.log(self.settings.columnNames.columnHeader);
		        	// this wasn't able to be achieved from the app.model.js 

		        	// story specific
		        	if(self.settings.storyName == 'StoreServerTrend'){

						rows = [['TS', 'CPU', 'Memory', 'Response Time']];
						//rows = self.settings.columnNames.columnHeader;
						// rows = self.settings.columnNames;
				        // console.log(rawData);
				        var tempRows = [];
				        // this is necssary for render
				        var element = d3.select('#' + self.settings.elementId);
						element.selectAll('svg').remove();
					    if(self.settings.howManyLines == 3){
						    for(var i=0; i < rawData.length; i++){
					        	tempRows.push([
					        		new Date(rawData[i][self.settings.xAxis]),
				        	 		rawData[i][self.settings.line1], 
				        	 		rawData[i][self.settings.line2], 
				        	 	    rawData[i][self.settings.line3]
			        	 		]);
					        }	
					    }
					    // console.log(rows);
					    tempRows = tempRows.sort(ForceSortM);
						// console.log('sorted');
						rows = rows.concat(tempRows);

						// console.log(rows);

						function ForceSortM(a, b) {

						    if (a[0] < b[0]){
						    	// console.log('less');
						   		return -1;
						   	}
						    if (a[0] > b[0]){
						    	// console.log('greater');
						    	return 1;
						    } 
						    
						    console.log('a');
						    console.log(a[0]);
						    console.log('b');
						    console.log(b[0]);
						    
						    // console.log('equal');
						    return 0;
						}

				        // console.log(rows);
					    var data = google.visualization.arrayToDataTable(rows);

				     
				        // Instantiate and draw our chart, passing in some options.
				        var chart = new google.visualization.ChartWrapper({
				            chartType: 'LineChart',
				            containerId: self.settings.elementId,
				            dataTable: data,
				            options: self.settings.options
				        });
				        
				        // create columns array
				        var columns = [0];
				        /* the series map is an array of data series
				         * "column" is the index of the data column to use for the series
				         * "roleColumns" is an array of column indices corresponding to columns with roles that are associated with this data series
				         * "display" is a boolean, set to true to make the series visible on the initial draw
				         */
				        var seriesMap = [{
				            column: 1,
				            roleColumns: [],
				            display: true,
				            color: 'orange'
				        }, {
				            column: 2,
				            roleColumns: [],
				            display: true,
				            color: 'blue'
				        }, {
				            column: 3,
				            roleColumns: [],
				            display: true,
				            color: 'pink'
				        
				        }];
				        var columnsMap = {};
				        var series = [];
				        for (var i = 0; i < seriesMap.length; i++) {
				            var col = seriesMap[i].column;
				            columnsMap[col] = i;
				            // set the default series option
				            series[i] = {};
				            if (seriesMap[i].display) {
				                // if the column is the domain column or in the default list, display the series
				                columns.push(col);
				            }
				            else {
				                // otherwise, hide it
				                columns.push({
				                    label: data.getColumnLabel(col),
				                    type: data.getColumnType(col),
				                    sourceColumn: col,
				                    calc: function () {
				                        return null;
				                    },
				                    color: 'black'
				                });
				                // backup the default color (if set)
				                /*
				                if (typeof(series[i].color) !== 'undefined') {
				                    series[i].backupColor = series[i].color;
				                }
				                series[i].color = '#CCCCCC';
				                */
				            }
				            for (var j = 0; j < seriesMap[i].roleColumns.length; j++) {
				                columns.push(seriesMap[i].roleColumns[j]);
				            }
				        }

				        
				        
				        chart.setOption('series', self.settings.options.series);
				        
				        function showHideSeries () {
				            var sel = chart.getChart().getSelection();
				            // if selection length is 0, we deselected an element
				            if (sel.length > 0) {
				                // if row is undefined, we clicked on the legend
				                if (sel[0].row == null) {
				                    var col = sel[0].column;
				                    if (typeof(columns[col]) == 'number') {
				                        var src = columns[col];
				                        
				                        // hide the data series
				                        columns[col] = {
				                            label: data.getColumnLabel(src),
				                            type: data.getColumnType(src),
				                            sourceColumn: src,
				                            calc: function () {
				                                return null;
				                            }
				                        };
				                        
				                        // grey out the legend entry
				                        series[columnsMap[src]].color = '#CCCCCC';
				                    }
				                    else {
				                        var src = columns[col].sourceColumn;
				                        
				                        // show the data series
				                        columns[col] = src;
				                        series[columnsMap[src]].color = null;
				                    }
				                    var view = chart.getView() || {};
				                    view.columns = columns;
				                    chart.setView(view);
				                    chart.draw();
				                }
				            }
				        }
				        
				        google.visualization.events.addListener(chart, 'select', showHideSeries);
				        
				        // create a view with the default columns
				        var view = {
				            columns: columns
				        };
				        chart.draw();


						
					}
					else if(self.settings.storyName == 'workloadLagTrend'){
						//console.log('workload lag trend');
						//console.log(rawData);
						rows = [['TS', 'Lag Minutes']];
						//rows = self.settings.columnNames.columnHeader;
						// rows = self.settings.columnNames;
				        // console.log(rawData);
				        var tempRows = [];
				        // this is necssary for render
				        var element = d3.select('#' + self.settings.elementId);
						element.selectAll('svg').remove();
					    
					    for(var i=0; i < rawData.length; i++){
				        	tempRows.push([
				        		new Date(rawData[i][self.settings.xAxis]),
			        	 		rawData[i][self.settings.line1]
		        	 		]);
				        }	
				    
					    // console.log(rows);
					    tempRows = tempRows.sort(ForceSortWK);
						// console.log('sorted');
						rows = rows.concat(tempRows);

						// console.log(rows);

						function ForceSortWK(a, b) {

						    if (a[0] < b[0]){
						    	// console.log('less');
						   		return -1;
						   	}
						    if (a[0] > b[0]){
						    	// console.log('greater');
						    	return 1;
						    }
						    
						    
						    
						    // console.log('equal');
						    return 0;
						}

				        // console.log(rows);
					    var data = google.visualization.arrayToDataTable(rows);

					    // google.visualization.events.addListener(chart, 'select', showHideSeries);
				       	var chart = new google.visualization.ChartWrapper({
				            chartType: 'LineChart',
				            containerId: self.settings.elementId,
				            dataTable: data,
				            options: self.settings.options
				        });

				       	chart.setOption('series', self.settings.options.series);

				       	chart.draw();

					}
					else if(self.settings.storyName == 'ApplicationTrend'){
						// console.log('Application Trend');
						// console.log(rawData);

						rows = [['TS', 'Response Time']];
						var tempRows = [];
				        // this is necssary for render
				        var element = d3.select('#' + self.settings.elementId);
						element.selectAll('svg').remove();
					    
					    for(var i=0; i < rawData.length; i++){
				        	tempRows.push([
				        		new Date(rawData[i][self.settings.xAxis]),
			        	 		rawData[i][self.settings.line1]
		        	 		]);
				        }	
				    
					    // console.log(rows);
					    tempRows = tempRows.sort(ForceSortWK);
						// console.log('sorted');
						rows = rows.concat(tempRows);

						// console.log(rows);

						function ForceSortWK(a, b) {

						    if (a[0] < b[0]){
						    	// console.log('less');
						   		return -1;
						   	}
						    if (a[0] > b[0]){
						    	// console.log('greater');
						    	return 1;
						    }
						    // console.log('equal');
						    return 0;
						}

				        // console.log(rows);
					    var data = google.visualization.arrayToDataTable(rows);

					    // google.visualization.events.addListener(chart, 'select', showHideSeries);
				       	var chart = new google.visualization.ChartWrapper({
				            chartType: 'LineChart',
				            containerId: self.settings.elementId,
				            dataTable: data,
				            options: self.settings.options
				        });

				       	chart.setOption('series', self.settings.options.series);

				       	chart.draw();











					}
		        	
				    
      			};
			}
		}
	); // 

	return GoogleChartStoreMultiline;

})(jQuery);
