//
// Copyright (c) 2014-2015 TIBCO Software Inc. All rights reserved.
//
'use strict';


var GoogleChartTable = (function($){
	/**
	 * This object wraps a straight-forward GoogleChartTable chart. It is meant to be reusable, but is limited in the configuration
	 * options made available. It extends from the Visualization base object which maintains its data model.
	 * @class GoogleChartTable
	 * @param {Object} settings An object containing the parameters used to configure this GoogleChartTable
	 * @param {String} settings.elementId The element ID of the DOM element that this visualization should render in.
	 * @param {String} [settings.categoryField] The field name of the category field in the data model.
	 * @param {String} [settings.valueField] The field name of the value field in the data model.
	 */
	function GoogleChartTable(settings){
		this.schema = {};
		this.data = [];
		this.html = '<div>GoogleChartTable goes here</div>';
		this.settings = settings || {elementId: ''};
		this.settings.categoryField = settings.categoryField || 'category';
		this.settings.valueField = settings.valueField || 'value';
		// if adding more stuff in the app.model.js, add them here as well
		this.viewModel = [];
	}

	GoogleChartTable.prototype = $.extend(
		new Visualization(),
		{
			refresh: function(){
				var i;
				//sync viewModel with data
				this.viewModel = [];
				for(i = 0; i < this.data.length; i++){
					if(this.data[i]){
						this.viewModel.push(this.data[i].fieldMap);
					}
				}
				
				this.render();
			},
			render: function(){
				/*
				var data = this.viewModel,
					self = this;
				*/
				// console.log(data);
				
				var self = this;
      			// Set a callback to run when the Google Visualization API is loaded.
      			google.charts.setOnLoadCallback(drawChart);
				
      			// drawChart() is to guarantee that DataTable() will be loaded before vis is to be drawn
      			function drawChart(){
      				// console.log('draw table');
      				var rawData = self.viewModel,
			        	data = new google.visualization.DataTable(),
			        	rows = [];
			        // console.log(rawData);
			        
			        // this is necssary for render
			        var element = d3.select('#' + self.settings.elementId);
					element.selectAll('svg').remove();
					element.selectAll('*').remove();

					// console.log(rawData);

					// this part has not been made generic enough just yet
					if(self.settings.storyName == 'resSentToBatch'){
						data.addColumn('string', 'Reservation Number');
						data.addColumn('string', 'Partner ID');
						data.addColumn('string', 'Added By App');
						data.addColumn('string', 'Order Status');
						data.addColumn('datetime', 'Batched Time');
						data.addColumn('datetime', 'Last Updated');
						data.addColumn('string', 'Error String');
						// data.addColumn('boolean', 'Create Business Error');
						// data.addColumn('boolean', 'Create Fatal Error');
						// data.addColumn('boolean', 'Complete Business Error');
						// data.addColumn('boolean', 'Complete Fatal Error');
						data.addColumn('string', 'Business Exception');
						data.addColumn('string', 'Fatal Exception');
						data.addColumn('string', 'Splunk Link');
						// data.addColumn('string', 'Stack String');
						// data.addColumn('string', 'BAM Error');



						// console.log('res sent to batch');
						for(var i=0; i < rawData.length; i++){
				        	rows.push([rawData[i]['ResNum'], 
				        		       rawData[i]['PartnerID'],
				        		       rawData[i]['addedByApp'],
				        		       rawData[i]['orderStatus'],
				        		       new Date(rawData[i]['toBatchTimeStamp']),
				        		       new Date(rawData[i]['lastUpdateTimeStamp']),
				        		       rawData[i]['errorStringIFSCap'],
				        		       // rawData[i]['CreateBE'],
				        		       // rawData[i]['CreateFE'],
				        		       // rawData[i]['CompleteBE'],
				        		       // rawData[i]['CompleteFE'], 
				        		       rawData[i]['BEString'],
				        		       rawData[i]['FEString'],
				        		       rawData[i]['SPLUNK_link'],
				        		       // rawData[i]['stackString'],
				        		       // rawData[i]['BAMError']
				        		       ]);

				        
				        }

					}
					else{
						data.addColumn('datetime', self.settings.field1Name);
			        	data.addColumn('string', self.settings.field2Name);
			        	for(var i=0; i < rawData.length; i++){
				        	rows.push([new Date(rawData[i][self.settings.field1]), rawData[i][self.settings.field2]]);
				        	//console.log([rawData[i][self.settings.categoryField], rawData[i][self.settings.valueField]]);
				        }
					}
			        // console.log(rows);
			        data.addRows(rows);
			        // console.log('rows: ' + rows.length);
			        // console.log(rows);

			        // Set chart options
			        
			        // Instantiate and draw our chart, passing in some options.
			        var chart = new google.visualization.Table(document.getElementById(self.settings.elementId));
			        chart.draw(data, {allowHtml: true, showRowNumber: false, width: '100%', height: '100%'});	




			        //if(self.settings.storyName == 'resSentToBatch'){
			        	


			        	//var selectHandler = function(e) {
				        	//open(data.getValue(chart.getSelection()[0]['row'], 8)); // 9 means the 9th column, which is the link in this case
				        	//self.render(); // this is necessary for one of the mysterious bug
				        				   // 
				        //}

				        // Add our selection handler.
				        //google.visualization.events.addListener(chart, 'select', selectHandler);










			        	/*
			        	google.visualization.events.addListener(chart, 'select', selectHandler);
			        	function selectHandler() {
			        		var str;
							var selection = chart.getSelection();
						 	var message = '';
							for (var i = 0; i < selection.length; i++) {
						    	
						    	var item = selection[i];
						    	if (item.row != null && item.column != null) {
						     		var str = data.getFormattedValue(item.row, item.column);
						     		console.log('row: ' + item.row), ', column: ' + item.column;
						      		message += '{row:' + item.row + ',column:' + item.column + '} = ' + str + '\n';
							    } else if (item.row != null) {
							      	var str = data.getFormattedValue(item.row, 0); // the number here means the xth column, starting from 0
							      	message += '{row:' + item.row + ', column:none}; value (col 0) = ' + str + '\n';
							    } else if (item.column != null) {
							      	var str = data.getFormattedValue(0, item.column);
							      	message += '{row:none, column:' + item.column + '}; value (row 0) = ' + str + '\n';
							    }

							    console.log(message);
							    
							}
							if (message == '') {
						    	message = 'nothing';
						  	}
						  	alert(message);
						    window.open("http://localhost:10080/dashboard/pages/Batched_Triaged/Batched_Triaged.html?resnum=" + str);
						}
						*/
			       // }

			        
      			};
			}
		}
	);

	return GoogleChartTable;

})(jQuery);
