/**
 * This variable provides the model data for our application. All that's needed to alter what pages exist in the
 * dashboard, what sections exist in each page, what components are shown in each section, what visualization to
 * display in each component, or what query to use as the data source for a component is to modify this object.
 */
var appModel = {
	pages: {
		defaultPage: {
			name: 'CICS Monitoring',
			title: 'CICS',
			sections:[
				{
					components: [
						{
							query: 'SELECT * from CICS_Summary_Full WHERE SYS_ID="C101" ORDER BY REGION LIMIT 20', // where SYS_ID = and where REGION...etc
							visualizationType: 'pie',
							visualizationConfig: {
								title: 'C101',
								categoryField: 'REGION',
								valueField: 'CPU_TIME',
								legend: {
									align: 'right',
									verticalAlign: 'middle',
									layout: 'vertical'
								}
							},
							colSpan: 4,
							height: 400
						},
						{
							query: 'SELECT * from CICS_Summary_Full WHERE SYS_ID="C104" ORDER BY REGION LIMIT 20',
							visualizationType: 'pie',
							visualizationConfig: {
								title: 'C104',
								categoryField: 'REGION',
								valueField: 'CPU_TIME',
								legend: {
									align: 'right',
									verticalAlign: 'middle',
									layout: 'vertical'
								}
							},
							colSpan: 4,
							height: 400
						}
						// below is for testing
						/*
						{
							query: 'SELECT * FROM Summary_C101 WHERE SYS_ID = "C101"', // where SYS_ID = and where REGION...etc
							visualizationType: 'bubbles',
							visualizationConfig: {
								title: 'BUBBLE VIEW TEST',
								categoryField: 'REGION',
								valueField: 'CPU_TIME',
								legend: {
									align: 'right',
									verticalAlign: 'middle',
									layout: 'vertical'
								}
							},
							colSpan: 4,
							height: 400
						},
						{
							query: 'SELECT * FROM Summary_C104 WHERE SYS_ID = "C104"', // where SYS_ID = and where REGION...etc
							visualizationType: 'bubbles',
							visualizationConfig: {
								title: 'BUBBLE VIEW TEST',
								categoryField: 'REGION',
								valueField: 'CPU_TIME',
								legend: {
									align: 'right',
									verticalAlign: 'middle',
									layout: 'vertical'
								}
							},
							colSpan: 4,
							height: 400
						}
						*/
					]
				}
			]
		}
	}
};
