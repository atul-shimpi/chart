var hostlink = 'localhost';
// var hostlink = 'ln001xsbam0001';
// var hostlink = '11.48.169.243';

