//
// Copyright (c) 2014-2015 TIBCO Software Inc. All rights reserved.
//
'use strict';
var ServerHardware = (function($){

	/**
	 * This object wraps a straight-forward ServerHardware chart. It is meant to be reusable, but is limited in the configuration
	 * options made available. It extends from the Visualization base object which maintains its data model.
	 * @class ServerHardware
	 * @param {Object} settings An object containing the parameters used to configure this ServerHardware
	 * @param {String} settings.elementId The element ID of the DOM element that this visualization should render in.
	 * @param {String} [settings.categoryField] The field name of the category field in the data model.
	 * @param {String} [settings.valueField] The field name of the value field in the data model.
	 */
	function ServerHardware(settings){
		this.schema = {};
		this.data = [];
		this.html = '<div>ServerHardware goes here</div>';
		this.settings = settings || {elementId: ''};
		this.settings.categoryField = settings.categoryField || 'category';
		this.settings.valueField = settings.valueField || 'value';
		// if adding more stuff in the app.model.js, add them here as well
		this.viewModel = [];
	}

	ServerHardware.prototype = $.extend(
		new Visualization(),
		{
			refresh: function(){
				var i;
				//sync viewModel with data
				this.viewModel = [];
				for(i = 0; i < this.data.length; i++){
					if(this.data[i]){
						this.viewModel.push(this.data[i].fieldMap);
					}
				}
				this.render();
			},
			render: function(){
				//console.log('Rendering ServerHardware to ' + this.settings.elementId);
				var data = this.viewModel,
				
				self = this;
				// console.log("in ServerHardware.js");
				// console.log(data);
				
				// default color to avoid warning
				var finalColor = 'Green';

				for(var i = 0; i < data.length; i++){
					// console.log('check high level color');
					if(data[i].Status == 'Red'){
						finalColor = 'Red';
						break;
					}
					else if(data[i].Status == 'Yellow'){
						finalColor = 'Yellow';
						break;
					}
					else{
						finalColor = 'Green';
					}
				}

				// console.log(finalColor);

				

				var element = d3.select('#' + this.settings.elementId);
				element.selectAll('.' + self.settings.class + 'svg').remove();
				// element.selectAll('a').remove();
				

				var svg = element.append('svg')
					.attr('width', 107)
					.attr('height', 120)
					//.attr('height', 720)
					.attr('class', self.settings.class + 'svg')
					.attr('text-anchor', 'middle');

				// console.log(finalColor);
				/*
				svg.selectAll('.imageL')
					.data(finalColor)
					.enter()*/
				svg.append('a')
				    .attr('href', function(d, i){

				    	if(self.settings.elementId == 'webiis'){
							return 'http://' + hostlink + ':10080/dashboard/pages/Store_Fulfillment_Servers_Hardware/Store_Fulfillment_Servers.html';
						}
						else if(self.settings.elementId == 'webreporting'){
							return 'http://' + hostlink + ':10080/dashboard/pages/Store_Fulfillment_Servers_Reporting_Hardware/Store_Fulfillment_Servers_Reporting.html';
						}
						else if(self.settings.elementId == 'pipeline'){
							return 'http://' + hostlink + ':10080/dashboard/pages/Store_Fulfillment_Servers_Pipeline_Hardware/Store_Fulfillment_Servers_Pipeline.html';
						}
						else{
							return 'https://google.com';
						}
				    })
				    .attr('id', self.settings.class + 'href')
				  .append('image')
					.attr('href', function(d, i){
						
						if(finalColor == 'Red'){
							return redImagePath;
						}
						else if(finalColor == 'Yellow'){
							return yellowImagePath;
						}
						else if(finalColor == 'Blue'){
							return blueImagePath;
						}
						else{
							return greenImagePath;
						}
					})
					.attr('x', -5)
					.attr('y', 1)
					.attr('height', 110)
					.attr('width', 120)
					.attr('text-anchor', 'middle')
					.on('mouseover', function(d){
					
						d3.select(this).style('cursor', 'pointer');
						
				    	
				    	// console.log('hoverover');
				    })
				    .on('mouseout', function(d){
				    	d3.select(this).style('cursor', 'default');

				    	
				    });/*
					.on('click', function(){
						if(self.settings.elementId == 'webiis'){
							open('http://' + hostlink + ':10080/dashboard/pages/Store_Fulfillment_Servers_Hardware/Store_Fulfillment_Servers.html');
						}
						else if(self.settings.elementId == 'webreporting'){
							open('http://' + hostlink + ':10080/dashboard/pages/Store_Fulfillment_Servers_Reporting_Hardware/Store_Fulfillment_Servers_Reporting.html');
						}
						else if(self.settings.elementId == 'pipeline'){
							open('http://' + hostlink + ':10080/dashboard/pages/Store_Fulfillment_Servers_Pipeline_Hardware/Store_Fulfillment_Servers_Pipeline.html');
						}
						else{
							open('https://google.com');
						}
						
					});*/

					


			}
		}
	);

	return ServerHardware;

})(jQuery);
