//
// Copyright (c) 2014-2015 TIBCO Software Inc. All rights reserved.
//
'use strict';
var WMSBubbleTitle = (function($){

	/**
	 * This object wraps a straight-forward WMSBubbleTitle chart. It is meant to be reusable, but is limited in the configuration
	 * options made available. It extends from the Visualization base object which maintains its data model.
	 * @class WMSBubbleTitle
	 * @param {Object} settings An object containing the parameters used to configure this WMSBubbleTitle
	 * @param {String} settings.elementId The element ID of the DOM element that this visualization should render in.
	 * @param {String} [settings.categoryField] The field name of the category field in the data model.
	 * @param {String} [settings.valueField] The field name of the value field in the data model.
	 */
	function WMSBubbleTitle(settings){
		this.schema = {};
		this.data = [];
		this.html = '<div>WMSBubbleTitle goes here</div>';
		this.settings = settings || {elementId: ''};
		this.settings.categoryField = settings.categoryField || 'category';
		this.settings.valueField = settings.valueField || 'value';
		// if adding more stuff in the app.model.js, add them here as well
		this.viewModel = [];
	}

	WMSBubbleTitle.prototype = $.extend(
		new Visualization(),
		{
			refresh: function(){
				var i;
				//sync viewModel with data
				this.viewModel = [];
				for(i = 0; i < this.data.length; i++){
					if(this.data[i]){
						this.viewModel.push(this.data[i].fieldMap);
					}
				}
				this.render();
			},
			render: function(){
				//console.log('Rendering WMSBubbleTitle to ' + this.settings.elementId);
				var data = this.viewModel,
				
				self = this,
				height = data.length * 90;
				

				// console.log(data);
				// console.log(data);

				//element = d3.select('#' + this.settings.elementId),
				
				// console.log(data);

				// all size related code should be determined somehow by:
				// svgWidth for width, y
				// svgHeight for height, x
				
				var element = d3.select('#' + this.settings.elementId);
				element.selectAll('svg').remove();

				var svg = element.append('svg')
					.attr('width', 170)
					.attr('height', data.length * 100)
					//.attr('height', 720)
					.attr('class', self.settings.class);

				


				svg.selectAll('.bubbleTitle')
					.data(data)
					.enter()
				  .append('text')
					.attr('class', 'bubbleTitle')
					.attr('display', 'inline-block')
					.attr('width', '50px')
					.attr('x', 2)
					.attr('y', function(d, i){
						return (i+0.6)*97;
					})
					.text(function(d, i){
						return d[self.settings.categoryField];
					})
					.attr('font-size', 11)
					.attr('font-family', 'Times New Roman')
					.attr('fill', 'white');
					
					//.attr('text-anchor', 'middle')






				svg.selectAll('.' + this.settings.class + 'borderline')
					.data(data)
					.enter()
				  .append('line')
					.attr('class', this.settings.class + 'borderline')
					.attr('x1', 0)
					.attr('x2', 170)
					.attr('y1', function(d, i){
						return (i+1)*97;
						
					})
					.attr('y2', function(d, i){
						return (i+1)*97;
						
					})
					.attr('stroke', 'grey')
					.attr('stroke-width', 2);

				
				
			}
		}
	);

	return WMSBubbleTitle;

})(jQuery);
