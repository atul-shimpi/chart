//
// Copyright (c) 2014-2015 TIBCO Software Inc. All rights reserved.
//
'use strict';
var ServersMonitoring = (function($){

	/**
	 * This object wraps a straight-forward ServersMonitoring chart. It is meant to be reusable, but is limited in the configuration
	 * options made available. It extends from the Visualization base object which maintains its data model.
	 * @class ServersMonitoring
	 * @param {Object} settings An object containing the parameters used to configure this ServersMonitoring
	 * @param {String} settings.elementId The element ID of the DOM element that this visualization should render in.
	 * @param {String} [settings.categoryField] The field name of the category field in the data model.
	 * @param {String} [settings.valueField] The field name of the value field in the data model.
	 */
	function ServersMonitoring(settings){
		this.schema = {};
		this.data = [];
		this.html = '<div>ServersMonitoring goes here</div>';
		this.settings = settings || {elementId: ''};
		this.settings.categoryField = settings.categoryField || 'category';
		this.settings.valueField = settings.valueField || 'value';
		// if adding more stuff in the app.model.js, add them here as well
		this.viewModel = [];
	}

	ServersMonitoring.prototype = $.extend(
		new Visualization(),
		{
			refresh: function(){
				var i;
				//sync viewModel with data
				this.viewModel = [];
				for(i = 0; i < this.data.length; i++){
					if(this.data[i]){
						this.viewModel.push(this.data[i].fieldMap);
					}
				}
				this.render();
			},
			render: function(){
				//console.log('Rendering ServersMonitoring to ' + this.settings.elementId);

				var data = this.viewModel,
				self = this,
				width = 107,
				height = 140,
				radius = width / 3;

				// console.log(data);
				// console.log(self.settings.storyName);
				

				var element = d3.select('#' + this.settings.elementId);
				element.selectAll('.' + self.settings.class + 'svg').remove();

				var svg = element.append('svg')
					.attr('width', width)
					.attr('height', height)
					//.attr('height', 720)
					.attr('class', self.settings.class + 'svg')
					.attr('text-anchor', 'middle');


				var red = 0;
				var yellow = 0;
				var blue = 0;
				var green = 0;	

				if(self.settings.storyName == 'storeMonitor' || self.settings.storyName == 'application' || self.settings.storyName == 'storedatabase'){
					
					
					for(var i = 0; i < this.viewModel.length; i++){
						if(this.viewModel[i].color == 'Red'){
							// red++;
							red = this.viewModel[i].cnt;
						}
						else if(this.viewModel[i].color == 'Yellow'){
							// yellow++;
							yellow = this.viewModel[i].cnt;
						}
						else if(this.viewModel[i].color == 'Blue'){
							// green++;
							blue = this.viewModel[i].cnt;
						}
						else if(this.viewModel[i].color == 'Green'){
							// green++;
							green = this.viewModel[i].cnt;
						}
					}
					self.viewModel = [{color: 'BLUE', CNT: blue},{color: 'RED', CNT: red}, {color: 'YELLOW', CNT: yellow}, {color: 'GREEN', CNT: green}];
					
				}


				// console.log(self.viewModel);


				// color = d3.scale.category20().range(randomColors);
				var color = d3.scale.category20();
				var arc = d3.svg.arc()
					.outerRadius(radius)
					.innerRadius(0);
				var sortEnable = function(a, b){
					return a - b;
				};
				
				var pie = d3.layout.pie()
					.sort(null)
					.value(function(d){
						return d['CNT'];
					});

				element.selectAll('svg').remove();
				var svg = element
					.append('svg')
					.attr('width', width)  // add 150 pixel for legend space
					.attr('height', height)
					.append('g')
					.attr('transform', 'translate(' + width / 2 + ',' + height / 3.7 + ')');

				var g = svg.selectAll('.arc')
					.data(pie(this.viewModel))
					.enter()
					.append('g')
					.attr('class', 'arc');

				g.append('path')
					.attr('d', arc)
					.style('fill', function(d){
						return colorMapperBubble(d.data['color']);
					})
					.attr('stroke', 'white')
					.attr('stroke-width', 1)
					.attr('stroke-linejoin', 'round');

				if(self.settings.storyName == 'storeMonitor'){
					// console.log('sorting pie');
					self.viewModel.sort(function(a, b){
						if(a.color == "Red"){
							return -1;
						}
						else if(a.color == "Yellow" && b.color != "Red"){
							return -1;
						}
						else{
							return 1;
						}
					});
				}	


				svg.selectAll('.rect')
					.data(pie(self.viewModel))
					.enter()
					.append('rect')
					.attr('width', 20)
					.attr('height', 10)
					.attr('x', -45)
					.attr('y', function(d, i){
						return (i+4)*12;
					})
					.attr('fill', function(d, i){
						return colorMapperBubble(d.data['color']);
					})
					.attr('rx', 10)
					.attr('ry', 10);
				// text
				
				
				

				svg.selectAll('.text')
					.data(pie(this.viewModel))
					.enter()
					.append('text')
					.attr('x', 9)
					.attr('y', function(d, i){
						return (i+4.7)*12;
					})
					.attr('fill', function(d, i){
						return color(d.data[self.settings.categoryField]);
					})
					.text(function(d){
						return "" + labelMapper(d.data['color']) + ": " + d.data['CNT'];
					})
					.attr('text-anchor', 'middle')
					.attr('font-size', 9);

				svg.append('a')
					.attr('href', function(d, i){
						if(self.settings.storyName == 'application'){

							if(self.settings.app == 'fulfillment'){
							    return 'http://' + hostlink + ':10080/dashboard/pages/Store_Fulfillment_Servers/Store_Fulfillment_Servers.html';
							}
							else if(self.settings.app == 'ssrs'){
								return 'http://' + hostlink + ':10080/dashboard/pages/Store_Fulfillment_Servers_Reporting/Store_Fulfillment_Servers_Reporting.html';
							}
							else if(self.settings.app == 'pipeline'){
								return 'http://' + hostlink + ':10080/dashboard/pages/Store_Fulfillment_Servers_Pipeline/Store_Fulfillment_Servers_Pipeline.html';
							}	
							else{
								return 'http://mymacys.net/sites/MBI/SitePages/index.html';
							}

						}
						else if(self.settings.storyName == 'storedatabase'){
							// work on the link here soooooon
						
							return 'http://' + hostlink + ':10080/dashboard/pages/Store_Database_L2/Store_Database_L2.html';
						}
						else{
							return 'http://' + hostlink + ':10080/dashboard/pages/Store_Fulfillment_WebSites/Store_Fulfillment_WebSites.html?server=' + self.settings.server;
						}
					})
				  .append('text')
					.attr('x', 0)
					.attr('y', 10)
					.attr('opacity', 0)
					.text('click')
					.attr('text-anchor', 'middle')
					.attr('font-size', 35)
					.on('mouseover', function(d){
						
						d3.select(this).style('cursor', 'pointer');
						
				    	
				    	// console.log('hoverover');
				    })
				    .on('mouseout', function(d){
				    	
						d3.select(this).style('cursor', 'default');
						

				    	
				    });/*
					.on('click', function(d, i){
						var lk = 'http://mymacys.net/sites/MBI/SitePages/index.html';
						if(self.settings.storyName == 'application'){

							if(self.settings.app == 'fulfillment'){
							    open('http://' + hostlink + ':10080/dashboard/pages/Store_Fulfillment_Servers/Store_Fulfillment_Servers.html');
							}
							else if(self.settings.app == 'ssrs'){
								open('http://' + hostlink + ':10080/dashboard/pages/Store_Fulfillment_Servers_Reporting/Store_Fulfillment_Servers_Reporting.html');
							}
							else if(self.settings.app == 'pipeline'){
								open('http://' + hostlink + ':10080/dashboard/pages/Store_Fulfillment_Servers_Pipeline/Store_Fulfillment_Servers_Pipeline.html');
							}	
							else{
								open('http://mymacys.net/sites/MBI/SitePages/index.html');
							}

						}
						else{
							open('http://' + hostlink + ':10080/dashboard/pages/Store_Fulfillment_WebSites/Store_Fulfillment_WebSites.html?server=' + self.settings.server);
						}
					});*/
				
				/*
				var labelTextX = 70;
				var labelWidth = 30;

			


				// append count by color
				svg.append('rect')
					.attr('width', labelWidth)
					.attr('height', 20)
					.attr('x', 5)
					.attr('y', 35)
					.attr('fill', function(d, i){
						return colorMapperBubble('RED');
					})
					.attr('rx', 10)
					.attr('ry', 10);
				
				svg.append('rect')
					.attr('width', labelWidth)
					.attr('height', 20)
					.attr('x', 5)
					.attr('y', 60)
					.attr('fill', function(d, i){
						return colorMapperBubble('YELLOW');
					})
					.attr('rx', 10)
					.attr('ry', 10);

				svg.append('rect')
					.attr('width', labelWidth)
					.attr('height', 20)
					.attr('x', 5)
					.attr('y', 85)
					.attr('fill', function(d, i){
						return colorMapperBubble('GREEN');
					})
					.attr('rx', 10)
					.attr('ry', 10);


				svg.append('text')
					.attr('x', labelTextX)
					.attr('y', 50)
					.text('Critical:' + red)
					.attr('text-anchor', 'left')
					.attr('font-size', 11);	

				svg.append('text')
					.attr('x', labelTextX)
					.attr('y', 75)
					.text('Moderate:' + yellow)
					.attr('text-anchor', 'left')
					.attr('font-size', 11);
					
				svg.append('text')
					.attr('x', labelTextX)
					.attr('y', 100)
					.text('Acceptable:' + green)
					.attr('text-anchor', 'left')
					.attr('font-size', 11);

				*/


				// svg obtained
				/*
				svg.selectAll('.serverImages')
					.data(data)
					.enter()
					.append('image')
					.attr('href', function(d, i){
						//'../imgclearBubbleTest1.jpg')
						console.log(d[self.settings.color]);
						if(d[self.settings.color] == 'RED'){
							return self.settings.redImagePath;
						}
						else if(d[self.settings.color] == 'YELLOW'){
							return self.settings.yellowImagePath;
						}
						else{
							return self.settings.greenImagePath;
						}
					})
					.attr('x', function(d, i){
						
						return (i + 0.3)*95;
					})
					.attr('y', function(d, i){
						return 10;
					})
					.attr('height', 70)
					.attr('width', 90)
					.attr('text-anchor', 'middle')
					.on('click', function(d, i){
						open('https://www.google.com');
					});

				// the label 
				// this will change based on what field to use
				svg.selectAll('.' + this.settings.class + 'Text')
					.data(data)
					.enter()
					.append('text')
					.attr('class', this.settings.class + 'Text')
					.attr('x', function(d, i){
						return (i + 0.8)*95;
					})
					.attr('y', function(d, i){
						return 95;
						
					})
					.text(function(d, i){
						return d[self.settings.titleField];
					})
					.attr('font-size', 11)
					.attr('font-family', "Times New Roman")
					.attr('fill', 'white')
					.attr('text-anchor', 'middle');
				*/
			}
		}
	);

	return ServersMonitoring;

})(jQuery);
