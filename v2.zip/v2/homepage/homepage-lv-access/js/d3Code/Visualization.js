'use strict';
var Visualization = (function($){

	/**
	 * This is the base object for the visualizations in the sample. Its primary purpose is to maintain the data model
	 * for the visualization (i.e. handle the adding, updating, and deleting of tuples). The child visualization will
	 * likely have to transform the model somewhat into a format more appropriate for the visualization. Direct
	 * instantiation of this object should be avoided. Instead, create an instance of the appropriate child object.
	 * @class Visualization
	 * @param {Object} settings Contains the settings for this visualization.
	 * @param {String} settings.elementId The element ID of the DOM element that this visualization should render in.
	 */
	function Visualization(settings){
		this.schema = {};
		this.data = [];
		this.settings = settings || {};
		this.settings.elementId = this.settings.elementId || '';
		this.html = '<div>Visualization goes here</div>';
	}
	Visualization.prototype = {
		constructor: Visualization,
		setSchema: function(value){
			this.schema = value;
		},
		setData: function(value){
			this.data = value;
		},
		addTuple: function(tuple){
			this.data.push(tuple);
		},
		updateTuple: function(tuple){
			var fieldName, i;
			for(i = 0; i < this.data.length; i++){
				if(this.data[i].id === tuple.id){
					for(fieldName in tuple.fieldMap){
						if(tuple.fieldMap.hasOwnProperty(fieldName)){
							this.data[i].fieldMap[fieldName] = tuple.fieldMap[fieldName];
						}
					}
				}
			}
		},
		deleteTuple: function(tuple){
			var i;
			for(i = 0; i < this.data.length; i++){
				if(this.data[i].id === tuple.id){
					this.data.splice(i, 1);
					break;
				}
			}
		},
		render: function(elementId){
			elementId = elementId || this.settings.elementId || '';
			var element = $('#' + elementId);
			if(element){
				element.html(this.html);
			}
		},
		refresh: function(){
			console.log('Visualization.refresh - Should be implemented by the child object');
		},
		clear: function(){
			this.schema = {};
			this.data = [];
			this.refresh();
		}
	};

	return Visualization;
})(jQuery);