//
// Copyright (c) 2014-2015 TIBCO Software Inc. All rights reserved.
//
'use strict';
var ALight = (function($){

	/**
	 * This object wraps a straight-forward ALight chart. It is meant to be reusable, but is limited in the configuration
	 * options made available. It extends from the Visualization base object which maintains its data model.
	 * @class ALight
	 * @param {Object} settings An object containing the parameters used to configure this ALight
	 * @param {String} settings.elementId The element ID of the DOM element that this visualization should render in.
	 * @param {String} [settings.categoryField] The field name of the category field in the data model.
	 * @param {String} [settings.valueField] The field name of the value field in the data model.
	 */
	function ALight(settings){
		this.schema = {};
		this.data = [];
		this.html = '<div>ALight goes here</div>';
		this.settings = settings || {elementId: ''};
		this.settings.categoryField = settings.categoryField || 'category';
		this.settings.valueField = settings.valueField || 'value';
		// if adding more stuff in the app.model.js, add them here as well
		this.viewModel = [];
	}

	ALight.prototype = $.extend(
		new Visualization(),
		{
			refresh: function(){
				var i;
				//sync viewModel with data
				this.viewModel = [];
				for(i = 0; i < this.data.length; i++){
					if(this.data[i]){
						this.viewModel.push(this.data[i].fieldMap);
					}
				}
				this.render();
			},
			render: function(){
				//console.log('Rendering ALight to ' + this.settings.elementId);
				var data = this.viewModel,
				
				self = this,
				height = data.length * 90,
				rds = 55;

				// console.log(data);
				// console.log(data);

				//element = d3.select('#' + this.settings.elementId),
				
				// console.log(data);

				// all size related code should be determined somehow by:
				// svgWidth for width, y
				// svgHeight for height, x
				
				var element = d3.select('#' + this.settings.elementId);
				element.selectAll('svg').remove();

				var svg = element.append('svg')
					.attr('width', rds * 2)
					.attr('height', rds * 2)
					//.attr('height', 720)
					.attr('class', self.settings.class);

			


				


				
				svg.selectAll('.' + this.settings.class + 'ALight')
					.data(data)
					.enter()
					.append('circle')
					/*.on('mouseover', function(d, i){
						div.transition()
							.duration(200)
							.style('opacity', .9);
						div.html('the ' + i + 'th circle')
							.style('left', (d3.event.pageX) + "px")
							.style('top', (d3.event.pageY - 20) + "px");
					})
					.on('mouseout', function(d){
						div.transition()
							.duration(500)
							.style('opacity', 0);
					})*/
					.attr('class', this.settings.class + 'ALight')
					.attr('fill', function(d, i){
						return colorMapperBubble(d[self.settings.color]);
						//return 'green';
					})
					.attr('cx', function(d, i){
						return rds;
						
					})
					.attr('cy', function(d, i){
						return rds;
					})
					.attr('r', rds - 5)
					.attr('stroke-width', 3)
					.attr('stroke', 'black')
					.attr('opacity', .8);
				


				svg.selectAll('.' + this.settings.class + 'label') // the value in the middle of the bubble
					.data(data)
					.enter()
					.append('text')
					.attr('class', this.settings.class + 'label')
					.attr('x', rds)
					.attr('y', function(d, i){
						return rds - 15;
					})
					.text(function(d, i){
						return '' + d[self.settings.label] + ' Min';
					})
					.attr('font-size', rds-40)
					.attr('font-family', "Times New Roman")
					.attr('fill', 'black')
					.attr('text-anchor', 'middle');

				svg.selectAll('.' + this.settings.class + 'Text1')
						.data(data)
						.enter()
					  .append('text')
						.attr('class', this.settings.class + 'Text1')
						.attr('x', rds)
						.attr('y', rds)
						.attr('word-wrap', 'break-word')
						.attr('width', 110)
						.attr('white-space', 'pre')
						.text('Last Updated:')
						.attr('font-size', 12)
						.attr('font-family', "Times New Roman")
						.attr('fill', 'black')
						.attr('text-anchor', 'middle');

				svg.selectAll('.' + this.settings.class + 'ts1') // the value in the middle of the bubble
					.data(data)
					.enter()
					.append('text')
					.attr('class', this.settings.class + 'ts1')
					.attr('x', rds)
					.attr('y', function(d, i){
						return rds + 10;
					})
					.text(function(d, i){
						return '' + (new Date(d['dtStamp'])).toString().substring(4, 16);
					})
					.attr('font-size', rds-45)
					.attr('font-family', "Times New Roman")
					.attr('fill', 'black')
					.attr('text-anchor', 'middle');

				svg.selectAll('.' + this.settings.class + 'ts2') // the value in the middle of the bubble
					.data(data)
					.enter()
					.append('text')
					.attr('class', this.settings.class + 'ts2')
					.attr('x', rds)
					.attr('y', function(d, i){
						return rds + 20;
					})
					.text(function(d, i){
						return '' + (new Date(d['dtStamp'])).toString().substring(16, 25);
					})
					.attr('font-size', rds-45)
					.attr('font-family', "Times New Roman")
					.attr('fill', 'black')
					.attr('text-anchor', 'middle');



				// add link based on story
				// console.log(self.settings.storyName);

				if(self.settings.storyName == 'storeWorkLoadLagLive'){
					svg.selectAll('.' + this.settings.class + 'clickT') // the value in the middle of the bubble
						.data(data)
						.enter()
					  .append('a')
					    .attr('href', function(d, i){
					    	return 'http://' + hostlink + ':10080/dashboard/pages/Store_Workload_Lag_Trend/Store_Workload_Lag_Trend.html';
					    })
					  .append('text')
						.attr('class', this.settings.class + 'clickT')
						.attr('x', rds)
						.attr('y', 80)
						.text('O')
						.attr('font-size', 80)
						.attr('font-family', "Times New Roman")
						.attr('fill', 'black')
						.attr('text-anchor', 'middle')
						.attr('opacity', 0)
						.on('mouseover', function(d){
							d3.select(this).style('cursor', 'pointer');	
					    })
					    .on('mouseout', function(d){
					    	d3.select(this).style('cursor', 'default');
					    });
				}
				
				
			}
		}
	);

	return ALight;

})(jQuery);
