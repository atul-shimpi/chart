//
// Copyright (c) 2014-2015 TIBCO Software Inc. All rights reserved.
//
'use strict';
var Table = (function($){

	/**
	 * An HTML table. This is obviously not an optimal way to maintain values in a table as it recreates the table on
	 * every update. Inclusion of this Table object in your project should be done with caution.
	 * @class Table
	 * @param {Object} settings An object containing the parameters used to configure this Table
	 * @param {String} settings.elementId The element ID of the DOM element that this visualization should render in.
	 * @param {Object} [settings.headerNameMap] Object that maps header ID to header Title like avgMonthyIncome: 'Average Monthly Income'
	 * @param {Function} [settings.valueFormatter] Function to invoke if custom formatting is desired for values in the Table. The function will be invoked with parameters: fieldName and fieldValue. A string value is expected to be returned by the function. That value will be displayed as the value for the field.
	 * @param {Number} [settings.maxRows] Limits the number of rows to display in the table. The default is undefined, resulting in no limit.
	 */
	function Table(settings){
		this.schema = {};
		this.data = [];
		this.html = '<div>Table goes here</div>';
		this.settings = settings || {};
		this.settings.headerTitleMap = settings.headerTitleMap || {};
		this.settings.valueFormatter = settings.valueFormatter || function(fieldName, fieldValue){ return fieldValue; };
		this.settings.maxRows = settings.maxRows || Number.MAX_VALUE;
	}

	Table.prototype = $.extend(
		new Visualization(),
		{
			constructor: Table,

			//overridden to put new data at the top of the list and enforce maxRows
			addTuple: function(tuple){
				while(this.data.length >= this.settings.maxRows){
					this.data.pop();
				}
				this.data.splice(0, 0, tuple);
				this.refresh();
			},

			refresh: function(){
				this.html = '<table>' +
					this.buildTableHead() +
					'<tbody>' +
					this.buildTableRows() +
					'</tbody>' +
					'</table>';
				this.render();
			},

			buildTableHead: function(schema){
				var fields, field, fieldIndex,
					tableHeadHtml = '<thead><tr>';

				schema = schema || this.schema || {};
				if($.isEmptyObject(schema)){
					console.warn('Schema not ready yet. Can\'t build table header...');
				}
				else{
					fields = schema.fields;
					for(fieldIndex = 0; fieldIndex < fields.length; ++fieldIndex){
						field = fields[fieldIndex];
						tableHeadHtml += '<th>' + (this.settings.headerTitleMap[field.name] || field.name) + '</th>';
					}
				}
				return tableHeadHtml + '</thead></tr>';
			},

			buildTableRows: function(schema, data){
				var i, fields, field, fieldIndex, value, rowData,
					tableRowHtml = '';

				data = data || this.data || [];
				schema = schema || this.schema || {};
				if($.isEmptyObject(schema)){
					console.warn('Schema not ready yet. Can\'t build table row...');
					return '';
				}

				fields = schema.fields;
				for(i = 0; i < data.length; i++){
					tableRowHtml += '<tr>';
					if(data[i]){
						rowData = data[i].fieldMap;
						for(fieldIndex = 0; fieldIndex < fields.length; fieldIndex++){
							field = fields[fieldIndex];
							value = this.settings.valueFormatter(field.name, rowData[field.name]);
							tableRowHtml += '<td>' + value + '</td>';
						}
						tableRowHtml += '</tr>';
					}
				}
				return tableRowHtml;
			}

		}
	);

	return Table;
})(jQuery);
