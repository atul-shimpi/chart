//
// Copyright (c) 2014-2015 TIBCO Software Inc. All rights reserved.
//
'use strict';
var Circles = (function($){

	/**
	 * This object wraps a straight-forward Circles chart. It is meant to be reusable, but is limited in the configuration
	 * options made available. It extends from the Visualization base object which maintains its data model.
	 * @class Circles
	 * @param {Object} settings An object containing the parameters used to configure this Circles
	 * @param {String} settings.elementId The element ID of the DOM element that this visualization should render in.
	 * @param {String} [settings.categoryField] The field name of the category field in the data model.
	 * @param {String} [settings.valueField] The field name of the value field in the data model.
	 */
	function Circles(settings){
		this.schema = {};
		this.data = [];
		this.html = '<div>Circles goes here</div>';
		this.settings = settings || {elementId: ''};
		this.settings.categoryField = settings.categoryField || 'category';
		this.settings.valueField = settings.valueField || 'value';
		// if adding more stuff in the app.model.js, add them here as well
		this.viewModel = [];
	}

	Circles.prototype = $.extend(
		new Visualization(),
		{
			refresh: function(){
				var i;
				//sync viewModel with data
				this.viewModel = [];
				for(i = 0; i < this.data.length; i++){
					if(this.data[i]){
						this.viewModel.push(this.data[i].fieldMap);
					}
				}
				this.render();
			},
			render: function(){
				//console.log('Rendering Circles to ' + this.settings.elementId);
				var data = this.viewModel,
				
				self = this,
				height = data.length * 90;
				

				// console.log(data);
				// console.log(data);

				//element = d3.select('#' + this.settings.elementId),
				
				// console.log(data);

				// all size related code should be determined somehow by:
				// svgWidth for width, y
				// svgHeight for height, x
				
				var element = d3.select('#' + this.settings.elementId);
				element.selectAll('svg').remove();

				var xp = 99;

				var svg = element.append('svg')
					.attr('width', 196)
					.attr('height', function(){
						if(self.settings.elementId == 'cheshire'){
							return (data.length + 2) * 100;
						}
						else{
							return data.length * 100;
						}
						
					})
					//.attr('height', 720)
					.attr('class', self.settings.class);
				/*
				var div = d3.select('body').append('div')
					.attr('class', 'tooltip')
					.style('opacity', 0)
					.style('background-color', 'white');
				*/


				// console.log(colorMapper('hey'));

				var skip = 0;
				/*
				svg.selectAll('.' + this.settings.class + 'Text')
					.data(data)
					.enter()
					.append('text')
					.attr('class', this.settings.class + 'Text')
					.attr('x', 2)
					.attr('y', function(d, i){
						


						if(d['location'] == 'CHESHIRE' && (d['title'] == 'EV Msg Stuck in Failed' || d['title'] == 'Purge failure')){
							skip++;
							return (i+skip+0.1)*97;
						}
						else{
							return (i+skip+0.1)*97;
						}
						
					})
					.text(function(d, i){
						return d[self.settings.categoryField];
					})
					.attr('font-size', 11)
					.attr('font-family', "Times New Roman")
					.attr('fill', 'white');
					//.attr('text-anchor', 'middle')
				*/

				skip = 0;
				svg.selectAll('.' + this.settings.class + 'Circles')
					.data(data)
					.enter()
					.append('circle')
					.attr('class', this.settings.class + 'Circles')
					.attr('fill', function(d, i){
						return colorMapperBubble(d[self.settings.valueField2]);
						//return 'green';
					})
					.attr('cx', function(d, i){
						return xp;
						
					})
					.attr('cy', function(d, i){
						if(d['location'] == 'CHESHIRE' && (d['title'] == 'EV Msg Stuck in Failed' || d['title'] == 'Purge failure')){
							skip++;
							return (i+skip+0.37)*97;
						}
						else{
							return (i+skip+0.37)*97;
						}
						
					})
					.attr('r', 30)
					.attr('stroke-width', 3)
					.attr('stroke', 'black')
					.attr('opacity', .8);
				

				// 	<image xlink:href="firefox.jpg" x="0" y="0" height="50px" width="50px"/>
				// syntax for replacing bubble with image
				/*
				svg.selectAll('.wmsBubbleImage')
					.data(data)
					.enter()
					.append('image')
					.attr('href', 'clearBubbleTest1.jpg')
					.attr('x', function(d, i){
						return 45;
						
					})
					.attr('y', function(d, i){
						return (i+0.6)*70;
					})
					.attr('height', 60)
					.attr('width', 60)
					.attr('text-anchor', 'middle');
				*/
				
				/*
				svg.selectAll('.' + this.settings.class + 'Text')
					.data(data)
					.enter()
					.append('text')
					.attr('class', this.settings.class + 'Text')
					.attr('x', 2)
					.attr('y', function(d, i){
						return (i+0.1)*97;
						
					})
					.text(function(d, i){
						return d[self.settings.categoryField];
					})
					.attr('font-size', 11)
					.attr('font-family', "Times New Roman")
					.attr('fill', 'white');
					//.attr('text-anchor', 'middle')

				*/
				skip = 0;
				svg.selectAll('.' + this.settings.text1 + 'Text')
					.data(data)
					.enter()
					.append('text')
					.attr('class', this.settings.text1 + 'Text')
					.attr('x', 99)
					.attr('y', function(d, i){
					
						if(d['location'] == 'CHESHIRE' && (d['title'] == 'EV Msg Stuck in Failed' || d['title'] == 'Purge failure')){
							skip++;
							return (i+skip+0.82)*97;
						}
						else{
							return (i+skip+0.82)*97;
						}
						
					})
					.text(function(d, i){
						return d[self.settings.text1];
					})
					.attr('font-size', 10.5)
					.attr('font-family', "Times New Roman")
					.attr('fill', 'white')
					.attr('text-anchor', 'middle');
				

				skip = 0;
				svg.selectAll('.' + this.settings.class + 'Text2') // the value in the middle of the bubble
					.data(data)
					.enter()
					.append('text')
					.attr('class', this.settings.class + 'Text2')
					.attr('x', xp)
					.attr('y', function(d, i){
						
						if(d['location'] == 'CHESHIRE' && (d['title'] == 'EV Msg Stuck in Failed' || d['title'] == 'Purge failure')){
							skip++;
							return (i+skip+0.43)*97;
						}
						else{
							return (i+skip+0.43)*97;
						}
					})
					.text(function(d, i){
						return d[self.settings.valueField1];
					})
					.attr('font-size', 15)
					.attr('font-family', "Times New Roman")
					.attr('fill', 'white')
					.attr('text-anchor', 'middle');




				skip = 0;

				var div = d3.select('body').append('div')
					.attr('class', 'tooltip')
					.style('opacity', 0)
					.style('background-color', 'white');

				svg.selectAll('.' + this.settings.class + 'CirclesInvisible')
					.data(data)
					.enter()
					.append('circle')
					.on('mouseover', function(d, i){
						div.transition()
							//.duration(0)
							.style('opacity', .9);
						div.html('' + d[self.settings.categoryField] 
									+ ', count: ' + d[self.settings.valueField1]
									+ '<br>' + d[self.settings.text1])
							.style('left', (d3.event.pageX) + "px")
							.style('top', (d3.event.pageY - 20) + "px");
					})
					.on('mouseout', function(d){
						div.transition()
							//.duration(0)
							.style('opacity', 0);
					})
					/*.on('mouseover', function(d){
						
						d3.select(this).style('cursor', 'pointer');						
						
				    	
				    })
				    .on('mouseout', function(d){
				    	d3.select(this).style('cursor', 'default');
				    })
					.on('click', function(d, i){
						alert('' + d[self.settings.categoryField] 
									+ ', \ncount:' + d[self.settings.valueField1]
									+ ', \n' + d[self.settings.text1]);
					})*/
					.attr('class', this.settings.class + 'Circles')
					.attr('fill', function(d, i){
						return colorMapperBubble(d[self.settings.valueField2]);
						//return 'green';
					})
					.attr('cx', function(d, i){
						return xp;
						
					})
					.attr('cy', function(d, i){
						
						
						if(d['location'] == 'CHESHIRE' && (d['title'] == 'EV Msg Stuck in Failed' || d['title'] == 'Purge failure')){
							skip++;
							return (i+skip+0.37)*97;
						}
						else{
							return (i+skip+0.37)*97;
						}
					})
					.attr('r', 30)
					.attr('stroke-width', 3)
					.attr('stroke', 'black')
					.attr('opacity', 0);

				var emptyData = data;
				emptyData.push('');
				emptyData.push('');

				svg.selectAll('.' + this.settings.class + 'borderline')
					.data(emptyData)
					.enter()
					.append('line')
					.attr('class', this.settings.class + 'borderline')
					.attr('x1', 0)
					.attr('x2', 198)
					.attr('y1', function(d, i){
						return (i+1)*97;
						
					})
					.attr('y2', function(d, i){
						return (i+1)*97;
						
					})
					.attr('stroke', 'grey')
					.attr('stroke-width', 2);

				
				
			}
		}
	);

	return Circles;

})(jQuery);
