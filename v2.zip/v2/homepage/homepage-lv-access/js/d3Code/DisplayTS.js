//
// Copyright (c) 2014-2015 TIBCO Software Inc. All rights reserved.
//
'use strict';
var DisplayTS = (function($){

	/**
	 * This object wraps a straight-forward DisplayTS chart. It is meant to be reusable, but is limited in the configuration
	 * options made available. It extends from the Visualization base object which maintains its data model.
	 * @class DisplayTS
	 * @param {Object} settings An object containing the parameters used to configure this DisplayTS
	 * @param {String} settings.elementId The element ID of the DOM element that this visualization should render in.
	 * @param {String} [settings.categoryField] The field name of the category field in the data model.
	 * @param {String} [settings.valueField] The field name of the value field in the data model.
	 */
	function DisplayTS(settings){
		this.schema = {};
		this.data = [];
		this.html = '<div>DisplayTS goes here</div>';
		this.settings = settings || {elementId: ''};
		this.settings.categoryField = settings.categoryField || 'category';
		this.settings.valueField = settings.valueField || 'value';
		// if adding more stuff in the app.model.js, add them here as well
		this.viewModel = [];
	}

	DisplayTS.prototype = $.extend(
		new Visualization(),
		{
			refresh: function(){
				var i;
				//sync viewModel with data
				this.viewModel = [];
				for(i = 0; i < this.data.length; i++){
					if(this.data[i]){
						this.viewModel.push(this.data[i].fieldMap);
					}
				}
				this.render();
			},
			render: function(){
				//console.log('Rendering DisplayTS to ' + this.settings.elementId);
				var data = this.viewModel,
				self = this,
				height = data.length * 90,
                textToDisplay = data.length;
                // console.log(data);
				// console.log(textToDisplay);
				// initial load will have nothing 
				if(self.settings.elementId == 'lastUpdatedFIL'){
					textToDisplay = new Date(data[0].ts).toString().substring(0, 24);
				}
				else if(self.settings.elementId == 'staleOrNot'){
					var lu = data[0].FLAGS.slice(0, 4) + '/' // change it to back slash JUST FOR IE
						+ data[0].FLAGS.slice(5, 7) + '/'
						+ data[0].FLAGS.slice(8, 10) + ' '
						+ data[0].FLAGS.slice(11, 13) + ':'
						+ data[0].FLAGS.slice(14, 16) + ':'
						+ data[0].FLAGS.slice(17, 19);
					console.log(lu);
					var lastUpdated = new Date(lu).toString().substring(0, 24);
					console.log('last updated: ' + lastUpdated);
					// check if > 45 min
					console.log('now: ' + new Date(Date.now()));

					var datediff = Date.now() - new Date(lu);
					
					console.log('days difference: ' + (datediff/(1000*3600*24)));
					console.log('difference in milliseconds: ' + datediff);

					// 45 minutes is 2700000 milliseconds

					if(datediff > 2700000){
						textToDisplay = 'STALE DATA; last updated at ' + lastUpdated; 
					}
					else{
						textToDisplay = ' '; 
					}
					

					



					
					// output textToDisplay, which is the text
					
				}
				// console.log("in DisplayTS");
				// console.log(this.viewModel);

				//element = d3.select('#' + this.settings.elementId),
				
				// console.log(data);

				// all size related code should be determined somehow by:
				// svgWidth for width, y
				// svgHeight for height, x
				

				// this class goes straight to svg


				var element = d3.select('#' + this.settings.elementId);
				element.selectAll('svg').remove();

				var svg = element.append('svg')
					.attr('width', 500)
					.attr('height', 15)
					//.attr('height', 720)
					.attr('class', self.settings.class)
					.attr('margin-left', 10);


				// console.log(colorMapper('hey'));

				
				svg.append('text')
					.attr('class', self.settings.class)
					.attr('x', self.settings.x)
					.attr('y', self.settings.y)
					.text(textToDisplay)
					.attr('font-size', 13)
					.attr('font-family', "Times New Roman")
					.attr('fill', 'white');
				


				/*
				svg.selectAll('.wmsCircls')
					.data(data)
					.enter()
					.append('circle')
					.attr('class', 'wmsDisplayTS')
					.attr('fill', function(d, i){
						return colorMapperBubble(d[self.settings.valueField2]);
						//return 'green';
					})
					.attr('cx', function(d, i){
						return 45;
						
					})
					.attr('cy', function(d, i){
						return (i+0.6)*70;
					})
					.attr('r', 30)
					.attr('stroke-width', 3)
					.attr('stroke', 'black')
					.attr('opacity', .8);
					
				
				svg.selectAll('.text')
					.data(data)
					.enter()
					.append('text')
					.attr('class', 'wmsHealthCheckText')
					.attr('x', 2)
					.attr('y', function(d, i){
						return (i+0.15)*70;
						
					})
					.text(function(d, i){
						return d[self.settings.categoryField];
					})
					.attr('font-size', 11)
					.attr('font-family', "Times New Roman")
					.attr('fill', 'white');
					//.attr('text-anchor', 'middle')

				svg.selectAll('.text')
					.data(data)
					.enter()
					.append('text')
					.attr('class', 'wmsHealthCheckText')
					.attr('x', 45)
					.attr('y', function(d, i){
						return (i+0.65)*70;
						
					})
					.text(function(d, i){
						return d[self.settings.valueField1];
					})
					.attr('font-size', 15)
					.attr('font-family', "Times New Roman")
					.attr('fill', 'white')
					.attr('text-anchor', 'middle');
				*/
				
			}
		}
	);

	return DisplayTS;

})(jQuery);
