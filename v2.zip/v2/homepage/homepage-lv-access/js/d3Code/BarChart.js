//
// Copyright (c) 2014-2015 TIBCO Software Inc. All rights reserved.
//
'use strict';
var BarChart = (function($){

	/**
	 * This object wraps a straight-forward BarChart chart. It is meant to be reusable, but is limited in the configuration
	 * options made available. It extends from the Visualization base object which maintains its data model.
	 * @class BarChart
	 * @param {Object} settings An object containing the parameters used to configure this BarChart
	 * @param {String} settings.elementId The element ID of the DOM element that this visualization should render in.
	 * @param {String} [settings.categoryField] The field name of the category field in the data model.
	 * @param {String} [settings.valueField] The field name of the value field in the data model.
	 */
	function BarChart(settings){
		this.schema = {};
		this.data = [];
		this.html = '<div>BarChart goes here</div>';
		this.settings = settings || {elementId: ''};
		this.settings.categoryField = settings.categoryField || 'category';
		this.settings.valueField = settings.valueField || 'value';
		// if adding more stuff in the app.model.js, add them here as well
		this.viewModel = [];
	}

	BarChart.prototype = $.extend(
		new Visualization(),
		{
			refresh: function(){
				var i;
				//sync viewModel with data
				this.viewModel = [];
				for(i = 0; i < this.data.length; i++){
					if(this.data[i]){
						this.viewModel.push(this.data[i].fieldMap);
					}
				}
				this.render();
			},
			render: function(){
				var data = this.viewModel,
					valueLabelWidth = 50, // space reserved for value labels (right)
					barHeight = 20, // height of one bar
					barLabelWidth = 390, // space reserved for bar labels
					barLabelPadding = 20, // padding between bar and bar labels (left)
					gridLabelHeight = 18, // space reserved for gridline labels
					gridChartOffset = 3, // space between start of grid and first bar
					maxBarWidth = 200, // width of the bar with the max value
					element = d3.select('#' + this.settings.elementId),
					self = this;

				// console.log(data);

				data = data.sort(ForceSortM)
				function ForceSortM(a, b) {

				    if (a[self.settings.catogoryField] < b[self.settings.catogoryField]){
				    	// console.log('less');
				   		return 1;
				   	}
				    if (a[self.settings.catogoryField] > b[self.settings.catogoryField]){
				    	// console.log('greater');
				    	return -1;
				    } 
				    
				    
				    // console.log('equal');
				    return 0;
				}					

				element.selectAll('svg').remove();

				// accessor functions
				var barLabel = function(d){
					return d[self.settings.categoryField];
				};
				var barValue = function(d){
					return parseFloat(d[self.settings.valueField]);
				};

				// scales
				var yScale = d3.scale.ordinal()
					.domain(d3.range(0, data.length))
					.rangeBands([0, data.length * barHeight]);
				var y = function(d, i){
					return yScale(i);
				};
				var yText = function(d, i){
					return y(d, i) + yScale.rangeBand() / 2;
				};
				var x = d3.scale.linear().domain([0, d3.max(data, barValue)]).range([0, maxBarWidth]);
				// svg container element
				var chart = element.append('svg')
					.attr('width', maxBarWidth + barLabelWidth + valueLabelWidth)
					.attr('height', gridLabelHeight + gridChartOffset + data.length * barHeight);
				// grid line labels
				var gridContainer = chart.append('g')
					.attr('transform', 'translate(' + barLabelWidth + ',' + gridLabelHeight + ')');
				gridContainer.selectAll('text').data(x.ticks(5)).enter().append('text')
					.attr('x', x)
					.attr('dy', -3)
					.attr('text-anchor', 'middle')
					.attr('font-size', '10px')
					.text(String);
				// vertical grid lines
				gridContainer.selectAll('line').data(x.ticks(5)).enter().append('line')
					.attr('x1', x)
					.attr('x2', x)
					.attr('y1', 0)
					.attr('y2', yScale.rangeExtent()[1] + gridChartOffset)
					.style('stroke', '#ccc');
				// bar labels
				var labelsContainer = chart.append('g')
					.attr('transform', 'translate(' + (barLabelWidth - barLabelPadding) + ',' + (gridLabelHeight + gridChartOffset) + ')');
				labelsContainer.selectAll('text').data(data).enter().append('text')
					.attr('y', yText)
					.attr('stroke', 'none')
					.attr('fill', 'black')
					.attr('dy', '.35em') // vertical-align: middle
					.attr('text-anchor', 'end')
					.attr('class', 'x_axis')
					.text(barLabel);
				// bars
				var barsContainer = chart.append('g')
					.attr('transform', 'translate(' + barLabelWidth + ',' + (gridLabelHeight + gridChartOffset) + ')');
				barsContainer.selectAll('rect').data(data).enter().append('rect')
					.attr('y', y)
					.attr('height', yScale.rangeBand())
					.attr('width', function(d){
						return x(barValue(d));
					})
					.attr('stroke', 'white')
					.attr('fill', function(d, i) {
						return 'black';
					}); // right here
				// bar value labels
				barsContainer.selectAll('text')
					.data(this.viewModel)
					.enter()
					.append('text')
					.attr('x', function(d){
						return x(barValue(d));
					})
					.attr('y', yText)
					.attr('dx', 3) // padding-left
					.attr('dy', '.35em') // vertical-align: middle
					.attr('text-anchor', 'start') // text-align: right
					.attr('fill', 'black')
					.attr('stroke', 'none')
					.text(function(d){
						return d3.round(barValue(d), 2);
					});
				// start line
				barsContainer.append('line')
					.attr('y1', -gridChartOffset)
					.attr('y2', yScale.rangeExtent()[1] + gridChartOffset)
					.style('stroke', '#000');

				
			}
		}
	);

	return BarChart;

})(jQuery);
