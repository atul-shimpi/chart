'use strict';

/**
 * The app contains the application logic for the jsapisample. It initializes a connection to liveView, then initializes
 * and displays the default view when the connection has been established. When a view is selected, the
 * app changes the display to show the new view, unsubscribes from all existing queries, and subscribes to all queries
 * defined by the new view's components.
 */
var app = (function(){
	var connection = null,      //will be the LiveView Connection once it has been established
		currentView = null;     //keeps track of the current view being presented

	//make sure the app's model was included
	if(!appModel_gc){
		alert('The application\'s model was not found! Please make sure app.model.js is included as a source file and try again.');
		return;
	}

	//Connect to LiveView
	LiveView.connect({
		url: '/lv/client'
	})
	.then(
		//On successful connection, set our connection variable to the created connection for later reference, show the nav, and load the default (1st) view
		function(lvConnection){
			connection = lvConnection;
			d3.select('#nav').style('display', 'block');
			showView(appModel_gc.views[appModel_gc.defaultView]);
		}
	);


	/**
	 * Alters the nav styles, displays view content, and subscribes to all relevant LiveView data for the specified view.
	 * @param {Object} view The view to display
	 * @param {boolean} [dontLoadData] Flag indicating whether or not to initialize data subscriptions for the view. The default value is false.
	 */
	function showView(view, dontLoadData){
		var viewName, i;
		if(!view){
			console.log('[ERROR] Tried to show invalid view.');
			return;
		}
		if(view === currentView){ return; }

		//Update nav
		d3.selectAll('.leftNavSelected').classed('leftNavSelected', false);
		d3.select('#menu' + view.name).classed('leftNavSelected', true);
		d3.selectAll('.blue').style('display', 'inline');
		d3.selectAll('.white').style('display', 'none');
		d3.select('#menu' + view.name).select('.white').style('display', 'inline');
		d3.select('#menu' + view.name).select('.blue').style('display', 'none');

		//Load View data
		if(!dontLoadData){
			subscribeViewQueries(view);
		}

		//Display view content and hide unselected views
		d3.select('#' + view.name).style('display', 'block');
		for(viewName in appModel_gc.views){
			if(!appModel_gc.views.hasOwnProperty(viewName)){ continue; }
			if(viewName !== view.name){
				for(i = 0; i < appModel_gc.views[viewName].components.length; i++){
					appModel_gc.views[viewName].components[i].visualization.clear();
				}
				d3.select('#' + viewName).style('display', 'none');
			}
		}
		currentView = view;
	}

	/**
	 * Subscribes to the data needed for a particular view and unsubscribes from data for views that are no longer visible.
	 * @param {Object} view The view to initiate data subscriptions for.
	 */
	function subscribeViewQueries(view){
		//check for a valid connection
		if(!connection){
			console.warn('No LiveView Connection.');
			return;
		}

		//unsubscribe from all current queries
		connection.unsubscribeAll()
		.then(
			function(){
				//initialize and configure data subscriptions for each component within the view
				var i;
				for(i = 0; i < view.components.length; i++){
					//capture the i-th component in closure so callbacks operate on the correct component
					(function(component){
						//subscribe to the component's query and configure callbacks to trigger the appropriate
						//component visualization handler
						connection.subscribe(component.query, {
							onSnapshotStart: function(event){
								component.visualization.setSchema(event.schema);
							},
							onInsert: function(event){
								component.visualization.addTuple(event.tuple);
								component.visualization.refresh();
							},
							onUpdate: function(event){
								component.visualization.updateTuple(event.tuple);
								component.visualization.refresh();
							},
							onDelete: function(event){
								component.visualization.deleteTuple(event.tuple);
								component.visualization.refresh();
							}
						});
					})(view.components[i]);
				}
			}
		);
	}

	//Properties and functionality that app "reveals" (i.e. app's interface). Notice that index.html binds the
	//navigation menu items' onclick to app.showViewByName
	return {
		showViewByName: function(viewName){showView(appModel_gc.views[viewName]);}
	};

})();
