//
// Copyright (c) 2014-2015 TIBCO Software Inc. All rights reserved.
//
'use strict';
var OneNumber = (function($){

	/**
	 * This object wraps a straight-forward OneNumber chart. It is meant to be reusable, but is limited in the configuration
	 * options made available. It extends from the Visualization base object which maintains its data model.
	 * @class OneNumber
	 * @param {Object} settings An object containing the parameters used to configure this OneNumber
	 * @param {String} settings.elementId The element ID of the DOM element that this visualization should render in.
	 * @param {String} [settings.categoryField] The field name of the category field in the data model.
	 * @param {String} [settings.valueField] The field name of the value field in the data model.
	 */
	function OneNumber(settings){
		this.schema = {};
		this.data = [];
		this.html = '<div>OneNumber goes here</div>';
		this.settings = settings || {elementId: ''};
		this.settings.categoryField = settings.categoryField || 'category';
		this.settings.valueField = settings.valueField || 'value';
		// if adding more stuff in the app.model.js, add them here as well
		this.viewModel = [];
	}

	OneNumber.prototype = $.extend(
		new Visualization(),
		{
			refresh: function(){
				var i;
				//sync viewModel with data
				this.viewModel = [];
				for(i = 0; i < this.data.length; i++){
					if(this.data[i]){
						this.viewModel.push(this.data[i].fieldMap);
					}
				}
				this.render();
			},
			render: function(){
				//console.log('Rendering OneNumber to ' + this.settings.elementId);
				var data = this.viewModel,
				self = this,
				height = data.length * 90,
                                cnt = data.length;
				// console.log(cnt);
				// console.log("in OneNumber");
				// console.log(this.viewModel);

				//element = d3.select('#' + this.settings.elementId),
				
				// console.log(data);

				// all size related code should be determined somehow by:
				// svgWidth for width, y
				// svgHeight for height, x
				

				// this class goes straight to svg

				var element = d3.select('#colorCountDiv');

				var svg = d3.select('#' + this.settings.elementId);
				element.selectAll('.' + self.settings.class).remove();



				// console.log(colorMapper('hey'));

				
				svg.append('text')
					.attr('class', self.settings.class)
					.attr('x', self.settings.x)
					.attr('y', self.settings.y)
					.text(cnt)
					.attr('font-size', 13)
					.attr('font-family', "Times New Roman")
					.attr('fill', 'white')
					.attr('text-anchor', 'middle');
				


				/*
				svg.selectAll('.wmsCircls')
					.data(data)
					.enter()
					.append('circle')
					.attr('class', 'wmsOneNumber')
					.attr('fill', function(d, i){
						return colorMapperBubble(d[self.settings.valueField2]);
						//return 'green';
					})
					.attr('cx', function(d, i){
						return 45;
						
					})
					.attr('cy', function(d, i){
						return (i+0.6)*70;
					})
					.attr('r', 30)
					.attr('stroke-width', 3)
					.attr('stroke', 'black')
					.attr('opacity', .8);
					
				
				svg.selectAll('.text')
					.data(data)
					.enter()
					.append('text')
					.attr('class', 'wmsHealthCheckText')
					.attr('x', 2)
					.attr('y', function(d, i){
						return (i+0.15)*70;
						
					})
					.text(function(d, i){
						return d[self.settings.categoryField];
					})
					.attr('font-size', 11)
					.attr('font-family', "Times New Roman")
					.attr('fill', 'white');
					//.attr('text-anchor', 'middle')

				svg.selectAll('.text')
					.data(data)
					.enter()
					.append('text')
					.attr('class', 'wmsHealthCheckText')
					.attr('x', 45)
					.attr('y', function(d, i){
						return (i+0.65)*70;
						
					})
					.text(function(d, i){
						return d[self.settings.valueField1];
					})
					.attr('font-size', 15)
					.attr('font-family', "Times New Roman")
					.attr('fill', 'white')
					.attr('text-anchor', 'middle');
				*/
				
			}
		}
	);

	return OneNumber;

})(jQuery);
