//
// Copyright (c) 2014-2015 TIBCO Software Inc. All rights reserved.
//
'use strict';
var CirclesOneGroup = (function($){

	/**
	 * This object wraps a straight-forward CirclesOneGroup chart. It is meant to be reusable, but is limited in the configuration
	 * options made available. It extends from the Visualization base object which maintains its data model.
	 * @class CirclesOneGroup
	 * @param {Object} settings An object containing the parameters used to configure this CirclesOneGroup
	 * @param {String} settings.elementId The element ID of the DOM element that this visualization should render in.
	 * @param {String} [settings.categoryField] The field name of the category field in the data model.
	 * @param {String} [settings.valueField] The field name of the value field in the data model.
	 */
	function CirclesOneGroup(settings){
		this.schema = {};
		this.data = [];
		this.html = '<div>CirclesOneGroup goes here</div>';
		this.settings = settings || {elementId: ''};
		this.settings.categoryField = settings.categoryField || 'category';
		this.settings.valueField = settings.valueField || 'value';
		this.viewModel = [];
	}

	CirclesOneGroup.prototype = $.extend(
		new Visualization(),
		{
			refresh: function(){
				var i;
				//sync viewModel with data
				this.viewModel = [];
				for(i = 0; i < this.data.length; i++){
					if(this.data[i]){
						this.viewModel.push(this.data[i].fieldMap);
					}
				}
				this.render();
			},
			render: function(){




				var data = this.viewModel,
				self = this;
				// console.log(data);

				if(self.settings.class == 'StoreFulfillmentServersByWebsite'){
					var height = data.length * 90,
					cx = 60,
					cy, 
					vSpace = 120,
					colDistance = 170,
					height = 490;
				}
				else if(self.settings.class == 'StoreFulfillmentWebSites' || self.settings.class == 'storeDatabaseL2b'){
					var height = data.length * 90,
					cx = 60,
					cy, 
					vSpace = 120,
					colDistance = 170,
					height = 490;
				}
				else{
					var height = data.length * 90,
					cx = 45,
					cy, 
					vSpace = 70,
					colDistance = 120;
					height = 296;
				}
				

				// console.log(data);
				
				var element = d3.select('#' + this.settings.elementId);
				element.selectAll('svg').remove();
				
				var svg = element.append('svg')
					.attr('width', colDistance * Math.ceil(data.length/4))
					.attr('height', height)
					//.attr('height', 720)
					.attr('class', self.settings.class)
					.attr('margin-left', 10);
				

			
				
				var div = d3.select('body').append('div')
					.attr('class', 'tooltip')
					.style('opacity', 0)
					.style('background-color', 'white');

				svg.selectAll('.' + this.settings.class + 'CirclesOneGroup')
					.data(data)
					.enter()
					.append('circle')
					.on('mouseover', function(d, i){
						if(self.settings.class == 'StoreFulfillmentWebSites' || self.settings.class =='StoreFulfillmentServersByWebsite' || self.settings.class == 'storeDatabaseL2b'){

						}
						else{
							var hoverMessage = 'NO DESCRIPTION AVAILABLE';

							if(d[self.settings.hoverMes].replace(/\s/g,'').length != 0){
								
								hoverMessage = d[self.settings.hoverMes];
							}
							
							// console.log(hoverMessage);
							div.transition()
								.duration(0)
								.style('opacity', .9);
							div.html(hoverMessage)
								.style('left', (d3.event.pageX) + "px")
								.style('top', (d3.event.pageY - 20) + "px");
						}
						
					})
					.on('mouseout', function(d){
						div.transition()
							.duration(0)
							.style('opacity', 0);
					})
					.attr('class', this.settings.class + 'CirclesOneGroup')
					.attr('fill', function(d, i){
						return colorMapperBubble(d[self.settings.valueField2]);
						//return 'green';
					})
					.attr('cx', function(d, i){
						if(i % 4 == 0 && i != 0){
							cx = cx + colDistance;
						}
						return cx;
					})
					.attr('cy', function(d, i){
						
						return ((i%4)+0.6)*vSpace;
					})
					.attr('r', 30)
					.attr('stroke-width', 3)
					.attr('stroke', 'black')
					.attr('opacity', .8);




				var x = 2;
				if(self.settings.class == 'StoreFulfillmentWebSites' || self.settings.class == 'StoreFulfillmentServersByWebsite' || self.settings.class == 'storeDatabaseL2b'){
					x = 65;
				}
				// the title of the bubble
				svg.selectAll('.' + this.settings.class + 'Text')
					.data(data)
					.enter()
					.append('text')
					.attr('class', this.settings.class + 'Text')
					.attr('x', function(d, i){
						if(i % 4 == 0 && i != 0){
							x = x + colDistance;
						}
						return x;
					})
					.attr('y', function(d, i){
						return ((i%4)+0.15)*vSpace;
						
					})
					.text(function(d, i){
						return d[self.settings.categoryField];
					})
					.attr('font-size', 11)
					.attr('font-family', "Times New Roman")
					.attr('fill', 'white')
					.attr('text-anchor', function(d, i){
						if(self.settings.class == 'StoreFulfillmentWebSites' || self.settings.class == 'StoreFulfillmentServersByWebsite' || self.settings.class == 'storeDatabaseL2b'){
							return 'middle';
						}
						else{
							return 'left';
						}
					});

				// the text in the middle
				if(self.settings.storyName == 'storeDatabaseL2b'){
					// console.log('store db');
					x = 60;
					svg.selectAll('.' + this.settings.class + 'Text2t')
						.data(data)
						.enter()
						.append('text')
						.attr('class', this.settings.class + 'Text2t')
						.attr('x', function(d, i){
							if(i % 4 == 0 && i != 0){
								x = x + colDistance;
							}
							return x;
						})
						.attr('y', function(d, i){
							return (i%4+0.25)*vSpace;
							
						})
						.text(function(d, i){
							return 'Status: ' + d['StatusDescription'];
						})
						.attr('font-size', 10)
						.attr('font-family', "Times New Roman")
						.attr('fill', 'white')
						.attr('text-anchor', 'middle');

					x = 60;
					svg.selectAll('.' + this.settings.class + 'Text3')
						.data(data)
						.enter()
					  .append('a')
					    .attr('href', function(d, i){
					    	return 'http://' + hostlink + ':10080/dashboard/pages/Store_Database_Trend/Store_Database_Trend.html?server=' + d['DBName'];
					    	
					    })
					  .append('text')
						.attr('class', this.settings.class + 'Text3')
						.attr('x', function(d, i){
							if(i % 4 == 0 && i != 0){
								x = x + colDistance;
							}
							return x;
						})
						.attr('y', function(d, i){
							return (i%4+0.55)*vSpace;
							
						})
						.text("Response")
						.attr('font-size', 10)
						.attr('font-family', "Times New Roman")
						.attr('fill', 'white')
						.attr('text-anchor', 'middle')
						.on('mouseover', function(d){
					    	d3.select(this).style('cursor', 'pointer');
					    })
					    .on('mouseout', function(d){
					    	d3.select(this).style('cursor', 'default');
					    });/*
						.on('click', function(d, i){
							
							open('http://' + hostlink + ':10080/dashboard/pages/Store_Fulfillment_Servers_By_WebSite/Store_Fulfillment_Servers_By_WebSite.html?website=' + d['WebSite']);
							
						});*/
					x = 60;	
					svg.selectAll('.' + this.settings.class + 'Text4')
						.data(data)
						.enter()
					  .append('a')
					    .attr('href', function(d, i){
					    	return 'http://' + hostlink + ':10080/dashboard/pages/Store_Database_Trend/Store_Database_Trend.html?server=' + d['DBName'];
					    })
					  .append('text')
						.attr('class', this.settings.class + 'Text4')
						.attr('x', function(d, i){
							if(i % 4 == 0 && i != 0){
								x = x + colDistance;
							}
							return x;
						})
						.attr('y', function(d, i){
							return (i%4+0.65)*vSpace;
							
						})
						.text(function(d, i){
							return d['TimeTaken'];
						})
						.attr('font-size', 9)
						.attr('font-family', "Times New Roman")
						.attr('fill', 'white')
						.attr('text-anchor', 'middle')
						.on('mouseover', function(d){
					    	d3.select(this).style('cursor', 'pointer');
					    })
					    .on('mouseout', function(d){
					    	d3.select(this).style('cursor', 'default');
					    });/*
						.on('click', function(d, i){
							
							open('http://' + hostlink + ':10080/dashboard/pages/Store_Fulfillment_Servers_By_WebSite/Store_Fulfillment_Servers_By_WebSite.html?website=' + d['WebSite']);

						});*/

					x = 60;
					svg.selectAll('.' + this.settings.class + 'Text5')
						.data(data)
						.enter()
						.append('text')
						.attr('class', this.settings.class + 'Text5')
						.attr('x', function(d, i){
							if(i % 4 == 0 && i != 0){
								x = x + colDistance;
							}
							return x;
						})
						.attr('y', function(d, i){
							return (i%4+0.75)*vSpace;
							
						})
						.text("sec")
						.attr('font-size', 10)
						.attr('font-family', "Times New Roman")
						.attr('fill', 'white')
						.attr('text-anchor', 'middle');

					x = 0;
					svg.selectAll('.' + this.settings.class + 'Text6')
						.data(data)
						.enter()
						.append('text')
						.attr('class', this.settings.class + 'Text6')
						.attr('x', function(d, i){
							if(i % 4 == 0 && i != 0){
								x = x + colDistance;
							}
							return x;
						})
						.attr('y', function(d, i){
							return (i%4+0.33)*vSpace;
							
						})
						.text(function(d, i){
							return 'LU: ' + (new Date(d['dtStamp'])).toString().substring(0, 25);
						})
						.attr('font-size', 10)
						.attr('font-family', "Times New Roman")
						.attr('fill', 'white');
						//.attr('text-anchor', 'middle');



				}
				else if(self.settings.class == 'StoreFulfillmentWebSites'){
					// console.log('level 2');
					x = 60;
					svg.selectAll('.' + this.settings.class + 'Text2t')
						.data(data)
						.enter()
						.append('text')
						.attr('class', this.settings.class + 'Text2t')
						.attr('x', function(d, i){
							if(i % 4 == 0 && i != 0){
								x = x + colDistance;
							}
							return x;
						})
						.attr('y', function(d, i){
							return (i%4+0.25)*vSpace;
							
						})
						.text(function(d, i){
							return 'Status: ' + d['StatusDescription'];
						})
						.attr('font-size', 10)
						.attr('font-family', "Times New Roman")
						.attr('fill', 'white')
						.attr('text-anchor', 'middle');

					x = 60;
					svg.selectAll('.' + this.settings.class + 'Text3')
						.data(data)
						.enter()
					  .append('a')
					    .attr('href', function(d, i){
					    	return 'http://' + hostlink + ':10080/dashboard/pages/Store_Fulfillment_Servers_By_WebSite/Store_Fulfillment_Servers_By_WebSite.html?website=' + d['WebSite']
					    })
					  .append('text')
						.attr('class', this.settings.class + 'Text3')
						.attr('x', function(d, i){
							if(i % 4 == 0 && i != 0){
								x = x + colDistance;
							}
							return x;
						})
						.attr('y', function(d, i){
							return (i%4+0.55)*vSpace;
							
						})
						.text("Response")
						.attr('font-size', 10)
						.attr('font-family', "Times New Roman")
						.attr('fill', 'white')
						.attr('text-anchor', 'middle')
						.on('mouseover', function(d){
					    	d3.select(this).style('cursor', 'pointer');
					    })
					    .on('mouseout', function(d){
					    	d3.select(this).style('cursor', 'default');
					    });/*
						.on('click', function(d, i){
							
							open('http://' + hostlink + ':10080/dashboard/pages/Store_Fulfillment_Servers_By_WebSite/Store_Fulfillment_Servers_By_WebSite.html?website=' + d['WebSite']);
							
						});*/
					x = 60;	
					svg.selectAll('.' + this.settings.class + 'Text4')
						.data(data)
						.enter()
					  .append('a')
					    .attr('href', function(d, i){
					    	return 'http://' + hostlink + ':10080/dashboard/pages/Store_Fulfillment_Servers_By_WebSite/Store_Fulfillment_Servers_By_WebSite.html?website=' + d['WebSite'];
					    })
					  .append('text')
						.attr('class', this.settings.class + 'Text4')
						.attr('x', function(d, i){
							if(i % 4 == 0 && i != 0){
								x = x + colDistance;
							}
							return x;
						})
						.attr('y', function(d, i){
							return (i%4+0.65)*vSpace;
							
						})
						.text(function(d, i){
							return d['TimeTaken'];
						})
						.attr('font-size', 9)
						.attr('font-family', "Times New Roman")
						.attr('fill', 'white')
						.attr('text-anchor', 'middle')
						.on('mouseover', function(d){
					    	d3.select(this).style('cursor', 'pointer');
					    })
					    .on('mouseout', function(d){
					    	d3.select(this).style('cursor', 'default');
					    });/*
						.on('click', function(d, i){
							
							open('http://' + hostlink + ':10080/dashboard/pages/Store_Fulfillment_Servers_By_WebSite/Store_Fulfillment_Servers_By_WebSite.html?website=' + d['WebSite']);

						});*/

					x = 60;
					svg.selectAll('.' + this.settings.class + 'Text5')
						.data(data)
						.enter()
						.append('text')
						.attr('class', this.settings.class + 'Text5')
						.attr('x', function(d, i){
							if(i % 4 == 0 && i != 0){
								x = x + colDistance;
							}
							return x;
						})
						.attr('y', function(d, i){
							return (i%4+0.75)*vSpace;
							
						})
						.text("sec")
						.attr('font-size', 10)
						.attr('font-family', "Times New Roman")
						.attr('fill', 'white')
						.attr('text-anchor', 'middle');

					x = 0;
					svg.selectAll('.' + this.settings.class + 'Text6')
						.data(data)
						.enter()
						.append('text')
						.attr('class', this.settings.class + 'Text6')
						.attr('x', function(d, i){
							if(i % 4 == 0 && i != 0){
								x = x + colDistance;
							}
							return x;
						})
						.attr('y', function(d, i){
							return (i%4+0.33)*vSpace;
							
						})
						.text(function(d, i){
							return 'LU: ' + (new Date(d['dtStamp'])).toString().substring(0, 25);
						})
						.attr('font-size', 10)
						.attr('font-family', "Times New Roman")
						.attr('fill', 'white');
						//.attr('text-anchor', 'middle');



				}

				else if(self.settings.class == 'StoreFulfillmentServersByWebsite'){
					// console.log('current lowest level');
					x = 60;
					svg.selectAll('.' + this.settings.class + 'Text2t')
						.data(data)
						.enter()
						.append('text')
						.attr('class', this.settings.class + 'Text2t')
						.attr('x', function(d, i){
							if(i % 4 == 0 && i != 0){
								x = x + colDistance;
							}
							return x;
						})
						.attr('y', function(d, i){
							return (i%4+0.25)*vSpace;
							
						})
						.text(function(d, i){
							return 'Status: ' + d['StatusDescription'];
						})
						.attr('font-size', 10)
						.attr('font-family', "Times New Roman")
						.attr('fill', 'white')
						.attr('text-anchor', 'middle');

					x = 60;
					svg.selectAll('.' + this.settings.class + 'Text3')
						.data(data)
						.enter()
						.append('text')
						.attr('class', this.settings.class + 'Text3')
						.attr('x', function(d, i){
							if(i % 4 == 0 && i != 0){
								x = x + colDistance;
							}
							return x;
						})
						.attr('y', function(d, i){
							return (i%4+0.55)*vSpace;
							
						})
						.text("Reponse")
						.attr('font-size', 10)
						.attr('font-family', "Times New Roman")
						.attr('fill', 'white')
						.attr('text-anchor', 'middle');
					x = 60;	
					svg.selectAll('.' + this.settings.class + 'Text4')
						.data(data)
						.enter()
					  .append('a')
					    .attr('href', function(d, i){
					    	return 'http://' + hostlink + ':10080/dashboard/pages/Store_Fulfillment_Application_Trend/Store_Fulfillment_Application_Trend.html?server=' + d['Server'] + '&site=' + d['WebSite'];
					    })
					  .append('text')
						.attr('class', this.settings.class + 'Text4')
						.attr('x', function(d, i){
							if(i % 4 == 0 && i != 0){
								x = x + colDistance;
							}
							return x;
						})
						.attr('y', function(d, i){
							return (i%4+0.65)*vSpace;
							
						})
						.text(function(d, i){
							return d['TimeTaken'];
						})
						.attr('font-size', 9)
						.attr('font-family', "Times New Roman")
						.attr('fill', 'white')
						.attr('text-anchor', 'middle');

					x = 60;
					svg.selectAll('.' + this.settings.class + 'Text5')
						.data(data)
						.enter()
						.append('text')
						.attr('class', this.settings.class + 'Text5')
						.attr('x', function(d, i){
							if(i % 4 == 0 && i != 0){
								x = x + colDistance;
							}
							return x;
						})
						.attr('y', function(d, i){
							return (i%4+0.75)*vSpace;
							
						})
						.text("sec")
						.attr('font-size', 10)
						.attr('font-family', "Times New Roman")
						.attr('fill', 'white')
						.attr('text-anchor', 'middle');

					x = 0;
					svg.selectAll('.' + this.settings.class + 'Text6')
						.data(data)
						.enter()
						.append('text')
						.attr('class', this.settings.class + 'Text6')
						.attr('x', function(d, i){
							if(i % 4 == 0 && i != 0){
								x = x + colDistance;
							}
							return x;
						})
						.attr('y', function(d, i){
							return (i%4+0.33)*vSpace;
							
						})
						.text(function(d, i){
							return 'LU: ' + (new Date(d['dtStamp'])).toString().substring(0, 25);
						})
						.attr('font-size', 10)
						.attr('font-family', "Times New Roman")
						.attr('fill', 'white');
						//.attr('text-anchor', 'middle');
				}
				else{
					x = 45;
					svg.selectAll('.' + this.settings.class + 'Text2')
						.data(data)
						.enter()
						.append('text')
						.on('mouseover', function(d, i){
							var hoverMessage = 'NO DESCRIPTION AVAILABLE';

							if(d[self.settings.hoverMes].replace(/\s/g,'').length != 0){
								
								hoverMessage = d[self.settings.hoverMes];
							}
							
							// console.log(hoverMessage);
							div.transition()
								.duration(0)
								.style('opacity', .9);
							div.html(hoverMessage)
								.style('left', (d3.event.pageX) + "px")
								.style('top', (d3.event.pageY - 20) + "px");
						})
						.on('mouseout', function(d){
							div.transition()
								.duration(0)
								.style('opacity', 0);
						})
						.attr('class', this.settings.class + 'Text2')
						.attr('x', function(d, i){
							if(i % 4 == 0 && i != 0){
								x = x + colDistance;
							}
							return x;
						})
						.attr('y', function(d, i){
							return (i%4+0.65)*vSpace;
							
						})
						.text(function(d, i){
							return parseInt(d[self.settings.valueField1]);
						})
						.attr('font-size', 15)
						.attr('font-family', "Times New Roman")
						.attr('fill', 'white')
						.attr('text-anchor', 'middle');
					}
				
				
			}
		}
	);

	return CirclesOneGroup;

})(jQuery);
