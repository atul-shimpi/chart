//
// Copyright (c) 2014-2015 TIBCO Software Inc. All rights reserved.
//
'use strict';
var StoreServers = (function($){

	/**
	 * This object wraps a straight-forward StoreServers chart. It is meant to be reusable, but is limited in the configuration
	 * options made available. It extends from the Visualization base object which maintains its data model.
	 * @class StoreServers
	 * @param {Object} settings An object containing the parameters used to configure this StoreServers
	 * @param {String} settings.elementId The element ID of the DOM element that this visualization should render in.
	 * @param {String} [settings.categoryField] The field name of the category field in the data model.
	 * @param {String} [settings.valueField] The field name of the value field in the data model.
	 */
	function StoreServers(settings){
		this.schema = {};
		this.data = [];
		this.html = '<div>StoreServers goes here</div>';
		this.settings = settings || {elementId: ''};
		this.settings.categoryField = settings.categoryField || 'category';
		this.settings.valueField = settings.valueField || 'value';
		// if adding more stuff in the app.model.js, add them here as well
		this.viewModel = [];
	}

	StoreServers.prototype = $.extend(
		new Visualization(),
		{
			refresh: function(){
				var i;
				//sync viewModel with data
				this.viewModel = [];
				for(i = 0; i < this.data.length; i++){
					if(this.data[i]){
						this.viewModel.push(this.data[i].fieldMap);
					}
				}
				this.render();
			},
			render: function(){
				//console.log('Rendering StoreServers to ' + this.settings.elementId);
				var data = this.viewModel,
				
				self = this;


				var element = d3.select('#' + this.settings.elementId);
				element.selectAll('.' + self.settings.class + 'svg').remove();

				var svg = element.append('svg')
					.attr('width', 107)
					.attr('height', 200)
					//.attr('height', 720)
					.attr('class', self.settings.class + 'svg')
					.attr('text-anchor', 'middle');



				svg.selectAll('image')
					.data(data)
					.enter()
				  .append('image')
					.attr('href', function(d, i){
						
						if(d[self.settings.color] == 'Red'){
							return redImagePath;
						}
						else if(d[self.settings.color] == 'Yellow'){
							return yellowImagePath;
						}
						else if(d[self.settings.color] == 'Blue'){
							return blueImagePath;
						}
						else{
							return greenImagePath;
						}
					})
					.attr('x', function(d, i){
						
						return -5;
					})
					.attr('y', function(d, i){
						return 1;
					})
					.attr('height', 110)
					.attr('width', 120)
					.attr('text-anchor', 'middle')
					.on('mouseover', function(d){
						
						d3.select(this).style('cursor', 'pointer');						
						
				    	
				    })
				    .on('mouseout', function(d){
				    	d3.select(this).style('cursor', 'default');
				    })/*
					.on('click', function(d, i){
						
						//open('http://localhost:10080/dashboard/pages/Store_Fulfillment_WebSites/Store_Fulfillment_WebSites.html?server=' + self.settings.server);
						alert("Server: " + d['Server'] + "\nStatus: " + d['StatusDesc'] + "\nCPU: " + d['CPU'] + "\nMemory: " + d['Memory'] + "\nDisk C Free: " + d['diskCfree'] + "\nDisk E Free: " + d['diskEfree']);
						

					})*/;

					// click here to see trend
					svg.selectAll('.' + this.settings.class + 'clickText')
						.data(data)
						.enter()
					  .append('a')
					    .attr('href', function(d, i){
					    	return 'http://' + hostlink + ':10080/dashboard/pages/Store_Fulfillment_Server_Trend/Store_Fulfillment_Server_Trend.html?server=' + d['Server'];
					    })
					  .append('text')
						.attr('class', this.settings.class + 'clickText')
						.attr('x', 53)
						.attr('y', 85)
						.text('O')
						.attr('font-size', 80)
						.attr('opacity', 0)
						.attr('font-family', "Times New Roman")
						.attr('fill', 'white');





					svg.selectAll('.' + this.settings.class + 'Text1')
						.data(data)
						.enter()
					  .append('text')
						.attr('class', this.settings.class + 'Text1')
						.attr('x', 53)
						.attr('y', 125)
						.attr('word-wrap', 'break-word')
						.attr('width', 110)
						.attr('white-space', 'pre')
						.text('Last Updated:')
						.attr('font-size', 10)
						.attr('font-family', "Times New Roman")
						.attr('fill', 'white');



					svg.selectAll('.' + this.settings.class + 'Text2')
						.data(data)
						.enter()
						.append('text')
						.attr('class', this.settings.class + 'Text2')
						.attr('x', 53)
						.attr('y', 135)
						.attr('word-wrap', 'break-word')
						.attr('width', 110)
						.attr('white-space', 'pre')
						.text(function(d, i){
							
							return (new Date(d['dtStamp'])).toString().substring(4, 25);
							
						})
						.attr('font-size', 10)
						.attr('font-family', "Times New Roman")
						.attr('fill', 'white');

					svg.selectAll('.' + this.settings.class + 'Text3')
						.data(data)
						.enter()
						.append('text')
						.attr('class', this.settings.class + 'Text3')
						.attr('x', 53)
						.attr('y', 150)
						.attr('word-wrap', 'break-word')
						.attr('width', 110)
						.attr('white-space', 'pre')
						.text(function(d, i){
							
							return 'CPU: ' + d['CPU'];
							
						})
						.attr('font-size', 10)
						.attr('font-family', "Times New Roman")
						.attr('fill', 'white');

					svg.selectAll('.' + this.settings.class + 'Text4')
						.data(data)
						.enter()
						.append('text')
						.attr('class', this.settings.class + 'Text4')
						.attr('x', 53)
						.attr('y', 160)
						.attr('word-wrap', 'break-word')
						.attr('width', 112)
						.attr('white-space', 'pre')
						.text(function(d, i){
							
							return 'Memory: ' + d['Memory'];
							
						})
						.attr('font-size', 10)
						.attr('font-family', "Times New Roman")
						.attr('fill', 'white');

					svg.selectAll('.' + this.settings.class + 'Text5')
						.data(data)
						.enter()
						.append('text')
						.attr('class', this.settings.class + 'Text5')
						.attr('x', 53)
						.attr('y', 170)
						.attr('word-wrap', 'break-word')
						.attr('width', 112)
						.attr('white-space', 'pre')
						.text(function(d, i){
							
							return 'Disk C Free: ' + d['diskCfree'];
							
						})
						.attr('font-size', 10)
						.attr('font-family', "Times New Roman")
						.attr('fill', 'white');

					svg.selectAll('.' + this.settings.class + 'Text6')
						.data(data)
						.enter()
						.append('text')
						.attr('class', this.settings.class + 'Text6')
						.attr('x', 53)
						.attr('y', 180)
						.attr('word-wrap', 'break-word')
						.attr('width', 112)
						.attr('white-space', 'pre')
						.text(function(d, i){
							
							return 'Disk E Free: ' + d['diskEfree'];
							
						})
						.attr('font-size', 10)
						.attr('font-family', "Times New Roman")
						.attr('fill', 'white');
					



			}
		}
	);

	return StoreServers;

})(jQuery);
