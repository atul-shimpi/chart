//
// Copyright (c) 2014-2015 TIBCO Software Inc. All rights reserved.
//
'use strict';
var CirclesInd = (function($){

	/**
	 * This object wraps a straight-forward CirclesInd chart. It is meant to be reusable, but is limited in the configuration
	 * options made available. It extends from the Visualization base object which maintains its data model.
	 * @class CirclesInd
	 * @param {Object} settings An object containing the parameters used to configure this CirclesInd
	 * @param {String} settings.elementId The element ID of the DOM element that this visualization should render in.
	 * @param {String} [settings.categoryField] The field name of the category field in the data model.
	 * @param {String} [settings.valueField] The field name of the value field in the data model.
	 */
	function CirclesInd(settings){
		this.schema = {};
		this.data = [];
		this.html = '<div>CirclesInd goes here</div>';
		this.settings = settings || {elementId: ''};
		this.settings.categoryField = settings.categoryField || 'category';
		this.settings.valueField = settings.valueField || 'value';
		// if adding more stuff in the app.model.js, add them here as well
		this.viewModel = [];
	}

	CirclesInd.prototype = $.extend(
		new Visualization(),
		{
			refresh: function(){
				var i;
				//sync viewModel with data
				this.viewModel = [];
				for(i = 0; i < this.data.length; i++){
					if(this.data[i]){
						this.viewModel.push(this.data[i].fieldMap);
					}
				}
				this.render();
			},
			render: function(){
				//console.log('Rendering CirclesInd to ' + this.settings.elementId);
				var data = this.viewModel,
				
				self = this,
				height = data.length * 90;
				var xp = 99;
				// console.log(data);
				// console.log(data);

				//element = d3.select('#' + this.settings.elementId),
				
				// console.log(data);

				// all size related code should be determined somehow by:
				// svgWidth for width, y
				// svgHeight for height, x
				
				var element = d3.select('#' + this.settings.elementId);
				element.selectAll('svg').remove();

				var svg = element.append('svg')
					.attr('width', 198)
					.attr('height', function(){
						return 400;
					})

					//.attr('height', 720)
					.attr('class', self.settings.class);

				var div = d3.select('body').append('div')
					.attr('class', 'tooltip')
					.style('opacity', 0)
					.style('background-color', 'white');
				


				// console.log(colorMapper('hey'));

				/*
				svg.selectAll('.text')
					.data(data)
					.enter()
					.append('p')
					.attr('class', 'wmsHealthCheckText')
					.attr('x', function(d, i){
						return 45;
					})
					.attr('y', function(d, i){
						return (i+0.5)*65;
						
					})
					.html(function(d, i){
						return d[self.settings.categoryField];
					})
					.attr('font-size', 11)
					.attr('font-family', "Times New Roman")
					.attr('fill', 'white');
					//.attr('text-anchor', 'middle')
				*/


				
				svg.selectAll('.' + this.settings.class + 'CirclesInd')
					.data(data)
					.enter()
					.append('circle')
					/*.on('mouseover', function(d, i){
						div.transition()
							.duration(200)
							.style('opacity', .9);
						div.html('the ' + i + 'th circle')
							.style('left', (d3.event.pageX) + "px")
							.style('top', (d3.event.pageY - 20) + "px");
					})
					.on('mouseout', function(d){
						div.transition()
							.duration(500)
							.style('opacity', 0);
					})*/
					.attr('class', this.settings.class + 'CirclesInd')
					.attr('fill', function(d, i){
						return colorMapperBubble(d[self.settings.valueField2]);
						//return 'green';
					})
					.attr('cx', function(d, i){
						return xp;
						
					})
					.attr('cy', function(d, i){
						return (i+0.32)*97;
					})
					.attr('r', 30)
					.attr('stroke-width', 3)
					.attr('stroke', 'black')
					.attr('opacity', .8);
				

				// 	<image xlink:href="firefox.jpg" x="0" y="0" height="50px" width="50px"/>
				// syntax for replacing bubble with image
				/*
				svg.selectAll('.wmsBubbleImage')
					.data(data)
					.enter()
					.append('image')
					.attr('href', 'clearBubbleTest1.jpg')
					.attr('x', function(d, i){
						return 45;
						
					})
					.attr('y', function(d, i){
						return (i+0.6)*70;
					})
					.attr('height', 60)
					.attr('width', 60)
					.attr('text-anchor', 'middle');
				*/
				
				svg.selectAll('.' + this.settings.class + 'Text')
					.data(data)
					.enter()
					.append('text')
					.attr('class', this.settings.class + 'Text')
					.attr('x', 99)
					.attr('y', function(d, i){
						return (i+0.75)*97;
						
					})
					.text(function(d, i){
						return d[self.settings.categoryField];
					})
					.attr('font-size', 11)
					.attr('font-family', "Times New Roman")
					.attr('fill', 'white')
					.attr('text-anchor', 'middle');


				svg.selectAll('.' + this.settings.text1 + 'Text')
					.data(data)
					.enter()
					.append('text')
					.attr('class', this.settings.text1 + 'Text')
					.attr('x', 99)
					.attr('y', function(d, i){
						return (i+0.88)*97;  
					})
					.text(function(d, i){
						return d[self.settings.text1];
					})
					.attr('font-size', 11)
					.attr('font-family', "Times New Roman")
					.attr('fill', 'white')
					.attr('text-anchor', 'middle');

				svg.selectAll('.' + this.settings.class + 'Text2') // the value in the middle of the bubble
					.data(data)
					.enter()
					.append('text')
					.on('mouseover', function(d, i){
						div.transition()
							.duration(200)
							.style('opacity', .9);
						div.html('' + d[self.settings.categoryField] + ', count: ' + d[self.settings.valueField1])
							.style('left', (d3.event.pageX) + "px")
							.style('top', (d3.event.pageY - 20) + "px");
					})
					.on('mouseout', function(d){
						div.transition()
							.duration(500)
							.style('opacity', 0);
					})
					.attr('class', this.settings.class + 'Text2')
					.attr('x', xp)
					.attr('y', function(d, i){
						return (i+0.38)*97;
					})
					.text(function(d, i){
						return d[self.settings.valueField1];
					})
					.attr('font-size', 15)
					.attr('font-family', "Times New Roman")
					.attr('fill', 'white')
					.attr('text-anchor', 'middle');
				
				
			}
		}
	);

	return CirclesInd;

})(jQuery);
