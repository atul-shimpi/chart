var ChartView = (function($){
	'use strict';

	/**
	 * A general-purpose Highcharts chart component
	 * @class ChartView
	 * @param {LiveViewQueryService.LiveQueryModel} model The model to be used to drive data in this View
	 * @param {Element} element The the DOM element that this visualization should render in.
	 * @param {Object} [config] An object containing the parameters used to configure this GaugeView
	 */
	function ChartView(model, element, config){
		if(this instanceof ChartView === false){
			return new ChartView(model, element, config);
		}

		this.model = model;
		this.viewModel = {};
		this.element = element;
		this.config = config || {};

		//Subscribe to model updates so we can update the view
		if(model instanceof LiveViewQueryService.LiveQueryModel){
			model.addInsertListener(this.handleDataAdded, this);
			model.addUpdateListener(this.handleDataUpdated, this);
			model.addDeleteListener(this.handleDataRemoved, this);
		}
		else{
			console.error('[ERROR] ChartView.constructor - The provided model is not a LiveQueryModel. Data will likely not be displayed for this ChartView.');
		}

		//Build the view and add it to the DOM
		this.container = $('<div class="chart-container" style="height:' + element.height() + 'px; "></div>');
		this.chart = buildChart(this.container[0], config);
		$(element).append(this.container);

		//Fix highcharts problem where chart doesn't fill the width of its container when initialized
		setTimeout((function(chart){
			return function(){ chart.reflow(); }
		})(this.chart), 0);

	}
	ChartView.prototype = {
		constructor: ChartView,

		/**
		 * Adds the appropriate chart data based on chart series configuration.
		 * @param tuple {LiveView.Tuple} The tuple that was added to the dataset and should be used to extract values to display in the chart.
		 */
		handleDataAdded: function(tuple){
			var seriesIndex, valueField;
			// console.log(tuple);
			//Using the visualizationConfig.series array defined for this chart, construct each series by adding points
			//whose x-value is the value contained in the chart's category field and whose y-value is the value
			//contained in the value field for the particular series. Note we pass false as a second argument to
			//addPoint to avoid redrawing the chart until all points have been added.
			for(seriesIndex = 0; seriesIndex < this.config.series.length; seriesIndex++){
				valueField = this.config.series[seriesIndex].valueField;
				this.chart.series[seriesIndex].addPoint([
					tuple.fieldMap[this.config.categoryField],
					tuple.fieldMap[valueField]
				], false);
			}

			//now that all points have been added to the chart, redraw it on the page
			this.chart.redraw();

			//In order to easily update or remove points on future update and delete events, we add a reference to the
			//Highcharts point to the viewModel. Points are only available after the points have been added and the
			//chart has been redrawn.
			for(seriesIndex = 0; seriesIndex < this.config.series.length; seriesIndex++){
				if(this.viewModel[seriesIndex] === undefined){
					this.viewModel[seriesIndex] = {};
				}
				this.viewModel[seriesIndex][tuple.id] = this.chart.series[seriesIndex].data[this.chart.series[seriesIndex].data.length - 1];
			}
		},

		/**
		 * Handles data updates for the chart.
		 * @param tuple {LiveView.Tuple} The tuple that was updated in the query result dataset. Note that because our
		 * LiveViewService utilizes the TupleStore, we have access to all fields (updated or not) in the tuple.
		 */
		handleDataUpdated: function(tuple){
			var seriesIndex, valueField;

			//For each of the series defined in the visualizationConfig.series array, look up the stored Point reference
			//using the updated tuple's ID, and update it with the new values. Again, we refrain from redrawing the
			//chart until all points have been updated.
			for(seriesIndex = 0; seriesIndex < this.config.series.length; seriesIndex++){
				valueField = this.config.series[seriesIndex].valueField;
				this.viewModel[seriesIndex][tuple.id].update([
					tuple.fieldMap[this.config.categoryField],
					tuple.fieldMap[valueField]
				], false);
			}

			//now that all points have been updated on the chart, redraw it on the page
			this.chart.redraw();
		},

		/**
		 * Handles data removal from the chart.
		 * @param tuple {LiveView.Tuple} The tuple that was removed in the query result dataset
		 */
		handleDataRemoved: function(tuple){
			var seriesIndex;

			//For each of the series defined in the visualizationConfig.series array, look up the stored Point reference
			//using the removed tuple's ID, and delete it. Again, we refrain from redrawing the chart until all points
			//have been removed.
			for(seriesIndex = 0; seriesIndex < this.config.series.length; seriesIndex++){
				if(!this.viewModel[seriesIndex] || !this.viewModel[seriesIndex][tuple.id]){
					continue;
				}
				this.viewModel[seriesIndex][tuple.id].remove(false);
			}
			delete this.viewModel[tuple.id];

			//now that all points have been updated on the chart, redraw it on the page
			this.chart.redraw();
		}
	};

	/**
	 * Builds a Highcharts chart to be rendered in the provided DOM element.
	 * @param element {Element} The DOM element in which the chart should render
	 * @param [config] {Object} Optional configuration object that can be used to define the characteristics of the constructed chart
	 * @returns {Highcharts.Chart} A reference to the Highcharts.Chart object that was created
	 */
	function buildChart(element, config){
		//console.log(config);
		config = config || {};
		config.options = config.options || {};
		Highcharts.setOptions({
			global: {
				useUTC: false
			}
		});
		return new Highcharts.Chart({
			chart: $.extend( true,
				config.options.chart || {},
				{
					type: config.plotType || 'line',
					renderTo: element,
					animation: Highcharts.svg,
					options3d: config.threeDOptions // added post 'purchase'
				}
			),
			title: {text: config.title},
			xAxis: config.options.xAxis || {},
			yAxis: config.options.yAxis || {},
			tooltip: config.options.tooltip || {},
			legend: config.options.legend || {},
			plotOptions: config.options.plotOptions || {},
			series: config.series.map(function(configSeriesItem){
				// console.log(configSeriesItem);
				return $.extend({data: []}, configSeriesItem); //make sure each series config has a data property
			})
		});
	}

	return ChartView;

})(jQuery);
