var PieChartView= (function($){
	'use strict';
	/**
	 * A Highcharts pie chart component
	 * @class GaugeView
	 * @param {LiveViewQueryService.LiveQueryModel} model The model to be used to drive data in this View
	 * @param {Element} element The the DOM element that this visualization should render in.
	 * @param {Object} [config] An object containing the parameters used to configure this GaugeView
	 */
	function PieChartView(model, element, config){
		var size;

		if(this instanceof PieChartView === false){ return new PieChartView(model, element, config); }

		this.model = model;
		this.viewModel = {};
		this.element = element;
		this.config = config || {};
		size = 0.9*element.height(); //constrain the pie chart view to 90% of its container

		//Subscribe to model updates so we can update the view
		if(model instanceof LiveViewQueryService.LiveQueryModel){
			model.addInsertListener(this.handleDataAdded, this);
			model.addUpdateListener(this.handleDataUpdated, this);
			model.addDeleteListener(this.handleDataRemoved, this);
		}
		else{
			console.error('[ERROR] PieChartView.constructor - The provided model is not a LiveQueryModel. Data will likely not be displayed for this PieChartView.');
		}

		//Build the view and add it to the DOM
		this.container = $('<div class="piechart-container" style="width: ' + size + 'px; height:' + size + 'px; "></div>');
		this.chart = buildChart(this.container[0], config);
		$(element).append(this.container);

	}
	PieChartView.prototype = {
		constructor: PieChartView,
		handleDataAdded: function(tuple){
			//add the tuple value to the series for this pie chart
			this.chart.series[0].addPoint([
				tuple.fieldMap[this.config.categoryField],
				tuple.fieldMap[this.config.valueField]
			]);
			//keep a reference to the data point for later updates and/or removal
			this.viewModel[tuple.id] = this.chart.series[0].data[this.chart.series[0].data.length-1];
		},
		handleDataUpdated: function(tuple){
			//find the corresponding datapoint in our viewModel and update its value
			this.viewModel[tuple.id].update([
				tuple.fieldMap[this.config.categoryField],
				tuple.fieldMap[this.config.valueField]
			]);
		},
		handleDataRemoved: function(tuple){
			//find the corresponding datapoint in our viewModel and remove it
			this.viewModel[tuple.id].remove();
			//remove the datapoint from the viewModel map
			delete this.viewModel[tuple.id];
		}
	};

	function buildChart(element, config){
		var hcConfig;
		config = config || {};
		hcConfig = {
			chart: {
				renderTo: element
			},
			title: {
				text: config.title || ''
			},
			plotOptions: {
				pie: {
					dataLabels: {
						enabled: false
					},
					showInLegend: (config.legend instanceof Object)
				}
			},
			legend: config.legend || {},
			series: [{
				type: 'pie',
				name: config.valueField
			}]
		};
		return new Highcharts.Chart(hcConfig);
	}

	return PieChartView;

})(jQuery);
