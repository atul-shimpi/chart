var BubblesView= (function($){
	'use strict';
	/**
	 * A Highcharts pie chart component
	 * @class GaugeView
	 * @param {LiveViewQueryService.LiveQueryModel} model The model to be used to drive data in this View
	 * @param {Element} element The the DOM element that this visualization should render in.
	 * @param {Object} [config] An object containing the parameters used to configure this GaugeView
	 */
	function BubblesView(model, element, config){
		
		/*
		console.log('enter BubblesView');
		console.log(model);
		console.log(element);
		console.log(config);
		*/
		
		var size;

		if(this instanceof BubblesView === false){ return new BubblesView(model, element, config); }

		this.model = model;
		this.viewModel = {};
		this.element = element;
		this.config = config || {};
		size = 0.9*element.height(); //constrain the pie chart view to 90% of its container

		//Subscribe to model updates so we can update the view
		if(model instanceof LiveViewQueryService.LiveQueryModel){
			model.addInsertListener(this.handleDataAdded, this);
			model.addUpdateListener(this.handleDataUpdated, this);
			model.addDeleteListener(this.handleDataRemoved, this);
		}
		else{
			console.error('[ERROR] BubblesView.constructor - The provided model is not a LiveQueryModel. Data will likely not be displayed for this BubblesView.');
		}

		//Build the view and add it to the DOM
		this.container = $('<div class="piechart-container" style="width: ' + size + 'px; height:' + size + 'px; "></div>');
		this.chart = buildChart(this.container[0], config);
		$(element).append(this.container);

	}
	BubblesView.prototype = {
		constructor: BubblesView,
		handleDataAdded: function(tuple){
			this.chart.series[0].addPoint([
				tuple.fieldMap[this.config.categoryField],
				tuple.fieldMap[this.config.valueField]
			]);
			//keep a reference to the data point for later updates and/or removal
			this.viewModel[tuple.id] = this.chart.series[0].data[this.chart.series[0].data.length-1];
			//console.log('in BubblesView, tuple added');
			//console.log(tuple);
			if(tuple.fieldMap.SYS_ID == 'C101'){
				console.log('in C101');
				bubbles('insert', tuple, 'c101_bubble');
			}
			else if(tuple.fieldMap.SYS_ID == 'C104'){
				console.log('in C104');
				bubbles('insert', tuple, 'c104_bubble');
			}
			
		},
		handleDataUpdated: function(tuple){
			this.viewModel[tuple.id].update([
				tuple.fieldMap[this.config.categoryField],
				tuple.fieldMap[this.config.valueField]
			]);
			console.log('in BubblesView, tuple updated');
			console.log(this.viewModel);
			bubbles('update', tuple, 'c101_bubble');
		},
		handleDataRemoved: function(tuple){
			
			this.viewModel[tuple.id].remove();
			//remove the datapoint from the viewModel map
			delete this.viewModel[tuple.id];
			console.log('in BubblesView, tuple deleted');
			console.log(this.viewModel);
			bubbles('delete', tuple, 'c101_bubble');
		}
	};

	function buildChart(element, config){
		/*
		console.log('in buildChart in BubblesView');
		console.log(element);
		console.log(config);
		*/
		var hcConfig;
		config = config || {};
		hcConfig = {
			chart: {
				renderTo: element
			},
			title: {
				text: config.title || ''
			},
			plotOptions: {
				pie: {
					dataLabels: {
						enabled: false
					},
					showInLegend: (config.legend instanceof Object)
				}
			},
			legend: config.legend || {},
			series: [{
				type: 'pie',
				name: config.valueField
			}]
		};
		return new Highcharts.Chart(hcConfig);
	}

	return BubblesView;

})(jQuery);