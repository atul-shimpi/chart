var TableView = (function($){
	'use strict';
	/**
	 * A live-updating HTML table view.
	 * @class TableView
	 * @param {LiveViewQueryService.LiveQueryModel} model The model to be used to drive data in this View
	 * @param {Element} element The the DOM element that this visualization should render in.
	 * @param {Object} [config] An object containing the parameters used to configure this Table
	 * @param {Object} [config.fieldNameToTitleMap] Object that maps tuple field name to the value to use as the Table column header. Like avgMonthyIncome: 'Average Monthly Income'
	 */
	function TableView(model, element, config){
		this.model = model;
		this.schema = null;
		this.element = element;
		this.config = config || {};

		//Subscribe to model updates so we can update the table view
		if(model instanceof LiveViewQueryService.LiveQueryModel){
			model.addSchemaListener(this.handleSchemaSet, this);
			model.addInsertListener(this.handleDataAdded, this);
			model.addUpdateListener(this.handleDataUpdated, this);
			model.addDeleteListener(this.handleDataRemoved, this);
		}
		else{
			console.error('[ERROR] TableView.constructor - The provided model is not a LiveQueryModel. Data will likely not be displayed for this TableView.');
		}

		//Build the table view and add it to the DOM, keep references to DOM elements to simplify handling of query events
		this.container = $('<div class="table-responsive"><br/></div>');
		this.table = $('<table class="table table-striped"></table>');
		this.tableHead = $('<thead></thead>');
		this.tableBody = $('<tbody></tbody>');

		this.table.append(this.tableHead);
		this.table.append(this.tableBody);
		this.container.append(this.table);
		$(element).append(this.container);
	}

	TableView.prototype = {
		constructor: TableView,

		handleSchemaSet: function(schema){
			//An array to store the <th> elements that will be used in the header row
			var cells = [];
			//A map that allows us to use something other than the fieldName as the column header text
			var titleMap = this.config.fieldNameToTitleMap || {};

			this.schema = schema;
			//Create a column header for each of the fields defined in the schema
			schema.fields.forEach(function(schemaField){
				cells.push('<th>' + (titleMap[schemaField.name] || schemaField.name) + '</th>');
			});
			this.tableHead.append('<tr>' + cells.join('') + '</tr>');
		},
		handleDataAdded: function(tuple){
			//An array to store the <td> elements that will be used in the data row
			var cells = [];
			this.schema.fields.forEach(function(schemaField){
				cells.push('<td>' + tuple.fieldMap[schemaField.name] + '</td>');
			});
			this.tableBody.append('<tr id="tuple_' + tuple.id + '">' + cells.join('') + '</tr>');
		},
		handleDataUpdated: function(tuple){
			var cell, //the cell element whose value needs to be updated
				fieldValue, //the new value to set in the cell
				fields = this.schema.fields, //short-hand reference to the schema's fields array
				updatedRow = $('#tuple_' + tuple.id); //the table row that contains the cell to update

			//for each updated field in the tuple, locate its table cell and update the value
			for(var i = 0; i < fields.length; i++){
				fieldValue = tuple.fieldMap[fields[i].name];
				if(typeof(fieldValue) !== 'undefined'){
					cell = updatedRow.find('td').eq(i);
					if(cell.length){
						cell.html(fieldValue);
					}
				}
			}
		},
		handleDataRemoved: function(tuple){
			$('#tuple_' + tuple.id).remove();
		}
	};

	return TableView;
})(jQuery);
