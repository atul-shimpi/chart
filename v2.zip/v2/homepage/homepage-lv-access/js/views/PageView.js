var PageView = (function($){
	'use strict';

	/**
	 * Displays a page which is composed of sections which are composed of components
	 * @param {Element} element The DOM element in which this PageView should render
	 * @param {Object} model The object that will determine what data is displayed in this view
	 * @param {Object} [config] Optional key-value pair object that defines settings for the PageView
	 * @constructor
	 */
	function PageView(element, model, config){

		//make sure this is what we expect it to be
		if(this instanceof PageView === false){
			return new PageView(element, model, config);
		}

		this.element = element;
		this.config = config || {};
		this.setModel(model);
	}
	PageView.prototype = {
		constructor: PageView,
		setModel: function(model){
			var sectionElements = [];
			var pageElement = $(this.element);

			this.model = model;

			//clear the page display (pageElement.children() is pseudo Array thus the use of Array.prototype.forEach)
			Array.prototype.forEach.call(
				pageElement.children(),
				function(child){
					child.remove();
				}
			);

			//add page title if one is specified
			if(this.model.title){
				pageElement.append('<h1 class="page-header">' + this.model.title + '</h1>');
			}

			//add page sections and their contained components
			model.sections.forEach(function(sectionModel, sectionId){
				var componentsContainer;
				sectionElements[sectionId] = $('<div class="page-section"></div>');

				if(sectionModel.title){
					sectionElements[sectionId].append('<h2 class="sub-header">' + sectionModel.title + '</h2>');
				}
				componentsContainer = $('<div class="row"></div>');
				sectionModel.components.forEach(function(component){
					var componentElement, componentModel, colSpan, height;
					componentModel = new LiveViewQueryService.LiveQueryModel({queryString: component.query});
					colSpan = isNaN(component.colSpan) ? 12:component.colSpan;
					height = isNaN(component.height) ? 300:component.height;
					componentElement = $('<div class="col-md-' + colSpan + '" style="height:' + height + 'px;"></div>');
					switch(component.visualizationType){
						case('table'):
							new TableView(componentModel, componentElement, component.visualizationConfig);
							break;
						case('gauge'):
							new GaugeView(componentModel, componentElement, component.visualizationConfig);
							break;
						case('pie'):
							new PieChartView(componentModel, componentElement, component.visualizationConfig);
							break;
						case('chart'):
							new ChartView(componentModel, componentElement, component.visualizationConfig);
							break;
						case('bubbles'):
							new BubblesView(componentModel, componentElement, component.visualizationConfig); // this does not turn out as intended
							break;
						default:
							console.error('[ERROR] PageView - Cannot create component of type: ' + component.visualizationType);
					}
					componentModel.run();
					componentsContainer.append(componentElement);
				});
				sectionElements[sectionId].append(componentsContainer);
				pageElement.append(sectionElements[sectionId]);
			});
		}
	};

	return PageView;

})(jQuery);
