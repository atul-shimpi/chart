/**
 * This variable provides the model data for our application. All that's needed to alter what pages exist in the
 * dashboard, what sections exist in each page, what components are shown in each section, what visualization to
 * display in each component, or what query to use as the data source for a component is to modify this object.
 */
var appModel = { // var name to be changed to appModel_gc
	defaultView: 'HP',
	views: {
		HP: {
			name: 'HP',
			components: [
				{	
					query: new LiveView.Query('select count() as cnt, Status from MSTStoreServerStatus where Status !="Green" group by Status'), 
					visualization: new AlertNotification({
						value: 'cnt',
						elementId: 'store_infr_alerts',
						spanID: 'store_infr_alerts_span'

					})
				},
				{	
					query: new LiveView.Query('select count() as cnt, color as Status from StoreFulfillmentServers where color!="Green" group by color'),
					visualization: new AlertNotification({
						value: 'cnt', 
						elementId: 'store_appl_alerts', 
						spanID: 'store_appl_alerts_span' 

					})
				},
				{	
					query: new LiveView.Query('select count() as cnt, Status from StoreDatabaseLive where Status!="Green" group by Status'),
					visualization: new AlertNotification({
						value: 'cnt', 
						elementId: 'store_db_alerts', 
						spanID: 'store_db_alerts_span' 

					})
				},
			]
		}
	}
};
