//
// Copyright (c) 2014-2015 TIBCO Software Inc. All rights reserved.
//
'use strict';

var myData;

var MSTFlow = (function($){
    //this.canvas = null;
    //this.d2cFont = null;
	
	function MSTFlow(settings){
		this.canvas = null;
    this.d2cFont = null;
    this.render();
    
    
	}
  
   // done
  fabric.Canvas.prototype.getPlatformName = function(name) {
    var object = null,
    objects = this.getObjects();

    for (var i = 0, len = this.size(); i < len; i++) {          
      if (objects[i].type && objects[i].type == 'platform' && objects[i].name && objects[i].name === name) {
        object = objects[i];
        break;
      }
    }

    return object;
  }
      
	MSTFlow.prototype = $.extend(
		new Visualization(),
		{
      
			refresh: function(){
				var i;
				//sync viewModel with data
				this.viewModel = [];
				for(i = 0; i < this.data.length; i++){
					if(this.data[i]){
						this.viewModel.push(this.data[i].fieldMap);
            this.updateMap(this.data[i].fieldMap);
					}
				}
        //this.updateMap(data[data.length - 1]);
				//this.render();
			},
     
      // sumanth - done
      setUpCanvas: function() {
        this.canvas = new fabric.Canvas('c');
        this.canvas.hoverCursor = 'arrow';
        
        this.canvas.on('mouse:down', function(options) {
          console.log(options.target);
          if (options.target) {    
            var clicked_id = options.target.get('id')
              if (clicked_id == 'status') {
                //alert('Threshold is 60.00 %');
              }
          }
        });
      },
      // in done (drawSubwayMap())
			render: function(){
      
				//console.log('Rendering MSTFlow to ' + this.settings.elementId);
				//var data = this.viewModel;

				//console.log(data.length);
				//console.log(data[0].BAEendPoint);
				//console.log("Done");
				//myData = data;
				// 
				
        // sumanth
        
       
        this.setUpCanvas();
        var horizontalSpacing = 122;
        
        // wms
        this.drawJunction({name: 'd2cOrder', text: '   D2C\nORDER', top: 80, left: 20});
        this.drawStation({name: 'intFedfil', text: 'INTEGRATED\n IN FEDFIL', top: 80, left: horizontalSpacing});
        this.drawStation({name: 'inProcess', text: 'IN PROCESS', top: 80, left: horizontalSpacing * 2});
        this.drawStation({name: 'wms', text: 'WMS', top: 80, left: horizontalSpacing * 3});
        this.drawStation({name: 'readyToPick', text: 'READY TO PICK', top: 80, status: 'normal', left: horizontalSpacing * 4});
        this.drawStation({name: 'readyToFill', text: 'READY TO FILL', top: 80, left: horizontalSpacing * 5});
        this.drawStation({name: 'fillInWms', text: 'FILL IN WMS', top: 80, status: 'normal', left: horizontalSpacing * 6});
        this.drawStation({name: 'ack', text: 'ACKNOWLEDGED', top: 80, left: horizontalSpacing * 7});
        this.drawStation({name: 'shipConfirmed', text: 'SHIP\nCONFIRMED', top: 80, left: horizontalSpacing * 8});
        this.drawJunction({name: 'shipClosed', text: '   SHIP\nCLOSED', top: 80, left: 1100});
        this.drawRoute({left: 100, top: 80, width: 1000});
        
        
        // joppa
        this.drawStation({name: 'joppa', text: 'JOPPA', top: 180, left: horizontalSpacing * 3});
        this.drawStation({name: 'readyToPick', text: 'READY TO PICK', top: 180, left: horizontalSpacing * 4});
        this.drawStation({name: 'readyToFill', text: 'READY TO FILL', top: 180, left: horizontalSpacing * 5});
        this.drawStation({name: 'filkpikIntegrated', text: 'FILKPIK INTEGRATED', top: 180, left: horizontalSpacing * 6});
        this.drawStation({name: 'shipConfirmed', text: 'SHIP CONFIRMED', top: 180, left: horizontalSpacing * 8});
        
        // route - joppa to ship confirmed       
        this.drawRouteJoppa({left: horizontalSpacing * 3, top: 160, width: 620}, 230);
        
        this.canvas.selection = false;
        this.canvas.forEachObject(function(o) {
          o.selectable = false;
        });
        
        //console
        console.log("Map rendered");
        //this.updateMap(data[0]); 

			},
      
      // Junction (ex D2Corder, POClosed) done
      drawJunction: function(junction) { 
        var junction_ = {name: junction.name, stroke: 'black', strokeWidth: 1, fill: "RGB(233, 243, 253)",
                          border: "1px solid black", width: 80, height: 100};
        
        junction_.top = junction.top;
        junction_.left = junction.left;
        var rect = new fabric.Rect(junction_);
        
        this.d2cFont = {color: 'black', fontWeight: "normal", fontSize: 12, fontFamily: 'Arial' }
        var shadow = { color: 'grey', blurx: 20, offsetX: 2, offsetY: 2, opacity: 0.6, fillShadow: true,
                     strokeShadow: true };  
     
        rect.setShadow(shadow);
        this.d2cRect = rect;
        this.canvas.add(rect);
        
        this.d2cFont.left = junction.left + 15;
        this.d2cFont.top = 115;
        
        var text = new fabric.Text(junction.text, this.d2cFont);
        
        this.canvas.add(text);              
      },
      // done
      // draw station (ex 'INTEGRATED IN FEDFIL', PO CLOSED')
      drawStation: function (station) {
        var fedFilRect = {name: station.name, left: station.left, top: station.top, stroke: 'blue', strokeWidth: 1, fill: "white",
                            border: "1px solid blue", rx: 8, ry: 8, width: 100, height: 80};
                            
        var fedfillFont = {  color: 'black', fontWeight: "normal", fontSize: 10, fontFamily: 'Arial' };
        
        var rectFedFill = new fabric.Rect(fedFilRect);
       
        this.canvas.add(rectFedFill);
        
        this.d2cFont.left = rectFedFill.left + 3;
        this.d2cFont.top = rectFedFill.top + 5;
        
        this.d2cFont.fontSize = 11;
        var text = new fabric.Text(station.text, this.d2cFont);
        
        this.canvas.add(text);
        
        fedFilRect.status = station.status;
        fedFilRect.name = station.name;
        
        this.drawPlatform(fedFilRect);
      },
      // done
      drawPlatform: function(platform) {
        var statusRect = {type: 'platform', name: platform.name, id: 'status', stroke: 'rgba(34,177,76,1)', strokeWidth: 3, fill: "black",
                          top: platform.top + platform.height/1.7, width: platform.width - 20, height: 6};
        
        if (platform.status) {
          statusRect.stroke = {normal: 'green', warning: 'yellow', critical: 'red'}[platform.status];
        }
        statusRect.left = platform.left + 10;
        
               
        var status = new fabric.Rect(statusRect);
         status.hoverCursor = 'pointer';
       
        
        
        
        this.canvas.add(status); 
      },
      // done
      updateState: function(platformName, statusColor) {
        //setAllPlatforms2Normal();
        //var obj = canvas.getPlatformName('intFedfil');
        var obj = this.canvas.getPlatformName(platformName);
        
        obj.setStroke(statusColor);        
        this.canvas.renderAll();
      },
      // done
      drawRoute: function(route) {
        var statusRect = {fill: "black", width: 40, height: 3};
        
        statusRect.left = route.left;
        statusRect.width = route.width;
        
        statusRect.top = (this.d2cRect.top + 49);
        var status = new fabric.Rect(statusRect);
       
        this.canvas.add(status);        
      },
      drawRouteJoppa: function(route, top) {
        var statusRect = {fill: "black", width: 40, height: 3};
        
        statusRect.left = route.left;
        statusRect.width = route.width;
        
        statusRect.top = top;
        var status = new fabric.Rect(statusRect);
       
        this.canvas.add(status);        
      },
      // done
      setAllPlatforms2Normal: function() {
        var objects = this.canvas.getObjects();
      
        for (var i = 0; i < objects.length; i++) {          
          if (objects[i].type && objects[i].type == 'platform') {           
            objects[i].setStroke('green');           
          }
        }
      },
      // sumanth - done
      updateMap: function(data) {
        if (['WMS FULFILLMENT FLOW', 'FIL', 'ORDER FULFILLMENT FLOW']
            .indexOf(data.MapName) == -1 ) {
            return;
        }
        
        var stations = [ {bamKey: 'FedFil', ourKey: 'intFedfil'},
                         {bamKey: 'In Process', ourKey: 'inProcess'},
                         {bamKey: 'FedFil', ourKey: 'wms'},
                         {bamKey: 'Ready to Pick', ourKey: 'readyToPick'},
                         {bamKey: 'Ready to Fill', ourKey: 'readyToFill'},
                         {bamKey: 'FIL to WMSv', ourKey: 'fillInWms'},
                         {bamKey: 'Acknowledged', ourKey: 'ack'},
                         {bamKey: 'Ship Confirmed', ourKey: 'shipConfirmed'} ];
       
        var this_ = this;
        
        stations.forEach(function(item) {         
          if (item.bamKey === data.flowHeader) {
            console.log(data.MapName);
            this_.updateState(item.ourKey, data.flowStatus);
            return;
          }
        });
      }
      
		}
	);

	return MSTFlow;

})(jQuery);

function ReturnData() {
	return myData;
}
