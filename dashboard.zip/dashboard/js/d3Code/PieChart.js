//
// Copyright (c) 2014-2015 TIBCO Software Inc. All rights reserved.
//
'use strict';
var PieChart = (function($){

	/**
	 * This object wraps a D3 Pie chart. It is meant to be reusable, but is limited in the configuration options made
	 * available. It extends from the Visualization base object which maintains its data model.
	 * @class PieChart
	 * @param {Object} settings An object containing the parameters used to configure this PieChart
	 * @param {String} settings.elementId The element ID of the DOM element that this visualization should render in.
	 * @param {String} [settings.categoryField] The field name of the category field in the data model.
	 * @param {String} [settings.valueField] The field name of the value field in the data model.
	 */
	function PieChart(settings){
		this.schema = {};
		this.data = [];
		this.html = '<div>PieChart goes here</div>';
		this.settings = settings || {elementId: ''};
		this.settings.categoryField = settings.categoryField || 'category';
		this.settings.valueField = settings.valueField || 'value';
		this.viewModel = [];
	}

	PieChart.prototype = $.extend(
		new Visualization(),
		{
			constructor: PieChart,

			refresh: function(){
				var i;
				//sync viewModel with data
				this.viewModel = [];
				for(i = 0; i < this.data.length; i++){
					if(this.data[i]){
						this.viewModel.push(this.data[i].fieldMap);
					}
				}
				this.render();
			},

			render: function(){
				var element, width, height, radius, color, arc, pie, svg, g, self;

				//console.log('Rendering PieChart to ' + this.settings.elementId);
				self = this;
				element = d3.select('#' + this.settings.elementId);
				width = 130;
				height = 120;
				radius = Math.min(width, height) / 2.1;

				// color = d3.scale.category20().range(randomColors);
				color = d3.scale.category20();
				arc = d3.svg.arc()
					.outerRadius(radius)
					.innerRadius(0);


				pie = d3.layout.pie()
					.sort(null)
					.value(function(d){
						return d[self.settings.valueField];
					});

				element.selectAll('svg').remove();
				svg = element
					.append('svg')
					.attr('width', width + width/2)  // add 150 pixel for legend space
					.attr('height', height)
					.append('g')
					.attr('transform', 'translate(' + width / 2 + ',' + height / 2 + ')');

				g = svg.selectAll('.arc')
					.data(pie(this.viewModel))
					.enter()
					.append('g')
					.attr('class', 'arc');

				g.append('path')
					.attr('d', arc)
					.style('fill', function(d){
						return color(d.data[self.settings.categoryField]);
					})
					.attr('stroke', 'white')
					.attr('stroke-width', 1)
					.attr('stroke-linejoin', 'round')
					.attr('title', function(d, i){
						return d.data[self.settings.categoryField];
					});

				// text

				/*
				g.append('text')
					.attr('transform', function(d){
						return 'translate(' + arc.centroid(d) + ')';
					})
					.attr('dy', '.35em')
					.style('text-anchor', 'middle')
					.text(function(d){
						return d.data[self.settings.categoryField];
					});
				*/
				// label
				// color

				svg.selectAll('.rect')
					.data(pie(this.viewModel))
					.enter()
					.append('rect')
					.attr('width', 20)
					.attr('height', 10)
					.attr('x', width-70)
					.attr('y', function(d, i){
						return i*12-height/2;
					})
					.attr('fill', function(d, i){
						return color(d.data[self.settings.categoryField]);
					})
					.attr('rx', 10)
					.attr('ry', 10);
				// text
				svg.selectAll('.text')
					.data(pie(this.viewModel))
					.enter()
					.append('text')
					.attr('x', width-25)
					.attr('y', function(d, i){
						return (i+0.6)*12-height/2;
					})
					.attr('fill', function(d, i){
						return color(d.data[self.settings.categoryField]);
					})
					.text(function(d){
						return d.data[self.settings.categoryField];
					})
					.attr('text-anchor', 'middle')
					.attr('font-size', 10);
			}
		}
	);

	return PieChart;
})(jQuery);
