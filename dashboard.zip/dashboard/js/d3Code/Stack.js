//
// Copyright (c) 2014-2015 TIBCO Software Inc. All rights reserved.
//
'use strict';
var Stack = (function($){

	/**
	 * This object wraps a straight-forward stack chart. It is meant to be reusable, but is limited in the configuration
	 * options made available. It extends from the Visualization base object which maintains its data model.
	 * @class Stack
	 * @param {Object} settings An object containing the parameters used to configure this Stack
	 * @param {String} settings.elementId The element ID of the DOM element that this visualization should render in.
	 * @param {String} [settings.categoryField] The field name of the category field in the data model.
	 * @param {String} [settings.valueField] The field name of the value field in the data model.
	 */
	function Stack(settings){
		this.schema = {};
		this.data = [];
		this.html = '<div>Stack goes here</div>';
		this.settings = settings || {elementId: ''};
		this.settings.categoryField = settings.categoryField || 'category';
		this.settings.valueField = settings.valueField || 'value';
		// if adding more stuff in the app.model.js, add them here as well
		this.viewModel = [];
	}

	Stack.prototype = $.extend(
		new Visualization(),
		{
			refresh: function(){
				var i;
				//sync viewModel with data
				this.viewModel = [];
				for(i = 0; i < this.data.length; i++){
					if(this.data[i]){
						this.viewModel.push(this.data[i].fieldMap);
					}
				}
				this.render();
			},
			render: function(){
				//console.log('Rendering Stack to ' + this.settings.elementId);
				var data = this.viewModel,
					//element = d3.select('#' + this.settings.elementId),
					self = this,
					svgWidth = 350,
					svgHeight = data.length * 30;

				// all size related code should be determined somehow by:
				// svgWidth for width, y
				// svgHeight for height, x

				var element = d3.select('#' + this.settings.elementId);
				element.selectAll('svg').remove();

				var svg = element.append('svg')
					.attr('width', svgWidth)
					.attr('height', svgHeight);



				svg.selectAll('.rect')
					.data(data)
					.enter()
					.append('rect')
					.attr('width', svgWidth * 1/2)
					.attr('height', svgHeight/13)
					.attr('x', svgWidth * 1/4)
					.attr('y', function(d, i){
						return (i+.1)*svgHeight/10;
					})
					.attr('fill', function(d, i){
						if(self.settings.storyName == 'CICS_stack'){
							if(d[self.settings.valueField] == 'R'){
								return 'red';
							}
							else if(d[self.settings.valueField] == 'Y'){
								return 'yellow';
							}
							else{
								return 'lime';
							}
						}
					})
					.attr('stroke-width', 3)
					.attr('stroke', 'black')
					.attr('opacity', .8)
					.attr('rx', 10)
					.attr('ry', 10);

				svg.selectAll('.text')
					.data(data)
					.enter()
					.append('text')
					.attr('x', svgWidth * 1/2)
					.attr('y', function(d, i){
						return (i+.65)*svgHeight/10;
					})
					.text(function(d, i){
						return data[i][self.settings.categoryField];
					})
					.attr('font-size', 15)
					.attr('font-family', "Times New Roman")
					.attr('fill', 'white')
					.attr('text-anchor', 'middle');

			}
		}
	);

	return Stack;

})(jQuery);
