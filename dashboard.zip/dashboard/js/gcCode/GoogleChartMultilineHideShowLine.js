//
// Copyright (c) 2014-2015 TIBCO Software Inc. All rights reserved.
//
'use strict';


var GoogleChartMultilineHideShowLine = (function($){
	/**
	 * This object wraps a straight-forward GoogleChartMultilineHideShowLine chart. It is meant to be reusable, but is limited in the configuration
	 * options made available. It extends from the Visualization base object which maintains its data model.
	 * @class GoogleChartMultilineHideShowLine
	 * @param {Object} settings An object containing the parameters used to configure this GoogleChartMultilineHideShowLine
	 * @param {String} settings.elementId The element ID of the DOM element that this visualization should render in.
	 * @param {String} [settings.categoryField] The field name of the category field in the data model.
	 * @param {String} [settings.valueField] The field name of the value field in the data model.
	 */
	function GoogleChartMultilineHideShowLine(settings){
		this.schema = {};
		this.data = [];
		this.html = '<div>GoogleChartMultilineHideShowLine goes here</div>';
		this.settings = settings || {elementId: ''};
		this.settings.categoryField = settings.categoryField || 'category';
		this.settings.valueField = settings.valueField || 'value';
		// if adding more stuff in the app.model.js, add them here as well
		this.viewModel = [];
	}

	GoogleChartMultilineHideShowLine.prototype = $.extend(
		new Visualization(),
		{
			refresh: function(){
				var i;
				//sync viewModel with data
				this.viewModel = [];
				for(i = 0; i < this.data.length; i++){
					if(this.data[i]){
						this.viewModel.push(this.data[i].fieldMap);
					}
				}
				this.render();
			},
			render: function(){
				/*
				var data = this.viewModel,
					self = this;
				console.log(data);
				*/

				var self = this;

      			// Set a callback to run when the Google Visualization API is loaded.
      			google.charts.setOnLoadCallback(drawChart);

				
      			function drawChart(){
      				var rawData = self.viewModel,
		        	data = new google.visualization.DataTable(),
		        	rows;
		        	// console.log(self.settings.columnNames.columnHeader);
		        	// this wasn't able to be achieved from the app.model.js 

		        	// story specific
		        	if(self.settings.storyName == '10 Minutes Order Interval'){

						rows = [['TS', 'Macy\'s RT', 'Bloomingdale\'s RT', 'Macy\'s Batch', 'Bloomingdale\'s Batch']];
						//rows = self.settings.columnNames.columnHeader;
						
					}
		        	// rows = self.settings.columnNames;
			        // console.log(rawData);

			        // this is necssary for render
			        var element = d3.select('#' + self.settings.elementId);
					element.selectAll('svg').remove();
				    if(self.settings.howManyLines == 4){
					    for(var i=0; i < rawData.length; i++){
				        	rows.push([
				        		new Date(rawData[i][self.settings.xAxis]),
			        	 		rawData[i][self.settings.line1], 
			        	 		rawData[i][self.settings.line2], 
			        	 	    rawData[i][self.settings.line3], 
			        	 		rawData[i][self.settings.line4]
		        	 		]);
				        }	
				    }
				    
			        // console.log(rows);
				    var data = google.visualization.arrayToDataTable(rows);

			     
			        // Instantiate and draw our chart, passing in some options.
			        var chart = new google.visualization.ChartWrapper({
			            chartType: 'LineChart',
			            containerId: self.settings.elementId,
			            dataTable: data,
			            options: self.settings.options
			        });
			        
			        // create columns array
			        var columns = [0];
			        /* the series map is an array of data series
			         * "column" is the index of the data column to use for the series
			         * "roleColumns" is an array of column indices corresponding to columns with roles that are associated with this data series
			         * "display" is a boolean, set to true to make the series visible on the initial draw
			         */
			        var seriesMap = [{
			            column: 1,
			            roleColumns: [],
			            display: true,
			            color: 'orange'
			        }, {
			            column: 2,
			            roleColumns: [],
			            display: true,
			            color: 'blue'
			        }, {
			            column: 3,
			            roleColumns: [],
			            display: true,
			            color: 'pink'
			        },{
			            column: 4,
			            roleColumns: [],
			            display: true,
			            color: 'lime'
			        }];
			        var columnsMap = {};
			        var series = [];
			        for (var i = 0; i < seriesMap.length; i++) {
			            var col = seriesMap[i].column;
			            columnsMap[col] = i;
			            // set the default series option
			            series[i] = {};
			            if (seriesMap[i].display) {
			                // if the column is the domain column or in the default list, display the series
			                columns.push(col);
			            }
			            else {
			                // otherwise, hide it
			                columns.push({
			                    label: data.getColumnLabel(col),
			                    type: data.getColumnType(col),
			                    sourceColumn: col,
			                    calc: function () {
			                        return null;
			                    },
			                    color: 'black'
			                });
			                // backup the default color (if set)
			                /*
			                if (typeof(series[i].color) !== 'undefined') {
			                    series[i].backupColor = series[i].color;
			                }
			                series[i].color = '#CCCCCC';
			                */
			            }
			            for (var j = 0; j < seriesMap[i].roleColumns.length; j++) {
			                columns.push(seriesMap[i].roleColumns[j]);
			            }
			        }

			        
			        
			        chart.setOption('series', self.settings.options.series);
			        
			        function showHideSeries () {
			            var sel = chart.getChart().getSelection();
			            // if selection length is 0, we deselected an element
			            if (sel.length > 0) {
			                // if row is undefined, we clicked on the legend
			                if (sel[0].row == null) {
			                    var col = sel[0].column;
			                    if (typeof(columns[col]) == 'number') {
			                        var src = columns[col];
			                        
			                        // hide the data series
			                        columns[col] = {
			                            label: data.getColumnLabel(src),
			                            type: data.getColumnType(src),
			                            sourceColumn: src,
			                            calc: function () {
			                                return null;
			                            }
			                        };
			                        
			                        // grey out the legend entry
			                        series[columnsMap[src]].color = '#CCCCCC';
			                    }
			                    else {
			                        var src = columns[col].sourceColumn;
			                        
			                        // show the data series
			                        columns[col] = src;
			                        series[columnsMap[src]].color = null;
			                    }
			                    var view = chart.getView() || {};
			                    view.columns = columns;
			                    chart.setView(view);
			                    chart.draw();
			                }
			            }
			        }
			        
			        google.visualization.events.addListener(chart, 'select', showHideSeries);
			        
			        // create a view with the default columns
			        var view = {
			            columns: columns
			        };
			        chart.draw();
				    
      			};
			}
		}
	); // 

	return GoogleChartMultilineHideShowLine;

})(jQuery);
