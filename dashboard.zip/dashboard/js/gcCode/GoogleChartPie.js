//
// Copyright (c) 2014-2015 TIBCO Software Inc. All rights reserved.
//
'use strict';


var GoogleChartPie = (function($){
	/**
	 * This object wraps a straight-forward GoogleChartPie chart. It is meant to be reusable, but is limited in the configuration
	 * options made available. It extends from the Visualization base object which maintains its data model.
	 * @class GoogleChartPie
	 * @param {Object} settings An object containing the parameters used to configure this GoogleChartPie
	 * @param {String} settings.elementId The element ID of the DOM element that this visualization should render in.
	 * @param {String} [settings.categoryField] The field name of the category field in the data model.
	 * @param {String} [settings.valueField] The field name of the value field in the data model.
	 */
	function GoogleChartPie(settings){
		this.schema = {};
		this.data = [];
		this.html = '<div>GoogleChartPie goes here</div>';
		this.settings = settings || {elementId: ''};
		this.settings.categoryField = settings.categoryField || 'category';
		this.settings.valueField = settings.valueField || 'value';
		// if adding more stuff in the app.model.js, add them here as well
		this.viewModel = [];
	}

	GoogleChartPie.prototype = $.extend(
		new Visualization(),
		{
			refresh: function(){
				var i;
				//sync viewModel with data
				this.viewModel = [];
				for(i = 0; i < this.data.length; i++){
					if(this.data[i]){
						this.viewModel.push(this.data[i].fieldMap);
					}
				}
				
				this.render();
			},
			render: function(){
				/*
				var data = this.viewModel,
					self = this;
				console.log(data);
				*/
				var self = this;
      			// Set a callback to run when the Google Visualization API is loaded.
      			google.charts.setOnLoadCallback(drawChart);
				
      			// drawChart() is to guarantee that DataTable() will be loaded before vis is to be drawn
      			function drawChart(){
      				var rawData = self.viewModel,
			        	data = new google.visualization.DataTable(),
			        	rows = [];

			        // this is necssary for render
			        var element = d3.select('#' + self.settings.elementId);
					element.selectAll('svg').remove();

					// console.log(rawData);

			        data.addColumn('string', self.settings.categoryField);
			        data.addColumn('number', self.settings.valueField);

			        for(var i=0; i < rawData.length; i++){
			        	rows.push([rawData[i][self.settings.categoryField], rawData[i][self.settings.valueField]]);
			        	//console.log([rawData[i][self.settings.categoryField], rawData[i][self.settings.valueField]]);
			        }
			        // console.log(rows);
			        // console.log(rows);
			        data.addRows(rows);

			        // Set chart options
			        
			        // Instantiate and draw our chart, passing in some options.
			        var chart = new google.visualization.PieChart(document.getElementById(self.settings.elementId));
			        chart.draw(data, self.settings.options);	
      			};
			}
		}
	);

	return GoogleChartPie;

})(jQuery);
