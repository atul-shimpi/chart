/**
 * Utility for maintaining LiveView query result data. LiveView update and delete events do not contain complete tuple
 * data, so visualizations that depend on complete data in order to render data updates and/or deletes will need a
 * reference data set. The TupleStore fulfills that need.
 */
var TupleStore = (function($){
	'use strict';

	function TupleStore(){
		this.data = [];
		this.map = {};
		this.schema = undefined;
	}
	TupleStore.prototype = {
		constructor: TupleStore,
		addTuple: function(tuple){
			this.data.push(tuple);
			this.map[tuple.id] = tuple;
		},
		updateTuple: function(updatedTuple){
			var index;
			try{
				index = this.data.indexOf(this.map[updatedTuple.id]);
				$.extend(this.map[updatedTuple.id].fieldMap, updatedTuple.fieldMap);
				return index;
			}
			catch(err){
				console.warn('Failed to update tuple. New value will be ignored.');
				console.debug('TupleStore.updateTuple:', err);
				return -1;
			}
		},
		deleteTuple: function(deletedTuple){
			var index;
			try{
				index = this.data.indexOf(this.map[deletedTuple.id]);
				this.data.splice(index, 1);
				delete this.map[deletedTuple.id];
				return index;
			}
			catch(err){
				console.warn('Failed to delete tuple. Tuple will not be removed.');
				console.debug('TupleStore.deleteTuple:', err);
				return -1;
			}
		},
		indexOf: function(tuple){
			return this.data.indexOf(tuple);
		},
		clearData: function(){
			this.data = [];
			this.map = {};
		},
		clear: function(){
			this.clearData();
			this.schema = undefined;
		}
	};

	return TupleStore;
})(jQuery);