var ChartView = (function($){
	'use strict';
	
	/**
	 * A general-purpose Highcharts chart component
	 * @class ChartView
	 * @param {LiveViewQueryService.LiveQueryModel} model The model to be used to drive data in this View
	 * @param {Element} element The the DOM element that this visualization should render in.
	 * @param {Object} [config] An object containing the parameters used to configure this GaugeView
	 */
	function ChartView(model, element, config){
		if(this instanceof ChartView === false){
			return new ChartView(model, element, config);
		}

		this.model = model;
		this.viewModel = {};
		this.element = element;
		this.config = config || {};
		//alert(this.config.title);

		//Subscribe to model updates so we can update the view
		if(model instanceof LiveViewQueryService.LiveQueryModel){
			model.addInsertListener(this.handleDataAdded, this);
			//model.addUpdateListener(this.handleDataUpdated, this);
			model.addUpdateListener(this.handleDataAdded, this);
			//model.addDeleteListener(this.handleDataRemoved, this);
		}
		else{
			console.error('[ERROR] ChartView.constructor - The provided model is not a LiveQueryModel. Data will likely not be displayed for this ChartView.');
		}

		//Build the view and add it to the DOM
		this.container = $('<div class="chart-container" style="height:' + element.height() + 'px; "></div>');
		this.chart = buildChart(this.container[0], config);
		$(element).append(this.container);

		//Fix highcharts problem where chart doesn't fill the width of its container when initialized
		setTimeout((function(chart){
			return function(){ chart.reflow(); }
		})(this.chart), 0);
	}
	ChartView.prototype = {
		constructor: ChartView,

		/**
		 * Adds the appropriate chart data based on chart series configuration.
		 * @param tuple {LiveView.Tuple} The tuple that was added to the dataset and should be used to extract values to display in the chart.
		 */
		handleDataAdded: function(tuple){
			var seriesIndex, valueField;
			//Using the visualizationConfig.series array defined for this chart, construct each series by adding points
			//whose x-value is the value contained in the chart's category field and whose y-value is the value
			//contained in the value field for the particular series. Note we pass false as a second argument to
			//addPoint to avoid redrawing the chart until all points have been added.
			//console.log('chartview: add data');
			//alert('da: ' + tuple.fieldMap[this.config.categoryField] + " " + this.config.series.length);
			var shift; // shift if the series is longer than required
			for(seriesIndex = 0; seriesIndex < this.config.series.length; seriesIndex++){
				valueField = this.config.series[seriesIndex].valueField;
				console.log("add/updPoint" + seriesIndex + ": " + 
					tuple.fieldMap[this.config.categoryField] + " " + tuple.fieldMap[valueField]);
				shift = this.chart.series[seriesIndex].data.length > 10; // shift if the series is longer than required
				this.chart.series[seriesIndex].addPoint(
				[tuple.fieldMap[this.config.categoryField],	parseInt(tuple.fieldMap[valueField])],false, shift);
				//this.chart.series[seriesIndex].addPoint(['2016-12-07 18:35:02',parseInt(tuple.fieldMap[valueField])], false);
				//alert('added');
			}

			//now that all points have been added to the chart, redraw it on the page
			this.chart.redraw();

			//In order to easily update or remove points on future update and delete events, we add a reference to the
			//Highcharts point to the viewModel. Points are only available after the points have been added and the
			//chart has been redrawn.
			/*for(seriesIndex = 0; seriesIndex < window.chartview.config.series.length; seriesIndex++){
				if(window.chartview.viewModel[seriesIndex] == undefined){
					window.chartview.viewModel[seriesIndex] = {};
				}
				window.chartview.viewModel[seriesIndex][tuple.id] = window.chartview.chart.series[seriesIndex].data[window.chartview.chart.series[seriesIndex].data.length - 1];
			}*/
		},

		/**
		 * Handles data updates for the chart.
		 * @param tuple {LiveView.Tuple} The tuple that was updated in the query result dataset. Note that because our
		 * LiveViewService utilizes the TupleStore, we have access to all fields (updated or not) in the tuple.
		 */
		handleDataUpdated: function(tuple){
			//console.log('chartview: upd data');
			var seriesIndex, valueField;
			//For each of the series defined in the visualizationConfig.series array, look up the stored Point reference
			//using the updated tuple's ID, and update it with the new values. Again, we refrain from redrawing the
			//chart until all points have been updated.
			/*for(seriesIndex = 0; seriesIndex < window.cv.config.series.length; seriesIndex++){
				valueField = window.cv.config.series[seriesIndex].valueField;
				window.cv.viewModel[seriesIndex][tuple.id].update([
					tuple.fieldMap[window.cv.config.categoryField],
					tuple.fieldMap[valueField]
				], false);
				console.log("updatePoint: " + tuple.fieldMap[window.cv.config.categoryField] + " " + tuple.fieldMap[valueField]);
			}

			//now that all points have been updated on the chart, redraw it on the page
			window.cv.chart.redraw();*/
		},

		/**
		 * Handles data removal from the chart.
		 * @param tuple {LiveView.Tuple} The tuple that was removed in the query result dataset
		 */
		handleDataRemoved: function(tuple){
			var seriesIndex;

			//For each of the series defined in the visualizationConfig.series array, look up the stored Point reference
			//using the removed tuple's ID, and delete it. Again, we refrain from redrawing the chart until all points
			//have been removed.
			for(seriesIndex = 0; seriesIndex < this.config.series.length; seriesIndex++){
				if(!this.viewModel[seriesIndex] || !this.viewModel[seriesIndex][tuple.id]){
					continue;
				}
				this.viewModel[seriesIndex][tuple.id].remove(false);
			}
			delete this.viewModel[tuple.id];

			//now that all points have been updated on the chart, redraw it on the page
			this.chart.redraw();
		}
	};

	/**
	 * Builds a Highcharts chart to be rendered in the provided DOM element.
	 * @param element {Element} The DOM element in which the chart should render
	 * @param [config] {Object} Optional configuration object that can be used to define the characteristics of the constructed chart
	 * @returns {Highcharts.Chart} A reference to the Highcharts.Chart object that was created
	 */
	function buildChart(element, config){
		config = config || {};
		config.options = config.options || {};
		return new Highcharts.Chart({
			chart: $.extend( true,
				config.options.chart || {},
				{
					type: config.plotType || 'line',
					renderTo: element,
					animation: Highcharts.svg
				}
			),
			title: {text: config.title},
			xAxis: config.options.xAxis || {},
			yAxis: config.options.yAxis || {},
			tooltip: config.options.tooltip || {},
			legend: config.options.legend || {},
			plotOptions: config.options.plotOptions || {},
			series: config.series
			/*series: config.series.map(function(configSeriesItem){
				return $.extend({data: []}, configSeriesItem); //make sure each series config has a data property
			})*/
		});
	}

	return ChartView;

})(jQuery);