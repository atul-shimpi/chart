var PageView = (function($){
	'use strict';

	/**
	 * Displays a page which is composed of sections which are composed of components
	 * @param {Element} element The DOM element in which this PageView should render
	 * @param {Object} model The object that will determine what data is displayed in this view
	 * @param {Object} [config] Optional key-value pair object that defines settings for the PageView
	 * @constructor
	 */


	function PageView(element, model, config){
		
		//make sure this is what we expect it to be
		if(this instanceof PageView === false){
			return new PageView(element, model, config);
		}

		this.element = element;
		this.config = config || {};
		this.setModel(model);
		
		
	}
	PageView.prototype = {
		constructor: PageView,
		setModel: function(model){
			var sectionElements = [];
			var pageElement = $(this.element);
			var qryFinder = '<??>';
			var selServerName = ""
			if(window.location.search.length > 1)
				selServerName = window.location.search.substr(1);
			//alert('sn: ' + selStoreNumber);

			this.model = model;

			//clear the page display (pageElement.children() is pseudo Array thus the use of Array.prototype.forEach)
			Array.prototype.forEach.call(
				pageElement.children(),
				function(child){
					child.remove();
				}
			);

			//add page title if one is specified
			if(this.model.title){
				var strTitle;
				if(this.model.title.indexOf(qryFinder) >= 0 && selServerName.length > 0)
					strTitle = '<h3 class="page-header">' + this.model.title + ': ' + selServerName + '</h3>'
				else
					strTitle = '<h3 class="page-header">' + this.model.title + '</h3>'

				pageElement.append(strTitle);
			}

			//add page sections and their contained components
			model.sections.forEach(function(sectionModel, sectionId){
				var componentsContainer;
				sectionElements[sectionId] = $('<div class="page-section"></div>');

				if(sectionModel.title){
					sectionElements[sectionId].append('<h2 class="sub-header">' + sectionModel.title + '</h2>');
				}
				componentsContainer = $('<div class="row"></div>');
				sectionModel.components.forEach(function(component){
					var componentElement, componentModel, colSpan, height, revQueryString;

					revQueryString = component.query;
					if(revQueryString.indexOf(qryFinder) >= 0 && selServerName.length > 0)
						revQueryString = revQueryString.replace(qryFinder, selServerName);
					//alert('query: '+ revQueryString);
					
					componentModel = new LiveViewQueryService.LiveQueryModel({queryString: revQueryString});
					
					colSpan = isNaN(component.colSpan) ? 12:component.colSpan;
					height = isNaN(component.height) ? 300:component.height;
					componentElement = $('<div class="col-md-' + colSpan + '" style="width:900px;height:' + height + 'px;"></div>');
					switch(component.visualizationType){
						case('map'):
							new MapView(componentModel, componentElement, component.visualizationConfig);
							break;
						case('table'):
							new TableView(componentModel, componentElement, component.visualizationConfig);
							break;
						case('gauge'):
							new GaugeView(componentModel, componentElement, component.visualizationConfig);
							break;
						case('pie'):
							new PieChartView(componentModel, componentElement, component.visualizationConfig);
							break;
						case('chart'):
							new ChartView(componentModel, componentElement, component.visualizationConfig);
							break;
						case('textview'):
							new TextView(componentModel, componentElement, component.visualizationConfig);
							break;
						default:
							console.error('[ERROR] PageView - Cannot create component of type: ' + component.visualizationType);
					}
					componentModel.run();
					componentsContainer.append(componentElement);
				});
				sectionElements[sectionId].append(componentsContainer);
				pageElement.append(sectionElements[sectionId]);
			});
		}
	};

	return PageView;

})(jQuery);