var TextView = (function($){
	'use strict';
	
	/**
	 * A general-purpose Highcharts chart component
	 * @class TextView
	 * @param {LiveViewQueryService.LiveQueryModel} model The model to be used to drive data in this View
	 * @param {Element} element The the DOM element that this visualization should render in.
	 * @param {Object} [config] An object containing the parameters used to configure this GaugeView
	 */
	function TextView(model, element, config){
		if(this instanceof TextView === false){
			return new TextView(model, element, config);
		}

		this.model = model;
		this.viewModel = [];
		this.chart = [];
		this.element = element;
		this.config = config || {};

		this.HighCount = 30;
		this.HighColor = 'red';
		this.HighOrderId = '1';
		this.MedCount = 15;
		this.MedColor = 'yellow';
		this.MedOrderId = '2';
		this.NormCount = 0;
		this.NormColor = 'green';
		this.NormOrderId = '0';
		this.srvColor = this.NormColor;
		this.orderId = '';
		
		//alert(this.config.title);

		//Subscribe to model updates so we can update the view
		if(model instanceof LiveViewQueryService.LiveQueryModel){
			model.addInsertListener(this.handleDataAdded, this);
			model.addUpdateListener(this.handleDataUpdated, this);
			//model.addUpdateListener(this.handleDataAdded, this);
			model.addDeleteListener(this.handleDataRemoved, this);
		}
		else{
			console.error('[ERROR] TextView.constructor - The provided model is not a LiveQueryModel. Data will likely not be displayed for this TextView.');
		}

		//Build the view and add it to the DOM  height:' + element.height() + 'px;
		this.container1 = $('<div class="textview-container-1" style="display:inline-block; width:1000px; border:1px"></div>');
		this.container2 = $('<div class="textview-container-2" style="display:inline-block; width:1000px; border:1px"></div>');
		this.container3 = $('<div class="textview-container-3" style="display:inline-block; width:1000px; border:1px"></div>');
		
		$(element).append(this.container1);
		$(element).append(this.container2);
		$(element).append(this.container3);
	}
	TextView.prototype = {
		constructor: TextView,

		/**
		 * Adds the appropriate chart data based on chart series configuration.
		 * @param tuple {LiveView.Tuple} The tuple that was added to the dataset and should be used to extract values to display in the chart.
		 */
		handleDataAdded: function(tuple){
			var itemIndex, valueField;
			var textItems = [];
			var dispInstr = [];
			var ldispInst; var dispContainer;

			//alert('di lenght: '+this.config.displayItem.length);
			this.getColor(tuple);

			for(itemIndex = 0; itemIndex < this.config.displayItem.length; itemIndex++){

				if(this.config.displayItem[itemIndex][2] == 'CIRC' || this.config.displayItem[itemIndex][2] == 'RECT')
					ldispInst = this.config.displayItem[itemIndex][2] + '-' + this.srvColor;
				else				
					ldispInst = this.config.displayItem[itemIndex][2];

				//console.log('add:' + this.config.displayItem[itemIndex][0] + '--' + tuple.fieldMap[this.config.displayItem[itemIndex][1]]);
				textItems.push([this.config.displayItem[itemIndex][0],tuple.fieldMap[this.config.displayItem[itemIndex][1]]]);
				dispInstr.push([this.config.displayItem[itemIndex][0],ldispInst]);
			}
			
			/*this.chart.push(new TextItemView());
			if(this.orderId == this.HighCount)
				this.chart[this.chart.length-1].addItem(this.container1[0], textItems, dispInstr, this.orderId);
			else if(this.orderId == this.MidCount)
				this.chart[this.chart.length-1].addItem(this.container1[0], textItems, dispInstr, this.orderId);
			else
				this.chart[this.chart.length-1].addItem(this.container1[0], textItems, dispInstr, this.orderId);*/

			this.viewModel.push({'textItems': textItems, 'dispInstr': dispInstr, 'orderId': this.orderId}); // store the tuple

			if(this.orderId == this.HighCount)
				dispContainer = this.container1[0];
			else if(this.orderId == this.MidCount)
				dispContainer = this.container2[0];
			else
				dispContainer = this.container3[0];
			
			$(dispContainer).append(this.genTable(textItems, dispInstr));
		},

		/**
		 * Handles data updates for the chart.
		 * @param tuple {LiveView.Tuple} The tuple that was updated in the query result dataset. Note that because our
		 * LiveViewService utilizes the TupleStore, we have access to all fields (updated or not) in the tuple.
		 */
		handleDataUpdated: function(tuple){
			var itemIndex, chartIndex;
			var textItems = [];
			var dispInstr = [];
			var ldispInst;
			var dispContainer;

			this.getColor(tuple);

			// update data model 
			for(chartIndex=0;chartIndex<this.viewModel.length;chartIndex++) {
				textItems = this.viewModel[chartIndex]['textItems'];
				dispInstr = this.viewModel[chartIndex]['dispInstr'];
				//console.log('key: '+ textItems[0] + ' ' + tuple.fieldMap[this.config.displayItem[0][1]]);
				if(textItems[0][1] == tuple.fieldMap[this.config.displayItem[0][1]]) { // check with first key's value (primary key)
					for(itemIndex = 0; itemIndex < this.config.displayItem.length; itemIndex++) {

						if(this.config.displayItem[itemIndex][2] == 'CIRC' || this.config.displayItem[itemIndex][2] == 'RECT')
							ldispInst = this.config.displayItem[itemIndex][2] + '-' + this.srvColor;
						else				
							ldispInst = this.config.displayItem[itemIndex][2];

						textItems[itemIndex][1] = tuple.fieldMap[this.config.displayItem[itemIndex][1]];
						dispInstr[itemIndex][1] = ldispInst;
					}

					//this.chart[chartIndex].updateItem(textItems, dispInstr, this.orderId);
					this.viewModel[chartIndex]['textItems'] = textItems;
					this.viewModel[chartIndex]['dispInstr'] = dispInstr;
					this.viewModel[chartIndex]['orderId'] = this.orderId;
					break;
				}
			}

			// update display
			$(this.container1[0]).html("");
			$(this.container2[0]).html("");
			$(this.container3[0]).html("");

			for(chartIndex=0;chartIndex<this.viewModel.length;chartIndex++) {
				textItems = this.viewModel[chartIndex]['textItems'];
				dispInstr = this.viewModel[chartIndex]['dispInstr'];
				var lorderId = this.viewModel[chartIndex]['orderId'];

				if(lorderId == this.HighCount)
					dispContainer = this.container1[0];
				else if(lorderId == this.MidCount)
					dispContainer = this.container2[0];
				else
					dispContainer = this.container3[0];
				
				$(dispContainer).append(this.genTable(textItems, dispInstr));
			}


		},

		/**
		 * Handles data removal from the chart.
		 * @param tuple {LiveView.Tuple} The tuple that was removed in the query result dataset
		 */
		handleDataRemoved: function(tuple){
			var seriesIndex;

			//For each of the series defined in the visualizationConfig.series array, look up the stored Point reference
			//using the removed tuple's ID, and delete it. Again, we refrain from redrawing the chart until all points
			//have been removed.
			for(seriesIndex = 0; seriesIndex < this.config.series.length; seriesIndex++){
				if(!this.viewModel[seriesIndex] || !this.viewModel[seriesIndex][tuple.id]){
					continue;
				}
				this.viewModel[seriesIndex][tuple.id].remove(false);
			}
			delete this.viewModel[tuple.id];

			//now that all points have been updated on the chart, redraw it on the page
			this.chart.redraw();
		},

		genTable: function(textItems, dispInstr) {
			var divCls = 'tivcon-' + textItems[0][1];
			var html = '<div class="' + divCls + '" style="height:500px; width:230px; display:inline-block;">' +
						'<table border=1>';
			var cirClr, ffillCirClr='green', srvClr='green';

			for (var i = 0; i < textItems.length; i++) {
				
				html += '<tr>'; // add opening <tr> tag to the string:
				html += '<td align=center style="width:230px;">';
								
				if(dispInstr[i][1].indexOf('ECLIP') >= 0) {
					cirClr = dispInstr[i][1].split("-").pop();
					//console.log('inside circ');
					html += '<div style="display:inline-block; width: 15px;height: 10px;-webkit-border-radius: 25px;-moz-border-radius: 25px;border-radius: 25px;background: ' + cirClr + ';"></div> ';
				}
				

				html += textItems[i][0] + ' ' + (textItems[i][1]|| ' ');

				if(dispInstr[i][1].indexOf('CIRC') >= 0) {
					//console.log('inside circ');
					cirClr = dispInstr[i][1].split("-").pop();
					html += '<div style="width: 50px;height: 50px;-webkit-border-radius: 25px;-moz-border-radius: 25px;border-radius: 25px;background: ' + cirClr + ';"></div>';
				}
				else if(dispInstr[i][1].indexOf('RECT') >= 0) {
					cirClr = dispInstr[i][1].split("-").pop();
					html += '<div style="width: 50px;height: 50px;background: ' + cirClr + ';"></div>';

				}
				html += '</td>';
				html += '</tr>'; // add closing </tr> tag to the string:
			}
			html += '</table></div>';

			return html;
		},

		getColor: function(tuple) {
			if((tuple.fieldMap.ErrorCount) || 
				(tuple.fieldMap.CPU && tuple.fieldMap.Memory && tuple.fieldMap.CDrive && 
				tuple.fieldMap.DDrive && tuple.fieldMap.EDrive && tuple.fieldMap.SQLMemory &&
				tuple.fieldMap.Truevue))	 {
					if(parseInt(tuple.fieldMap.ErrorCount) >= this.HighCount || 
						parseInt(tuple.fieldMap.CPU) >= this.HighCount || 
						parseInt(tuple.fieldMap.Memory) >= this.HighCount || 
						parseInt(tuple.fieldMap.CDrive) >= this.HighCount || 
						parseInt(tuple.fieldMap.SQLMemory) >= this.HighCount ||
						parseInt(tuple.fieldMap.Truevue) >= this.HighCount
					) {// change bubble color on high error count
						this.srvColor = this.HighColor;
						this.orderId = this.HighCount;
					}
					else if(parseInt(tuple.fieldMap.ErrorCount) >= this.MedCount ||
						parseInt(tuple.fieldMap.CPU) >= this.MedCount || 
						parseInt(tuple.fieldMap.Memory) >= this.MedCount || 
						parseInt(tuple.fieldMap.CDrive) >= this.MedCount || 
						parseInt(tuple.fieldMap.SQLMemory) >= this.MedCount ||
						parseInt(tuple.fieldMap.Truevue) >= this.MedCount
					) {// change bubble color on medium error count
						this.srvColor = this.MedColor;
						this.orderId = this.MedCount;
					}
					else {
						this.srvColor = this.NormColor;
						this.orderId = this.NormCount;
					}
			}
			else
				this.srvColor = this.NormColor;
		}

	};

	/**
	 * Builds a Highcharts chart to be rendered in the provided DOM element.
	 * @param element {Element} The DOM element in which the chart should render
	 * @param [config] {Object} Optional configuration object that can be used to define the characteristics of the constructed chart
	 * @returns {Highcharts.Chart} A reference to the Highcharts.Chart object that was created
	 */
	function buildChart(element, config){
		return new TextItemView(element, config);
	}

	return TextView;

})(jQuery);