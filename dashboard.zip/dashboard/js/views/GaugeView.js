var GaugeView = (function($){
	'use strict';
	/**
	 * A Highcharts Gauge component
	 * @class GaugeView
	 * @param {LiveViewQueryService.LiveQueryModel} model The model to be used to drive data in this View
	 * @param {Element} element The the DOM element that this visualization should render in.
	 * @param {Object} [config] An object containing the parameters used to configure this GaugeView
	 */
	function GaugeView(model, element, config){
		var size;

		if(this instanceof GaugeView === false){ return new GaugeView(model, element, config); }

		this.model = model;
		this.element = element;
		this.config = config || {};
		size = 0.9*element.height(); //constrain the gauge view to 90% of its container

		//Subscribe to model updates so we can update the view
		if(model instanceof LiveViewQueryService.LiveQueryModel){
			model.addInsertListener(this.handleDataAdded, this);
			model.addUpdateListener(this.handleDataUpdated, this);
		}
		else{
			console.error('[ERROR] GaugeView.constructor - The provided model is not a LiveQueryModel. Data will likely not be displayed for this GaugeView.');
		}

		//Build the view and add it to the DOM
		this.container = $('<div class="gauge-container" style="width: ' + size + 'px; height:' + size + 'px; "></div>');
		this.gauge = buildGauge(this.container[0], config);
		$(element).append(this.container);
	}

	GaugeView.prototype = {
		constructor: GaugeView,
		handleDataAdded: function(tuple){
			this.gauge.series[0].addPoint(tuple.fieldMap[this.config.valueField]);
		},
		handleDataUpdated: function(tuple){
			this.gauge.series[0].data[0].update(tuple.fieldMap[this.config.valueField]);
		}
	};

	function buildGauge(element, config){
		config = config || {};
		config.min = isNaN(config.min) ? 0:config.min;
		config.max = isNaN(config.max) ? 0:config.max;
		return new Highcharts.Chart({
			chart: {
				type: 'gauge',
				plotBackgroundColor: null,
				plotBackgroundImage: null,
				plotBorderWidth: 0,
				plotShadow: false,
				renderTo: element
			},

			title: {
				text: config.title || ''
			},

			pane: {
				startAngle: -120,
				endAngle: 120,
				background: [
					{
						backgroundColor: {
							linearGradient: {x1: 0, y1: 0, x2: 0, y2: 1},
							stops: [
								[0, '#FFF'],
								[1, '#333']
							]
						},
						borderWidth: 0,
						outerRadius: '109%'
					},
					{
						backgroundColor: {
							linearGradient: {x1: 0, y1: 0, x2: 0, y2: 1},
							stops: [
								[0, '#333'],
								[1, '#FFF']
							]
						},
						borderWidth: 1,
						outerRadius: '107%'
					},
					{
						// default background
					},
					{
						backgroundColor: '#DDD',
						borderWidth: 0,
						outerRadius: '105%',
						innerRadius: '103%'
					}
				]
			},

			// the value axis
			yAxis: {
				min: config.min,
				max: config.max,

				minorTickInterval: 'auto',
				minorTickWidth: 1,
				minorTickLength: 10,
				minorTickPosition: 'inside',
				minorTickColor: '#666',

				tickPixelInterval: 30,
				tickWidth: 2,
				tickPosition: 'inside',
				tickLength: 10,
				tickColor: '#666',
				labels: {
					step: 2,
					rotation: 'auto'
				},
				title: {
					text: config.units || ''
				},
				plotBands: [
					{
						from: config.min,
						to: config.max / 4,
						color: '#DF5353' // red
					},
					{
						from: config.max / 4,
						to: config.max / 2,
						color: '#DDDF0D' // yellow
					},
					{
						from: config.max / 2,
						to: config.max,
						color: '#55BF3B' // green
					}
				]
			},

			series: [{
				name: config.valueField,
				data: [],
				tooltip: {
					valueSuffix: ' ' + (config.units || '')
				}
			}]
		});
	}

	return GaugeView;
})(jQuery);
