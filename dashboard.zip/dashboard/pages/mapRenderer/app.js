/**
 * Created by Harold Coqmard 5/22/2016.
 */
var app = (function($){
	"use strict";

	var debug = false;

	var lvConnection = undefined;

	var currSubscription = undefined;

	var insertTuple = function(schema, tuple){
		if(debug === true){
			console.info('Inserting ' + JSON.stringify(tuple) + ' as data...');
		}
		$('#Flow').append('<li id="' + tuple.id + '" data-coords="' + tuple.xPlot + ',' + tuple.yPlot + '" data-marker="' + tuple.stationType + '"><a href="' + tuple.FlowURL + '">' + tuple.flowHeader + '</a></li>');
	};

	var updateTuple = function(schema, tuple){
		if(debug === true){
			console.info('Updating ' + JSON.stringify(tuple) + ' as data...');
		}
		var row = $('#' + tuple.id);
		if(row.length){
			var fields = schema.fields;
			for(var i = 0; i < fields.length; i++){
				if(tuple.fieldMap[fields[i].name] !== undefined){
					var cell = row.find('td').eq(i);
					if(cell.length){
						cell.html(tuple.fieldMap[fields[i].name]);
					}
				}
			}
		}
	};

	var deleteTuple = function(tuple){
		if(debug === true){
			console.info('Deleting ' + JSON.stringify(tuple) + ' as data...');
		}
		var row = $('#' + tuple.id);
		if(row.length){
			row.remove();
		}
	};

	var getUrlParameter = function getUrlParameter(sParam) {
		var sPageURL = decodeURIComponent(window.location.search.substring(1)),
        		sURLVariables = sPageURL.split('&'),
        		sParameterName,
        		i;

    		for (i = 0; i < sURLVariables.length; i++) {
        		sParameterName = sURLVariables[i].split('=');

        		if (sParameterName[0] === sParam) {
            			return sParameterName[1] === undefined ? true : sParameterName[1];
        		}
    		}
	};

	return {

		onLoginLVMap: function(){
			console.info('Logging in ...');
			//connect to live view
			LiveView.connect({
				url: '/lv/client/',
				onClose: function(closeInfo){
					if(closeInfo.actor === 'server'){
						var msg = 'Disconnected by server';
						if(closeInfo.failReason != undefined){
							msg = msg + ' due to "' + closeInfo.failReason + "'";
						}
						console.info(msg);
						alert(msg);
					}
					else{
						console.info('Connection (' + lvConnection.id + ') - closed by (' + closeInfo.actor + ')');
					}
					resetApp();
				}
			}).then(
				function(connection){
					lvConnection = connection;
				},
				function(error){
					console.error(JSON.stringify(error) + ' while logging in anon...');
					alert(error.message);
				}
			);
		},

		onExecuteMap: function(){
			var query = 'SELECT * FROM MSTFlowTable WHERE MapName = \'' + getUrlParameter('map') + '\'';
			if(query !== undefined || query !== ''){
				console.info('Executing "' + query + '"...');
				lvConnection.execute(new LiveView.Query(query)).then(
					function(result){
                        var length = result.data.length;
                        for (var i = 0; i < length; i++) {
                            var tuple = result.data[i];
							insertTuple(result.schema, tuple);
						};
						console.info('Got ' + length + ' row(s) for "' + query + '"...');
					},
					function(error){
						console.error(JSON.stringify(error) + ' while executing "' + query + '"...');
						alert(error.message);
					}
				);
			}
		}

	}
})(jQuery);