'use strict';
/**
 * This object serves as the model for the jsapisample application. It defines 3 views as well as the name of the view
 * to display by default. Each view is identified in the model.views object by its name. A view consists of a name and
 * an array of components. A component defines a LiveView query to run and serve as the data provider for the component.
 * A component also defines a visualization that will handle the display of data when it is received from LiveView.
 */

// only one appModel, but multiple views.
// despite having multiple views, all visualization will still be executed regardless of which view is being loaded.
// this could potenailly cause performance issues if there are good number of visualization in this model file
var appModel = { // var name to be changed to appModel_gc
	defaultView: 'MSTFlow',
	views: {
		MSTFlow: {
			name: 'Flow',
			components: [
				{
					query: new LiveView.Query('SELECT * from MSTFlowTable'),
					visualization: new MSTFlow({
					})
				}
			]
		}
	}
};
