'use strict';
/**
 * This object serves as the model for the jsapisample application. It defines 3 views as well as the name of the view
 * to display by default. Each view is identified in the model.views object by its name. A view consists of a name and
 * an array of components. A component defines a LiveView query to run and serve as the data provider for the component.
 * A component also defines a visualization that will handle the display of data when it is received from LiveView.
 */

// only one appModel, but multiple views.
// despite having multiple views, all visualization will still be executed regardless of which view is being loaded.
// this could potenailly cause performance issues if there are good number of visualization in this model file
var appModel = { // var name to be changed to appModel_gc
	defaultView: 'BAM_Order_Capture',
	views: {
		BAM_Order_Capture: {
			name: 'CICS',
			components: [
				{
					query: new LiveView.Query('SELECT * from CICS_Summary_Full WHERE SYS_ID="C101" ORDER BY REGION LIMIT 20'),
					visualization: new GoogleChartPie({
						elementId: 'c101pie',
						storyName: 'C101 D2C Regions',
						categoryField: 'REGION',
						valueField: 'CPU_TIME',
						options: {
				         	title:'C101 D2C Regions',
				         	titleFontSize: 14,
				         	backgroundColor: '#333',
	                        width:330,
	                        height:215,
	                        is3D: true,
	                        chartArea: {left: 10, 'width': '100%', 'height': '70%'},
	                        tooltip: { isHtml: true }
				        }
					})
				},
				{
					query: new LiveView.Query('SELECT * from CICS_Summary_Full WHERE SYS_ID="C104" ORDER BY REGION LIMIT 20'),
					visualization: new GoogleChartPie({
						elementId: 'c104pie',
						storyName: 'C104 D2C Regions',
						categoryField: 'REGION',
						valueField: 'CPU_TIME',
						options: {
				         	title:'C104 D2C Regions',
				         	titleFontSize: 14,
				         	backgroundColor: '#333',
	                        width:330,
	                        height:215,
	                        is3D: true,
	                        chartArea: {left: 10, 'width': '100%', 'height': '70%'},
	                        tooltip: { isHtml: true }
				        }
					
					})
				},
				{
					query: new LiveView.Query('SELECT * FROM RT_VS_Batch WHEN LAST_UPD_TS BETWEEN now()-hours(8) AND now()'),
					visualization: new GoogleChartMultilineHideShowLine({
						elementId: 'orderCapture',
						storyName: '10 Minutes Order Interval',
						/* // this didn't work
						columnNames: {
							columnHeader: [['TS', 'Macy\'s RT', 'Bloomingdale\'s RT', 'Macy\'s Batch', 'Bloomingdale\'s Batch']]
						},*/
						xAxis: 'LAST_UPD_TS',
						line1: 'Macys_Completed_RT_inc',
						line2: 'Bloomingdales_Completed_RT_inc',
						line3: 'Macys_Completed_Batch_inc',
						line4: 'Bloomingdales_Completed_Batch_inc',
						howManyLines: 4,
						options: {
							title: '10 Minutes Order Interval',
							backgroundColor: '#333',
							//curveType: 'function',
							legend: { position: 'bottom' },
							pointSize: 12,
							width:1000,
							height: 440,
							hAxis: {
						        title: 'Time(EST)',
						        titleTextStyle: {
						            color: '#333'
						        },
						        gridlines:{
						        	count: 10,
						        	color: '#333',
						        	ticks: 10,
						        	color: 'transparent'
						        }
						    },
						    vAxis: {
						    	title: 'Order Count',
						        minValue: 0,
						        gridlines: {
						            color: 'white',
						            count: 10
						        },
						        viewWindowMode: "explicit", 
						        viewWindow:{ min: 0 },
						        // format: '#'
						    },
						    chartArea: {top: 40,'width': '85%', 'height': '70%'},
							series: {
				                0: { pointShape: 'star', color: 'orange'},
				                1: { pointShape: 'triangle', color: 'blue'},
				                2: { pointShape: 'square', color: 'pink'},
				                3: { pointShape: 'diamond', color: 'lime' },
				                4: { pointShape: 'polygon' }
				            },
				            tooltip: { isHtml: true } 
						}
					})
				}/*,
				{
					query: new LiveView.Query('SELECT * FROM SplunkD2CErrorMessages'),
					visualization: new GoogleChartTable({
						elementId: 'd2cSplunkError',
						field1: 'timePulled',
						field2: 'errorMessages'
						
					})
				},
				{
					query: new LiveView.Query('SELECT * FROM SplunkD2CErrorMessages'),
					visualization: new Table({
						elementId: 'd2cSplunkError2',
						headerTitleMap: {
							timePulled: 'Time Pulled',
							errorMessages: 'Error Messages'
						}
					})
				}*//*,

				}
				{
					query: new LiveView.Query('SELECT * from CICS_Summary_Full WHERE SYS_ID="C101" ORDER BY REGION LIMIT 20'),
					visualization: new GoogleChartGauge({
						elementId: 'c101gauge',
						storyName: 'C101 D2C Regions Meter',
						categoryField: 'REGION',
						valueField: 'CPU_TIME'
					})
				},
				{
					query: new LiveView.Query('SELECT * from CICS_Summary_Full WHERE SYS_ID="C104" ORDER BY REGION LIMIT 20'),
					visualization: new GoogleChartGauge({
						elementId: 'c104gauge',
						storyName: 'C104 D2C Regions Meter',
						categoryField: 'REGION',
						valueField: 'CPU_TIME'
					})
				}*//*,
				{
					query: new LiveView.Query('SELECT * from CICS_Status WHERE SYS_ID = "C101" ORDER BY REGION LIMIT 20'),
					visualization: new Stack({
						elementId: 'c101stack',
						storyName: 'CICS_stack',
						categoryField: 'REGION',
						valueField: 'STATUS',
					})
				},
				{
					query: new LiveView.Query('SELECT * from CICS_Status WHERE SYS_ID = "C104" ORDER BY REGION LIMIT 20'),
					visualization: new Stack({
						elementId: 'c104stack',
						storyName: 'CICS_stack',
						categoryField: 'REGION',
						valueField: 'STATUS'
					})
				}*/
			]
		}
	}
};
