'use strict';
/**
 * This object serves as the model for the jsapisample application. It defines 3 views as well as the name of the view
 * to display by default. Each view is identified in the model.views object by its name. A view consists of a name and
 * an array of components. A component defines a LiveView query to run and serve as the data provider for the component.
 * A component also defines a visualization that will handle the display of data when it is received from LiveView.
 */

// only one appModel, but multiple views.
// despite having multiple views, all visualization will still be executed regardless of which view is being loaded.
// this could potenailly cause performance issues if there are good number of visualization in this model file
var appModel = { // var name to be changed to appModel_gc
	defaultView: 'BAM_Order_Capture',
	views: {
		BAM_Order_Capture: {
			name: 'CICS',
			components: [
				{
					query: new LiveView.Query('SELECT * FROM SplunkD2CErrorMessages WHEN timePulled BETWEEN now()-hours(8) AND now()'),
					visualization: new GoogleChartTable({
						elementId: 'd2cSplunkError',
						field1: 'timePulled',
						field2: 'errorMessages',
						field1Name: 'Time Pulled',
						field2Name: 'Line Of Message The Error Appears In'
					})
				}/*,
				{
					query: new LiveView.Query('SELECT timePulled, errorMessages FROM SplunkD2CErrorMessages'),
					visualization: new Table({
						elementId: 'd2cSplunkError2',
						headerTitleMap: {
							timePulled: 'Time Pulled',
							errorMessages: 'Error Messages'
						}
					})
				}*/
			]
		}
	}
};
