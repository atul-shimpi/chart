var TextItemView = (function($){
	'use strict';
	
	/**
	 * A general-purpose Highcharts chart component
	 * @class TextItemView
	 * @param {LiveViewQueryService.LiveQueryModel} model The model to be used to drive data in this View
	 * @param {Element} element The the DOM element that this visualization should render in.
	 * @param {Object} [config] An object containing the parameters used to configure this GaugeView
	 */
	function TextItemView(){
		if(this instanceof TextItemView == false){
			return new TextItemView(model, element, config);
		}

		this.element = '';
		//this.textItems = [];

	}

	TextItemView.prototype = {
		constructor: TextItemView,
		
		addItem: function(element, textItems, dispInstr, orderId) {
			this.element = element;
			this.textItems = textItems;
			this.dispInstr = dispInstr;
			this.orderId = orderId;
			//alert(this.config.title);

			//Build the view and add it to the DOM
			//this.container = $('<div class="textitemview-container" style="height:300'/* + element.height() */+ 'px; ">This is an item</div>');
			var divCls = 'tivcon-' + textItems[0][1];
			//console.log('add divid: ' + divid);

			var html = '<div class="' + divCls + '" id = "' + orderId + '" style="height:500px; width:230px; display:inline-block;">';
			html += this.genTable();
			html += '</div>';
			this.container = html;
			//console.log('html: ' + html)
			$(element).append(this.container);
		},

		updateItem: function(textItems, dispInstr, orderId) {
			this.textItems = textItems;
			this.dispInstr = dispInstr;
			this.orderId = orderId;
			var html = this.genTable();
			//alert(this.config.title);
			//console.log('key: '+textItems[0][1]);
			//console.log('html: ' + $('div.textitemview-container-' + textItems[0][1]).html());
			var divCls = 'tivcon-' + textItems[0][1];
			//console.log('upitem: '+divid);
			var obj = $(this.element).find('div.' + divCls);
			obj.attr('id', orderId);
			obj.html(html); // replace with new content received
		
		},

		genTable: function() {
			var html = '<table border=1>';
			var cirClr, ffillCirClr='green', srvClr='green';

			for (var i = 0; i < this.textItems.length; i++) {
				
				html += '<tr>'; // add opening <tr> tag to the string:
				html += '<td align=center style="width:230px;">';
								
				if(this.dispInstr[i][1].indexOf('ECLIP') >= 0) {
					cirClr = this.dispInstr[i][1].split("-").pop();
					//console.log('inside circ');
					html += '<div style="display:inline-block; width: 15px;height: 10px;-webkit-border-radius: 25px;-moz-border-radius: 25px;border-radius: 25px;background: ' + cirClr + ';"></div> ';
				}
				

				html += this.textItems[i][0] + ' ' + (this.textItems[i][1]|| ' ');

				if(this.dispInstr[i][1].indexOf('CIRC') >= 0) {
					//console.log('inside circ');
					cirClr = this.dispInstr[i][1].split("-").pop();
					html += '<div style="width: 50px;height: 50px;-webkit-border-radius: 25px;-moz-border-radius: 25px;border-radius: 25px;background: ' + cirClr + ';"></div>';
				}
				else if(this.dispInstr[i][1].indexOf('RECT') >= 0) {
					cirClr = this.dispInstr[i][1].split("-").pop();
					html += '<div style="width: 50px;height: 50px;background: ' + cirClr + ';"></div>';

				}
				html += '</td>';
				html += '</tr>'; // add closing </tr> tag to the string:
			}
			html += '</table>';

			return html;
		},

		sortTables: function() {
			//var main = document.getElementById("textview-container-1");
			container = $('<div class="textview-container-1" style="display:inline-block; width:1000px; border:1px"></div>');
			var obj = $(this.element).find('div');
			for(var i = 0; i < obj.length; i++) {
				var div = obj[i];
				if(div != null)
					container.appendChild(div);
			}	
		},

		getFirstKeyValue: function() {
			return this.textItems[0][1]; // return first key's value; (primary key)
		}
	};

	return TextItemView;

})(jQuery);