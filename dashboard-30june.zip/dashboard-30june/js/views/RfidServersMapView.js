var RfidServersMapView = (function($){
	'use strict';


	/**
	 * A general-purpose Highcharts chart component
	 * @class RfidServersMapView
	 * @param {LiveViewQueryService.LiveQueryModel} model The model to be used to drive data in this View
	 * @param {Element} element The the DOM element that this visualization should render in.
	 * @param {Object} [config] An object containing the parameters used to configure this GaugeView
	 */
	function RfidServersMapView(model, element, config){
		if(this instanceof RfidServersMapView === false){
			return new RfidServersMapView(model, element, config);
		}

		this.model = model;
		this.viewModel = [];
		this.element = element;
		this.config = config || {};
		
		//Build the view and add it to the DOM
		this.container = $('<div class="map-container" style="height:' + element.height() + 'px; "></div>');
		this.mapview = buildChart(this.container[0], config);
		
    //
    var filters = `<center> <div class="btn-group">
    <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      Status <span class="caret"></span>
    </button>
    <ul class="dropdown-menu">
      <li><a href="#" onClick="setStatus('all-statuses')">All Statuses</a></li>
      <li><a href="#" onClick="setStatus('all-warnings')">All Warnings</a></li>      
      <li><a href="#" onClick="setStatus('green')">Green</a></li>
      <li><a href="#" onClick="setStatus('yellow')">Yellow</a></li>
      <li><a href="#" onClick="setStatus('red')">Red</a></li>
    </ul>
  </div>
  
  <div class="btn-group">
    <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      Business Div <span class="caret"></span>
    </button>
    <ul class="dropdown-menu">
      <li><a href="#" onClick="setBusinessDiv('all')">All</a></li>
      <li><a href="#" onClick="setBusinessDiv('Macys')">Macy's</a></li>
      <li><a href="#" onClick="setBusinessDiv('Bloomingdales')">Bloomingdales</a></li>
    </ul>
  </div> 
  <input id="store-number" type="number"  style="width: 90px;">
  <button type="button" class="btn btn-primary" onClick="openServerStatusUrl();">Go to Store</button></center>`
    //
		this.containerBtn = $(filters);
		$(element).append(this.containerBtn);
		$(element).append(this.container);

		//Subscribe to model updates so we can update the view
		if(model instanceof LiveViewQueryService.LiveQueryModel){
			//model.addInsertListener(this.handleDataAdded, this);
			model.addUpdateListener(this.handleDataUpdated, this);
			//model.addDeleteListener(this.handleDataRemoved, this);
		}
		else{
			console.error('[ERROR] RfidServersMapView.constructor - The provided model is not a LiveQueryModel. Data will likely not be displayed for this RfidServersMapView.');
		}
		
	}

	RfidServersMapView.prototype = {
		constructor: RfidServersMapView,

		handleDataAdded: function(tuple){
				
		},
		handleDataUpdated: function(tuple){
			return status;
		},
		handleDataRemoved: function(tuple){			
		},	
	};

	function buildChart(element, config){
		//alert('inside buildview')
		
    var normaljson = statusData;
    var warnjson = [];
    var errorjson = [];
    
		var mapDataPoints = [];
		var mapPoint = {};
		var H = Highcharts,
		map = H.maps['countries/us/custom/us-all-territories'];
        
var areasToIgnore = ['Puerto Rico', 'Saint John', 'Saipan', 'Rota', 'Western',
                          'Saint Croix', 'Eastern', 'Saint Thomas', 'Tinian'];
      var idxToIgnore = [];
     
     map.features.forEach(function(item, index) {
      if(item.type == 'Feature') {
        if(areasToIgnore.indexOf(item.properties.name) != -1) {
          idxToIgnore.push(index);
        }
      }
     });
     
     idxToIgnore.forEach(function(idx) {
      delete map.features[idx];
     });
     
     map.features.forEach(function(item, index) {
      if(item.type == 'Feature') {
        if(item.properties['hc-group'] == '__separator_lines__') {
          delete item.geometry.coordinates[7];
          delete item.geometry.coordinates[6];
          delete item.geometry.coordinates[5];
          delete item.geometry.coordinates[4];
          delete item.geometry.coordinates[3];
          delete item.geometry.coordinates[2];
          delete item.geometry.coordinates[1];          
        }
      }
     });
		return new Highcharts.mapChart({
			chart:{
				renderTo: element	,
width: 900,
            	height: 500,        
			},
			title: {text: config.title},
      credits: {
      enabled: false
  },
			mapNavigation: {
            	enabled: true
        	},

			tooltip: {
                pointFormat: 'Host: {point.source_host}<br>' +
                  'IP: {point.serverIP}<br>' +
                  'Queue Length: {point.processorQueueLength}<br>' +
                  'Avaiable Mem: {point.availableMBytes}<br>' +
                  'Processor Time: {point.processorTime}<br>' +
                  'Pool Paged Bytes: {point.poolPagedBytes}<br>'
            },
			
			xAxis: {
                crosshair: {
                    zIndex: 5,
                    dashStyle: 'dot',
                    snap: false,
                    color: 'gray'
                }
            },

            yAxis: {
                crosshair: {
                    zIndex: 5,
                    dashStyle: 'dot',
                    snap: false,
                    color: 'gray'
                }
            },

			plotOptions: {
				series: {
					//allowPointSelect: true,
					point: {
						events: {
							click: function (event) {
								location.href = ('index.html?' + event.point.source_host + "#serverdetailsview");
								//alert('clicked'+ event.point.storeNumber);
							}
						}
					}
				}
        	},

			series: [{
              name: 'Basemap',
              mapData: map,
              borderColor: '#606060',
              nullColor: 'rgba(200, 200, 200, 0.2)',
              showInLegend: false
          }, {
              name: 'Separators',
              type: 'mapline',
              data: H.geojson(map, 'mapline'),
              color: '#101010',
              enableMouseTracking: false,
              showInLegend: false
          }, {
              showInLegend: false,
              type: 'mapbubble',
              dataLabels: {
                  enabled: true,
                  format: '{point.storeNum}',                  
                  style:{color:"white"},                  
                  inside: true
              },
              name: 'Cities',
              data: normaljson,
              minsize: '1%',
              maxSize: '4%',
              color: 'green',
              inside: true,
              y: 10
          },{
              showInLegend: false,
              type: 'mapbubble',
              dataLabels: {
                  enabled: true,
                  format: '{point.storeNum}',
                  style:{color:"white"}
              },
              name: 'Cities',
              data: warnjson,
              minsize: '1%',
              maxSize: '4%',
              color: 'yellow'
          },
          {
              showInLegend: false,
              type: 'mapbubble',
              dataLabels: {
                  enabled: true,
                  format: '{point.storeNum}',
                  style:{color:"white"}
              },
              name: 'Cities',
              data: errorjson,
              minsize: '1%',
              maxSize: '4%',
              color: 'red'
          }]
		});
	  //});
	  //return ChartObj;
	}

	return RfidServersMapView;

})(jQuery);