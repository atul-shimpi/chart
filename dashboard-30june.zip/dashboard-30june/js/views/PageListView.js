var PageListView = (function($){
	'use strict';
	/**
	 *
	 * @param {Element} element The DOM element in which this PageListView should render
	 * @param {Object} model The object that will determine what data is displayed in this view
	 * @param {Object} [config] Optional key-value pair object that defines settings for the PageListView
	 * @param {String} [config.listClass] The CSS class string to apply to the unordered list element used by this view
	 * @param {String} [config.listItemClass] The CSS class string to apply to the list items displayed in this view's unordered list
	 * @constructor
	 */
	function PageListView(element, model, config){	
		var _this, pageId, listItemCount = 0;

		//make sure this is what we expect it to be
		if(this instanceof PageListView === false){
			return new PageListView(element, config);
		}

		_this = this;
		this.element = element;
		this.model = model;
		this.config = config || {};

		this.listElement = $('<ul class="nav nav-sidebar"></ul>');
		this.listItemElements = [];
		for(pageId in model){
			if(model.hasOwnProperty(pageId) === false){ continue; }
			//alert('page name: '+model[pageId].name);
			listItemCount = this.listItemElements.push(
				$('<li style="cursor:pointer;"><a href="#' + pageId + '">' + model[pageId].name + '</a></li>')
					.click(
						function(event){
							_this.listElement.children('li').removeClass('active');
							$(event.target.parentElement).addClass('active');
						}
					)
			);
			this.listElement.append(this.listItemElements[listItemCount-1]);
			$(element).append(this.listElement);
		}
	}
	PageListView.prototype = {
		constructor: PageListView,
		selectPage: function(pageId){
			this.listItemElements.forEach(function(listItem){
				var link = listItem.children('a');
				if(link[0]){
					link = link[0];
				}
				else{
					return;
				}
				if(link.hash === '#'+pageId){
					listItem.addClass('active');
				}
				else{
					listItem.removeClass('active');
				}
			});
		}
	};

	return PageListView;

})(jQuery);