var MapView = (function($){
	'use strict';


	/**
	 * A general-purpose Highcharts chart component
	 * @class MapView
	 * @param {LiveViewQueryService.LiveQueryModel} model The model to be used to drive data in this View
	 * @param {Element} element The the DOM element that this visualization should render in.
	 * @param {Object} [config] An object containing the parameters used to configure this GaugeView
	 */
	function MapView(model, element, config){
		if(this instanceof MapView === false){
			return new MapView(model, element, config);
		}

		this.model = model;
		this.viewModel = [];
		this.element = element;
		this.config = config || {};

		this.HighCount = 30;
		this.HighColor = 'red';
		this.MedCount = 15;
		this.MedColor = 'yellow';
		this.NormalColor = 'green';
		this.LocationId = ['ME', 'BL'];
		this.LocationName = ['Macy','Bloomingdales']
		
		//Build the view and add it to the DOM
		this.container = $('<div class="map-container" style="height:' + element.height() + 'px; "></div>');
		this.mapview = buildChart(this.container[0], config);
		this.loadMasterData();

		this.containerBtn = $('<button class="mybtn" id="filterAll">  All Stores </button> | <button id="filterMacy"> Macy Stores </button> | <button id="filterBloom"> Bloomingdales Stores </button> | <input type="text" size="7" id="filterStore" /><button id="filterSearch">Search</button>')
		$(element).append(this.containerBtn);
		$(element).append(this.container);

		//$("#filterAll").on('click', $.proxy(this.filterChart, this));
		//$("#filterAll").click($.proxy(this.filterChart, this));

		$('body').on('click', "#filterAll", $.proxy(this.filterChart, this, ''));
		$('body').on('click', "#filterMacy", $.proxy(this.filterChart, this, this.LocationId[0]));
		$('body').on('click', "#filterBloom", $.proxy(this.filterChart, this, this.LocationId[1]));
		$('body').on('click', "#filterSearch", $.proxy(this.searchStore, this));

		//Subscribe to model updates so we can update the view
		if(model instanceof LiveViewQueryService.LiveQueryModel){
			//model.addInsertListener(this.handleDataAdded, this);
			model.addUpdateListener(this.handleDataUpdated, this);
			//model.addDeleteListener(this.handleDataRemoved, this);
		}
		else{
			console.error('[ERROR] MapView.constructor - The provided model is not a LiveQueryModel. Data will likely not be displayed for this MapView.');
		}
		
	}

	MapView.prototype = {
		constructor: MapView,

		/**
		 * Adds the appropriate chart data based on chart series configuration.
		 * @param tuple {LiveView.Tuple} The tuple that was added to the dataset and should be used to extract values to display in the chart.
		 */
		handleDataAdded: function(tuple){
			var seriesIndex, valueField;

			console.log("addpoint: " +
				tuple.fieldMap.ServerName + ", " + 
				tuple.fieldMap.StoreNumber + ", " + 
				tuple.fieldMap.Latitude + ", " +  
				tuple.fieldMap.Longitude + ", " + 
				tuple.fieldMap.PostalCode + ", " + 
				tuple.fieldMap.ErrorCount + ", " + 
				tuple.fieldMap.DebugCount + ", " + 
				tuple.fieldMap.CPU + ", " + 
				tuple.fieldMap.Memory + ", " + 
				tuple.fieldMap.CDrive + ", " + 
				tuple.fieldMap.DDrive + ", " + 
				tuple.fieldMap.EDrive + ", " + 
				tuple.fieldMap.SQlMemory
				);
			var series = this.mapview.series[2];
			//alert('addpoint:'+seriesNumber+' series: '+this.view.series[seriesNumber].name+' point: '+point.CityName);
			series.addPoint({'serverName':tuple.fieldMap.ServerName, 
							'storeNumber':tuple.fieldMap.StoreNumber, 
							'lat':$.trim(tuple.fieldMap.Latitude), 
							'lon':$.trim(tuple.fieldMap.Longitude),
							'postcode':tuple.fieldMap.PostalCode,
							'errCount':$.trim(tuple.fieldMap.ErrorCount),
							'debugCount':$.trim(tuple.fieldMap.DebugCount),
							'z':$.trim(tuple.fieldMap.ErrorCount)
						});
			console.log('erros count ' + tuple.fieldMap.ErrorCount);
			if(parseInt(tuple.fieldMap.ErrorCount) >= this.HighCount) // change bubble color on high error count
				series.data[series.data.length-1].color = this.HighColor;
			else if(parseInt(tuple.fieldMap.ErrorCount) >= this.MedCount) // change bubble color on medium error count
				series.data[series.data.length-1].color = this.MedColor;
			else  // change bubble color on medium error count
				series.data[series.data.length-1].color = this.NormalColor;	
		},

		/**
		 * Handles data updates for the chart.
		 * @param tuple {LiveView.Tuple} The tuple that was updated in the query result dataset. Note that because our
		 * LiveViewService utilizes the TupleStore, we have access to all fields (updated or not) in the tuple.
		 */
		handleDataUpdated: function(tuple){
			var series = this.mapview.series[2];
			var status = false;

			for(var i=0; i < series.data.length; i++) {
				if(series.data[i].serverName == tuple.fieldMap.ServerName && 
						tuple.fieldMap.ErrorCount && tuple.fieldMap.DebugCount && 
						tuple.fieldMap.CPU && tuple.fieldMap.Memory && tuple.fieldMap.CDrive && 
						tuple.fieldMap.DDrive && tuple.fieldMap.EDrive && tuple.fieldMap.SQLMemory) {
					//alert('update: '+ series.data[i].serverName + ' pt: '+point.ServerName);
					series.data[i].update({
							'errCount':$.trim(tuple.fieldMap.ErrorCount),
							'debugCount':$.trim(tuple.fieldMap.DebugCount),
							'cpu':$.trim(tuple.fieldMap.CPU),
							'memory':$.trim(tuple.fieldMap.Memory),
							'cdrive':$.trim(tuple.fieldMap.CDrive),
							'ddrive':$.trim(tuple.fieldMap.DDrive),
							'edrive':$.trim(tuple.fieldMap.EDrive),
							'sqlmemory':$.trim(tuple.fieldMap.SQLMemory),							
							'z':$.trim(tuple.fieldMap.ErrorCount)
						});
					series.data[i].zIndex = 100;//parseInt(point.ErrorCount)/2;

					this.viewModel[i] = series.data[i];
					//console.log("xxx ' + tuple.fieldMap.ErrorCount);
					if(parseInt(tuple.fieldMap.ErrorCount) >= this.HighCount || 
						parseInt(tuple.fieldMap.CPU) >= this.HighCount || 
						parseInt(tuple.fieldMap.Memory) >= this.HighCount || 
						parseInt(tuple.fieldMap.CDrive) >= this.HighCount || 
						parseInt(tuple.fieldMap.SQLMemory) >= this.HighCount 
					) // change bubble color on high error count
						series.data[i].color = this.HighColor;
					else if(parseInt(tuple.fieldMap.ErrorCount) >= this.MedCount ||
						parseInt(tuple.fieldMap.CPU) >= this.MedCount || 
						parseInt(tuple.fieldMap.Memory) >= this.MedCount || 
						parseInt(tuple.fieldMap.CDrive) >= this.MedCount || 
						parseInt(tuple.fieldMap.SQLMemory) >= this.MedCount 
					) // change bubble color on medium error count
						series.data[i].color = this.MedColor;
					} else {
						series.data[i].color = this.normalColor;
					}	
					status = true;
					break;
				}
			}
			return status;
		},

		/**
		 * Handles data removal from the chart.
		 * @param tuple {LiveView.Tuple} The tuple that was removed in the query result dataset
		 */
		handleDataRemoved: function(tuple){
			var seriesIndex;

			//For each of the series defined in the visualizationConfig.series array, look up the stored Point reference
			//using the removed tuple's ID, and delete it. Again, we refrain from redrawing the chart until all points
			//have been removed.
			for(seriesIndex = 0; seriesIndex < this.config.series.length; seriesIndex++){
				if(!this.viewModel[seriesIndex] || !this.viewModel[seriesIndex][tuple.id]){
					continue;
				}
				this.viewModel[seriesIndex][tuple.id].remove(false);
			}
			delete this.viewModel[tuple.id];

			//now that all points have been updated on the chart, redraw it on the page
			this.mapview.redraw();
		},

		loadMasterData: function() {
			var mapPoint={};
			var lIndex;
			var series = this.mapview.series[2];
			var _this = this;

			$.get('RFID_Locations_640.csv', function(csv) {
	//ServerName,IP,City,State,PostalCode,Latitude,Longitude,SrvAppDateTime,ErrorCount,DebugCount,InfoCount,FineCount,SrvStatDateTime,CPU,Memory,CDrive,DDrive,EDrive
	//ME001ASRFI21,111.189.144.145,Elmhurst,NY,11373,42.651445,-73.755254,2016-12-07 18:08:02,0,0,0,0,2016-12-07 18:08:02,0,0,0,0,0
				
				var lines = csv.split('\n'); // Split the lines

				$.each(lines, function (lineNo, line) {
					var items = line.split(',');

					if (lineNo != 0) { // not headerline?
						//alert('addpoint:'+seriesNumber+' series: '+this.view.series[seriesNumber].name+' point: '+point.CityName);
						series.addPoint({
							'serverName':items[0], 
							'storeNumber':items[2], 
							'lat':parseFloat(items[5]), 
							'lon':parseFloat(items[6]),
							'postcode':items[4],
							'errCount':parseInt(items[8]),
							'debugCount':parseInt(items[9]),
							'cpu':parseInt(items[13]),
							'memory':parseInt(items[14]),
							'cdrive':parseInt(items[15]),
							'ddrive':parseInt(items[16]),
							'edrive':parseInt(items[17]),
							'sqlmemory':parseInt(items[18]),
							'z':parseInt(items[8])
						}, false);

						_this.viewModel.push({
							'serverName':items[0], 
							'storeNumber':items[2], 
							'lat':parseFloat(items[5]), 
							'lon':parseFloat(items[6]),
							'postcode':items[4],
							'errCount':parseInt(items[8]),
							'debugCount':parseInt(items[9]),
							'cpu':parseInt(items[13]),
							'memory':parseInt(items[14]),
							'cdrive':parseInt(items[15]),
							'ddrive':parseInt(items[16]),
							'edrive':parseInt(items[17]),
							'sqlmemory':parseInt(items[18]),
							'z':parseInt(items[8])
						});
						//console.log(items[0]);

						//lIndex = _this.getLocationIndex(items[0]);
						//console.log('data: ' + series.data[series.data.length - 1]);
						//_this.viewModel.push(series.data[series.data.length - 1]);

					}
				});
				//_this.viewModel = series.data;
				series.redraw();
				//alert(_this.viewModel.length);
			});
			
		},

		searchStore: function() {
			var i;
			var series = this.mapview.series[2];
			series.setData([]);
			//series.redraw();
			//lData = this.viewModel[1].value;
			//alert($('body').find('#filterStore').val());
			//alert('includes ' + strStoreNum + ' ' + this.viewModel.length);
			var strStoreNum = $('body').find('#filterStore').val()
			for (var i=0; i < this.viewModel.length;i++) {
				if(this.viewModel[i]['storeNumber'] == strStoreNum) {
					console.log(this.viewModel[i]['serverName']);
					/*series.addPoint({
							'serverName':this.viewModel[i]['serverName'], 
							'storeNumber':this.viewModel[i]['storeNumber'], 
							'lat':parseFloat(this.viewModel[i]['lat']), 
							'lon':parseFloat(this.viewModel[i]['lon']),
							'postcode':this.viewModel[i]['postcode'],
							'errCount':parseInt(this.viewModel[i]['errCount']),
							'debugCount':parseInt(this.viewModel[i]['debugCount']),
							'z':parseInt(this.viewModel[i]['z'])
						}, false);*/
					location.href = '?' + this.viewModel[i]['serverName'] + '#serverdetailsview';
					break;
				}
			}
			series.redraw();
			//this.mapview.mapZoom(0.9,100,100);
			this.mapview.mapZoom();
		},


		filterChart: function(strLocationId) {
			var lData = {};
			var i;
			var series = this.mapview.series[2];
			series.setData([]);
			//series.redraw();
			//lData = this.viewModel[1].value;
			//alert('includes ' + strLocationId + ' ' + this.viewModel.length);
			for (var i=0; i < this.viewModel.length;i++) {
				/*for(var obj in this.viewModel[i]) {
						console.log(this.viewModel[i][obj]);
				}*/
				if(this.viewModel[i]['serverName'] != null && this.viewModel[i]['serverName'].includes(strLocationId)) {
					console.log(this.viewModel[i]['serverName']);
					series.addPoint({
							'serverName':this.viewModel[i]['serverName'], 
							'storeNumber':this.viewModel[i]['storeNumber'], 
							'lat':parseFloat(this.viewModel[i]['lat']), 
							'lon':parseFloat(this.viewModel[i]['lon']),
							'postcode':this.viewModel[i]['postcode'],
							'errCount':parseInt(this.viewModel[i]['errCount']),
							'debugCount':parseInt(this.viewModel[i]['debugCount']),
							'cpu':parseInt(this.viewModel[i]['cpu']),
							'memory':parseInt(this.viewModel[i]['memory']),
							'cdrive':parseInt(this.viewModel[i]['cdrive']),
							'ddrive':parseInt(this.viewModel[i]['ddrive']),
							'edrive':parseInt(this.viewModel[i]['edrive']),
							'sqlmemory':parseInt(this.viewModel[i]['sqlmemory']),							
							'z':parseInt(this.viewModel[i]['z'])
						}, false);
				}
			}
			series.redraw();
			//this.mapview.mapZoom(0.9,100,100);
			this.mapview.mapZoom();
		}
	};


	/**
	 * Builds a Highcharts chart to be rendered in the provided DOM element.
	 * @param element {Element} The DOM element in which the chart should render
	 * @param [config] {Object} Optional configuration object that can be used to define the characteristics of the constructed chart
	 * @returns {Highcharts.Chart} A reference to the Highcharts.Chart object that was created
	 */

	function buildChart(element, config){
		//alert('inside buildview')
		
		var mapDataPoints = [];
		var mapPoint = {};
		var H = Highcharts,
		map = H.maps['countries/us/us-all'];
        

		return new Highcharts.mapChart({
			chart:{
				renderTo: element,
				animation: Highcharts.svg,
				margin: 0,
				width: 1000,
            	height: 700,
			},
			title: {text: config.title},

			mapNavigation: {
            	enabled: true
        	},

			tooltip: {
                pointFormat: '{point.serverName}, <br>' +
					'Store Number: {point.storeNumber}<br>' +
                    'Postal code: {point.postcode}<br>' +
                    'errCount: {point.errCount}<br>' +
                    'debugCount: {point.debugCount}<br>'
            },
			
			xAxis: {
                crosshair: {
                    zIndex: 5,
                    dashStyle: 'dot',
                    snap: false,
                    color: 'gray'
                }
            },

            yAxis: {
                crosshair: {
                    zIndex: 5,
                    dashStyle: 'dot',
                    snap: false,
                    color: 'gray'
                }
            },

			plotOptions: {
				series: {
					//allowPointSelect: true,
					point: {
						events: {
							click: function (event) {
								location.href = '?' + event.point.serverName + '#serverdetailsview';
								//alert('clicked'+ event.point.storeNumber);
							}
						}
					}
				}
        	},

			series: [{
                name: 'Basemap',
                mapData: map,
                borderColor: '#606060',
                nullColor: 'rgba(200, 200, 200, 0.2)',
                showInLegend: false
            }, {
                name: 'Separators',
                type: 'mapline',
                data: H.geojson(map, 'mapline'),
                color: '#101010',
                enableMouseTracking: false,
                showInLegend: false
            }, {
                type: 'mapbubble',
                dataLabels: {
                    enabled: true,
                    format: '{point.storeNumber}'
                },
				showInLegend: false,
                name: 'Cities',
				data: mapDataPoints,
				/*data: [{
					'city': 'Montgomery',
					'lat': 32.380120,
					'lon': -86.300629
				}, {
					'city': 'Juneau',
					'lat': 58.299740,
					'lon': -134.406794
				}, {
					'city': 'Phoenix',
					'lat': 33.448260,
					'lon': -112.075774
				}],*/
                minSize: '1%',
				maxSize: '4%',
                //color: H.getOptions().colors[0]
				color: 'green',
				hover: 'blue'
            }]
		});
	  //});
	  //return ChartObj;
	}

	return MapView;

})(jQuery);